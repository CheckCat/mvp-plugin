---
name: clarify-mvp
description: Use between /prepare-mvp and /bootstrap-mvp. Audits project_brief/ for inconsistencies, missing data, and grey zones — classifies findings by severity, persists an AskQueue, supports modes auto/light/medium/hard with self-critique. Resume-friendly across sessions.
---

# clarify-mvp

Закрывает дыры и несостыковки в `project_brief/` после `/prepare-mvp` и до `/bootstrap-mvp`. Шире, чем «закрыть заголовки для bootstrap»: ищет противоречия, серые зоны, неполноту бизнес-логики и стека. Количество вопросов растёт с объёмом проекта; режим определяет, на какие из них отвечает человек, а на какие — модель.

Опционален. Но если `project_brief/` имеет пустые обязательные секции — bootstrap встанет на синтаксической валидации, и тогда clarify становится фактически обязательным шагом.

Полный контекст плейбука — `~/.claude/playbooks/mvp.md`. Контракт brief'а — `~/.claude/playbooks/scripts/brief-contract.sh`.

---

## Когда использовать

- После `/prepare-mvp`, до `/bootstrap-mvp`.
- В `project_brief/` есть `business_logic.md` + `technical_solutions.md` со скелетом обязательных секций.
- Хочется поймать неоднозначности на уровне brief'а, а не каскадно в коде.

## Когда НЕ использовать

- `project_brief/` отсутствует или невалиден — сначала `/prepare-mvp`.
- `.claude/agents/` уже сгенерирован — правки brief требуют ребутстрапа. Pre-flight это поймает и предложит подтвердить.

---

## Шаг 0: Pre-flight

```bash
source ~/.claude/playbooks/scripts/brief-contract.sh

# brief существует?
test -f project_brief/business_logic.md || { echo "❌ нет business_logic.md — запусти /prepare-mvp"; exit 1; }
test -f project_brief/technical_solutions.md || { echo "❌ нет technical_solutions.md — запусти /prepare-mvp"; exit 1; }

# Skeleton-контракт prepare пройден? (presence, не non-emptiness)
validate_brief_presence project_brief \
  || { echo "⛔ Skeleton brief'а сломан — запусти /prepare-mvp --recreate"; exit 1; }

# Bootstrap уже сделан?
if [ -d .claude/agents ]; then
  echo "⚠ .claude/agents/ существует — правки brief потребуют ребутстрапа."
  # Stop&Ask через AskUserQuestion:
  #   "Продолжить (потребуется повторный /bootstrap-mvp)" | "Отмена"
fi
```

`.claude/agents/` Stop&Ask — обязательно через AskUserQuestion, не молчаливый exit.

---

## Шаг 1: Парсинг ARGUMENTS

ARGUMENTS slash-команды — одна или несколько строк через пробел.

Распознаём:
- `auto` / `light` / `medium` / `hard` — стартовый режим закрытия (см. Шаг 4.5). **Опционально.** Без аргумента — режим спрашивается через AskUserQuestion после генерации и self-critique.
- `--restart` — стереть существующий `clarify_queue.jsonl` и начать аудит с нуля. Без флага — resume (если очередь есть).
- `--no-self-critique` — отключить Pass 2. По умолчанию self-critique включён.

Запиши решения в переменные `MODE` (может быть пустой), `RESTART`, `SELF_CRITIQUE`.

**Принципиально:** на этом шаге режим **не выбирается через Stop&Ask**. Сначала генерируем вопросы и refute'им их (Шаги 3 и 3.5), потом показываем оператору сводку и спрашиваем режим (Шаг 4.5). До этого оператор не имеет содержательных данных для выбора.

---

## Шаг 2: Resume или инициализация AskQueue

`AskQueue` — persistent очередь находок: `project_brief/clarify_queue.jsonl`. Каждая строка — JSON-объект:

```jsonc
{
  "id": "Q-001",
  "category": "stack | business | inconsistency",
  "severity": "critical | medium | low",
  "summary": "...",                           // одно предложение, что неясно
  "evidence": ["цитата из brief'а или абзац", "..."],
  "target": {                                  // куда писать ответ
    "file": "technical_solutions.md",
    "header": "## Auth"
  },
  "options": ["вариант 1", "вариант 2", "вариант 3"],
  "recommended_v1": "вариант N",
  "rationale_v1": "почему так",
  "self_critique": {
    "verdict": "confirmed | changed",
    "reason": "..."
  },
  "recommended": "финальный recommended после self-critique",
  "rationale": "финальная мотивация",
  "status": "pending | answered_human | answered_auto | skipped | outdated",
  "source": "auto | human",
  "answer": null,                              // фактический выбор: полный label из options[] (после ответа)
  "operator_note": null,                       // optional: уточнение оператора, если выбрал Other с пояснением
  "answered_at": null
}
```

**Решение о resume:**

```bash
QUEUE=project_brief/clarify_queue.jsonl
QUEUE_EXISTS=0
HAS_PENDING=0
[ -f "$QUEUE" ] && QUEUE_EXISTS=1
[ -f "$QUEUE" ] && grep -q '"status":[[:space:]]*"pending"' "$QUEUE" && HAS_PENDING=1
```

Если очередь существует — **Stop&Ask** через AskUserQuestion:

| label | description |
|---|---|
| `Продолжить (Рекомендуется)` | Резюмировать на оставшихся `pending` записях. Сохраняет уже отвеченное и self-critique. |
| `Начать заново` | Удаляет очередь в backup и запускает полный audit + self-critique с нуля. Все предыдущие ответы потеряются. |

Если `RESTART=1` (флаг) — пропусти Stop&Ask и автоматически считай выбор «Начать заново».

«Начать заново»:
```bash
TS=$(date +%Y%m%d-%H%M%S)
mv "$QUEUE" "project_brief/clarify_queue.${TS}.bak.jsonl"
echo "✓ старая очередь сохранена в clarify_queue.${TS}.bak.jsonl"
RESUME=0
```

«Продолжить»:
```bash
RESUME=1
echo "ℹ Resume: пропускаем аудит и self-critique, идём в Шаг 4.5 (выбор режима) / Шаг 5 (закрытие)."
```

Если `QUEUE_EXISTS=0` — нет вопроса, `RESUME=0`, очередь создаётся в Шаге 4.

Если `RESUME=1` → пропусти Шаги 3, 3.5 и 4 — все вопросы и refute уже записаны в очереди от предыдущей сессии.

---

## Шаг 3: Audit brief — поиск дыр

Прочитай `business_logic.md`, `technical_solutions.md`, `glossary.md` (если есть), `analysis_grey_zones.md` (если есть). Сформируй список находок по трём категориям. Не выдумывай факты — опирайся на текст brief'а и/или **отсутствие данных в скелетных секциях**.

### 3.0 Формат находки (инварианты)

- `2 ≤ len(options) ≤ 4`. Если опций больше — сжимай до 4 (наименее ценные сливаются/удаляются). UI AskUserQuestion жёстко режет на 4-й.
- `options[0]` — это **всегда финальный `recommended`** после Pass 2. Не «первая попавшаяся» опция, не Pass-1-recommended. Контракт: override-эвристика `bootstrap-mvp/scripts/export-brief-decisions.sh` считает «оператор-override», когда `answer ≠ options[0]`.
- `category ∈ {stack, business, inconsistency}`. `severity ∈ {critical, medium, low}`. Other — не категория.

### 3.1 Категория `inconsistency` — противоречия внутри brief'а

Примеры:
- `frontend: nextjs`, но в `## Core scenarios` нет ни одного UI-сценария.
- `db: postgresql, redis`, но в `## Services` ни один сервис не использует кэш.
- В `business_logic.md` упомянуты интеграции (Stripe, OAuth, email, push), но в `## Services` нет соответствующего сервиса/модуля.
- `## Roles` упоминает админа, но `## Auth` не описывает RBAC.

### 3.2 Категория `business` — дыры в бизнес-логике

Признак: обязательная секция пустая ИЛИ описана так абстрактно, что bootstrap-y / plan-y нечего сгенерировать.

Чек-листы:
- `## Roles` — есть ли разделение прав? Если только «User» — спросить про админа/multi-tenant.
- `## Core scenarios` — минимум один end-to-end happy path.
- `## MVP scope` — что НЕ входит в первую версию (критично для plan'а — иначе разворачивается полная целевая архитектура).
- `## Success criteria` — KPI или функциональные критерии «MVP сдан».
- Edge-cases для главного сценария — если они подразумеваются природой продукта (платежи, multi-tenant, async pipelines).

### 3.3 Категория `stack` — дыры в техническом стеке

Признак: обязательная секция пустая, либо контент слишком общий для генерации кода.

Чек-листы:
- `## Stack` ключи присутствуют, но что-то выглядит подозрительно (DB добавки без объяснения, и т.д.).
- `## Services` — список есть, но границы непонятны (один сервис «делает всё»).
- `## Auth` — пусто, либо «JWT» без деталей: cookie session vs Bearer, refresh-токены, RBAC.
- `## Deploy` — пусто, либо не закрывает специфику (single VPS / cluster / DNS / certs).
- `## Layout` — корректен относительно реальной структуры сервисов.

### 3.4 Tier-1 расширения (опциональные секции)

Если из brief'а очевидно, что есть требование без секции — предложи создать. Не выдумывай беспричинно:
- `## Versions` — мажорные версии (NestJS 11 / FastAPI 0.115 / etc.).
- `## Scale` — порядок величины (DAU, RPS, объём данных).
- `## Observability` — logs / metrics / tracing требования.
- `## Messaging` — broker, если из `## Services` > 1 и есть асинхронные операции.
- `## Background jobs` — если бизнес-логика подразумевает очереди/cron.
- `## Secrets` — где живут API-keys, OAuth-tokens, db credentials.
- `## Integrations` — каждая внешняя система отдельной подсекцией.
- `## CI` — GitHub Actions / GitLab / etc.
- `## Compliance` — GDPR / PCI / HIPAA, если в бизнес-логике есть signals (PII, payments, medical).
- `## Edge cases` — критичные сбойные сценарии для главного flow.

Эти секции **добавляются по реальным сигналам**, не списком.

### 3.5 Severity-классификация

Для каждой находки выставь severity:
- **critical** — без ответа bootstrap сделает неверный выбор стека / безопасности / границ сервисов / MVP scope. Цена неправильного ответа — переписывание архитектуры.
- **medium** — качество мета-файлов / агентских правил пострадает. Архитектура устоит.
- **low** — улучшит документацию. Не влияет на код.

В сомнительном случае → escalate (medium ↑ critical, low ↑ medium). Цена ложного critical — лишний вопрос. Цена ложного low — пропуск важного решения.

---

## Шаг 3.5: Self-critique (Pass 2)

**Запускается для ВСЕХ находок** (если не выставлен `--no-self-critique`). Self-critique происходит **до** Stop&Ask о режиме — оператор должен видеть уже отрефаченные рекомендации, чтобы делать осмысленный выбор «отвечать самому ИЛИ доверить модели».

Почему для всех, а не только для critical:
- Self-critique — единственный фильтр anchoring между Pass 1 и финальным `recommended`. Если режим окажется `auto` или `light` (а оператор увидит только critical), для medium/low оператор примет результат Pass 1 без refute — это та же дыра, которую refute призван закрыть.
- Дешевле выполнить refute один раз сейчас на все, чем условно ветвить на «critical всегда + остальные зависит от режима». Branching усложняет SKILL без улучшения качества.

### Refute-промпт (обязательная форма)

Self-critique — это **adversarial refute**, не «ещё раз подумай». Для каждой находки выполни буквально следующий промпт (отдельный шаг рассуждения, не продолжение Pass 1):

> **Задача**: я (модель) сейчас рекомендую `<recommended_v1>` для вопроса `<summary>`.
> Допусти на 5 минут, что это **неправильный** ответ. Без оправдания — найди настоящие причины поменять выбор.
>
> Пройдись по списку:
> 1. **Какой конкретный сценарий из `## Core scenarios` / `## MVP scope` / `## Edge cases` ломается** от моего выбора? Цитата.
> 2. **Какая другая опция из `options[]` ближе** к этому сценарию? Почему?
> 3. **Какие сигналы в brief'е я проигнорировал** при формулировке `rationale_v1`? Цитата из brief'а или явное «секция X пуста».
> 4. **Скрытая стоимость**: что мой выбор удорожает на стадии plan/execute (миграция, рефакторинг, отказ от добавок к стеку, integration costs)?
> 5. **Reversibility**: если через месяц станет ясно, что я ошибся — насколько дорого откатиться? Если дорого — это аргумент против.
>
> Итог одной строкой: `verdict: confirmed | changed` + одно предложение «почему».

### Запись результата

1. Если хотя бы один пункт 1–5 дал содержательный аргумент против → `verdict: changed`, перепиши `recommended` и `rationale` под новый выбор.
   **После изменения** — переставь новый `recommended` в `options[0]` (см. 3.0). Старый Pass-1 вариант остаётся в массиве, но не на первой позиции.
2. Если все пять пунктов дали «нет сильного аргумента» → `verdict: confirmed`. **Запиши в `self_critique.reason` именно то, что Pass 2 проверил**, а не перефраз `rationale_v1`.
3. `recommended_v1` и `rationale_v1` остаются в записи неизменно — это audit-trail.

### Sanity-check на формальный self-critique

После прохода по всем критикам — посчитай `changed_rate = changed / total`. Если **`changed_rate == 0` на 5+ critical-находках** — это сильный сигнал, что Pass 2 деградировал в перефраз Pass 1. Не игнорируй: вылогируй предупреждение в сводку Шага 4, чтобы оператор знал, что он по факту согласовывает Pass 1, а не результат состязательной проверки. Это не блокер — иногда Pass 1 действительно достаточно хорош.

### Пример плохого self-critique (анти-паттерн)

```jsonc
{
  "recommended_v1": "PostgreSQL",
  "rationale_v1": "Зрелая БД, хорошая поддержка, ACID.",
  "self_critique": {
    "verdict": "confirmed",
    "reason": "PostgreSQL — стандарт индустрии, выбор обоснован."   // ← перефраз rationale_v1, не refute
  },
  "recommended": "PostgreSQL"
}
```

### Пример нормального self-critique

```jsonc
{
  "recommended_v1": "Собственный auth-service (FastAPI + JWT)",
  "rationale_v1": "Меньше внешних зависимостей.",
  "self_critique": {
    "verdict": "confirmed",
    "reason": "Pass 2: Better-Auth ускоряет frontend на 1-2 недели, но (3) brief'а в '## Auth' явно требует multi-tenant заделы и контроль refresh-flow — внешний провайдер усложнит миграцию tenant_id во все таблицы. (4) Recovery cost от Better-Auth → собственный auth-service в середине разработки — переписать integration во всех сервисах. (5) Reversibility: обратная замена дешевле прямой. Confirmed."
  },
  "recommended": "Собственный auth-service (FastAPI + JWT)"
}
```

Self-critique должен быть **отдельным проходом** с другим промптом, не «продолжением» формулирования options. Цель — снять anchoring модели на собственные первые варианты.

---

## Шаг 4: Запись AskQueue

Сохрани все находки в `project_brief/clarify_queue.jsonl` (JSON Lines, одна находка = одна строка). Все записи на этом этапе со статусом `pending`.

Не упорядочивай по severity жёстко — порядок в файле = порядок появления; сортировка для UX в Шаге 5.

Покажи оператору сводку:
```
✓ Аудит и self-critique завершены.
Найдено: <N> вопросов.
  - critical: <Nc>
  - medium:   <Nm>
  - low:      <Nl>
По категориям:
  - stack:         <Ns>
  - business:      <Nb>
  - inconsistency: <Ni>

Self-critique: <skipped | <K_sc>/N refute'нуто, changed=<K_changed>>
<если K_sc > 0 и changed_rate == 0 на ≥5 critical:>
⚠ Self-critique: changed_rate=0 на N критичных. Pass 2, вероятно, формальный.

Очередь: project_brief/clarify_queue.jsonl
```

---

## Шаг 4.5: Выбор стартового режима (Stop&Ask)

Если `MODE` уже был передан в ARGUMENTS — пропусти этот шаг.

Если `RESUME=1` (продолжаем старую очередь) — тоже пропусти. Стартовый уровень определяется автоматически по высшей `pending` severity (см. Шаг 5).

Иначе — **Stop&Ask** через AskUserQuestion. Сейчас оператор видит полную картину (вопросы сгенерированы, refute сделан) и может осмысленно выбрать, до какого уровня дойти ему лично:

| label | description |
|---|---|
| `light (Рекомендуется)` | Сам отвечаешь на critical (<Nc> шт.). После — спросим, продолжать ли medium / закрыть всё auto. |
| `medium` | Сам отвечаешь на critical + medium (<Nc> + <Nm> шт.). После — спросим про low. |
| `hard` | Сам отвечаешь на всё (<Nc> + <Nm> + <Nl> шт.). Без auto. |
| `auto` | Не дёргаем тебя. Модель сама закрывает всё recommended. |

`recommended_v1` и финальные `recommended` уже видны оператору через сводку — выбор осмысленный. Сохрани результат в `MODE`.

---

## Шаг 5: Закрытие очереди

Базовая модель: **уровневая эскалация** по severity. Оператор закрывает severity своего стартового уровня (выбранного в Шаге 4.5), затем явно решает — повышать уровень или auto-закрыть остальное.

Стартовый уровень определяется так:

| Источник | `start_level` |
|---|---|
| `MODE = light` | `critical` |
| `MODE = medium` | `medium` |
| `MODE = hard` | `low` |
| `MODE = auto` | `none` (все → auto) |
| `RESUME=1`, MODE не передан | высшая severity среди pending записей |

Внутренний порядок severity: `critical` → `medium` → `low`. «Дойти до level=medium» означает «закрыть critical и medium через оператора».

### 5.1 Если `MODE = auto`

Закрой все `pending` записи как `answered_auto` (см. формат ниже) и переходи в Шаг 6.

### 5.2 Уровневый loop (light / medium / hard / resume)

Псевдокод:

```
SEVERITY_ORDER = [critical, medium, low]
current_max = start_level  # критический индекс «дойти до»

for level in SEVERITY_ORDER:
  pending_in_level = [q for q in queue if q.status == pending and q.severity == level]

  if SEVERITY_ORDER.index(level) > SEVERITY_ORDER.index(current_max):
    # Уровень ниже current_max — оператор не выбрал сюда идти.
    auto_close_all(pending_in_level)
    continue

  if pending_in_level:
    handle_via_AskUserQuestion(pending_in_level)
    # Внутри handle: батчи по 3-4 + pause-control между батчами.
    # pause «Отложить»  → exit run, оставляем pending как есть.
    # pause «Закончить» → set current_max = level, break loop → auto-close на всё ниже.

  if level == current_max and level != low:
    next_level = SEVERITY_ORDER[index + 1]
    remaining_below = [q for q in queue if q.status == pending and severity_lower_than(q.severity, level)]
    if remaining_below:
      Stop&Ask:
        "Завершить — auto-close на {next_level}+ (<K_remaining> вопросов)"
        "Продолжить — обсудить {next_level} (<K_next_level> вопросов) сам"
      if Завершить → break loop → auto-close на всё ниже.
      if Продолжить → current_max = next_level
```

### 5.3 Батчинг и pause-control внутри уровня

- AskUserQuestion поддерживает до 4 вопросов на батч. Бери батчами 3–4.
- Между батчами — **pause-control** через отдельный AskUserQuestion:
  - **Продолжить** — следующий батч этого уровня.
  - **Отложить** — pending записи остаются как есть; маркер записывается с актуальным pending; выход с «возвращайся `/clarify-mvp` для resume».
  - **Закончить** — оператор больше не хочет ничего обсуждать; auto-close остальное (текущий уровень + всё ниже) и переходим в Шаг 6.

### 5.4 Формат закрытия

Внутри AskUserQuestion-батча каждый вопрос:
- `question` — `summary` находки (одно предложение).
- `header` — короткий тег (`Auth` / `Stack: db` / `MVP scope` / etc.).
- `options` — `options` из находки + автоматический «Other» от UI.
- Рекомендованный вариант — `recommended` с суффиксом «(Рекомендуется)» в первой позиции.

После ответа:
- `answer = <label выбранной опции>` — **полный label из `options[]`**, не сокращай и не склеивай с уточнением. Override-эвристика сравнивает по `options[0]`.
- Если оператор выбрал Other и добавил пояснение → `answer = выбранный или ближайший label`, **`operator_note = текст уточнения`**. Не объединяй их в `answer` — это ломает override-эвристику и теряет структуру.
- `status = answered_human`
- `source = human`
- `answered_at = <ISO-date из контекста>`

Auto-close (для записей вне current_max и для случая «Завершить»):
- `answer = options[0]` (полный label).
- `status = answered_auto`
- `source = auto`
- `answered_at = <ISO-date>`

После loop'а **все** записи должны быть либо `answered_*`, либо `pending` (только при «Отложить»). `skipped` использовать только если запись стала нерелевантной (например, между сессиями оператор уже закрыл вопрос ручной правкой brief'а).

---

## Шаг 6: Применение ответов к brief'у

Пройдись по записям со статусом `answered_human` или `answered_auto`, у которых ответ ещё не применён к brief'у (трекинг — отдельное поле, либо просто сравнение состояний).

**Стратегия записи** (выбирай по типу ответа, не по «пустая/заполнена»):

1. **Секция отсутствует** → создай заголовок + тело из ответа.
2. **Секция пустая** (только заголовок) → запиши тело из ответа.
3. **Секция заполнена + ответ УТОЧНЯЕТ** (добавляет новое к уже описанному: новый edge case, password hashing внутри уже описанного Auth, добавочный invariant) → **append** блок с `<!-- clarify <date>: <Q-id> -->` маркером в конец секции.
4. **Секция заполнена + ответ ПЕРЕОПРЕДЕЛЯЕТ** (меняет описанный архитектурный факт: 12 сервисов → modular monolith; email → Telegram; синхронный orchestrator → Celery) → **перепиши тело секции целиком** под финальное решение. Маркер `<!-- clarify <date>: <Q-id> -->` ставится **первой строкой нового тела**. Старый текст не сохраняется — он есть в `git log` и в `clarify_queue.jsonl` (поле `evidence`).

**Критерий «переопределяет vs уточняет»:** ответ противоречит хотя бы одному утверждению из текущего текста секции → переопределяет. Если все утверждения сохраняются, а ответ только добавляет — уточняет.

`operator_note` (если есть) пиши подзаголовком `**Уточнение оператора:** <текст>` сразу после маркера.

**Несколько вопросов в одну секцию** — каждый ответ отдельным блоком с `<!-- clarify ... -->` маркером (для трассируемости).

Используй Edit с уникальным якорем (заголовок + следующая строка). Не Write — не перезаписывай файлы целиком.

### Шаг 6.5: Glossary sync (механический проход)

После применения всех ответов — пройдись по новым именам, появившимся в `answer` / `operator_note` любой `answered_*` записи. Паттерны имён, требующих определения в `glossary.md`:
- `*Adapter`, `*Service`, `*Channel`, `*Bot`, `*Saga`, `*Middleware`, `*Repository`
- Технические термины с заглавной буквы: `RTR`, `JWT`, `OAuth`, `AES-256-GCM` (если ещё нет в glossary)
- Имена сервисов / runtime: `Celery`, `Celery Beat`, `Pika`, `Anthropic`, и т.п.

Для каждого имени, отсутствующего в `glossary.md`, добавь строку в таблицу:
```
| **<Имя>** | Однострочное определение из контекста решения (откуда появилось, какую роль играет). |
```

Это **механический** проход, не семантический разбор. Если имя уже есть — пропусти. Если не уверен в определении — возьми ближайшую строку из `rationale` соответствующей записи.

---

## Шаг 7: Маркер + финальная валидация

### 7.1 Audit-лог в analysis_grey_zones.md

Допиши блок в конец `project_brief/analysis_grey_zones.md` (создай файл если нет):

```markdown
<!-- clarify-mvp:done <ISO-date>; mode=<MODE>; reached_level=<critical|medium|low|none>; pending_critical=<Nc>; pending_total=<Np> -->

## Clarify session — <ISO-date> (mode=<MODE>, reached=<reached_level>)

Аудит: <N_total> вопросов (critical=<Nc_total>, medium=<Nm_total>, low=<Nl_total>).
Self-critique: <skipped | <K_sc>/N refute'нуто, changed=<K_changed>>.
Стартовый MODE: <MODE>; достигнутый уровень: <reached_level>.
Закрыто в этой сессии: <N_closed> (human=<K_human>, auto=<K_auto_closed>).
Осталось pending: <N_pending> (critical=<Nc>, total=<Np>).

### Closed in this session
- **[Q-001 / critical / stack]** <summary> → <answer> [source=<auto|human>]
- ...

### Still pending
- **[Q-007 / medium / business]** <summary> [ждёт ответа — оператор «Отложил» в pause-control]
- ...
```

`reached_level` — самая глубокая severity, которую оператор в этой сессии обсудил сам (не auto). `none` если выбрано `auto`.

`Still pending` содержит **только** записи, которые оператор явно «Отложил». В остальных случаях (включая «Завершить» и режим `auto`) все записи закрыты как `answered_*` к концу Шага 5.

Где `<Nc>` и `<Np>` в HTML-комментарии — текущее число pending после Шага 5/6 (не за всю историю).

ISO-date бери из системного контекста (`Today's date`), не из `date`.

### 7.2 Валидация

```bash
source ~/.claude/playbooks/scripts/brief-contract.sh

# Маркер записан
clarify_marker_present project_brief/analysis_grey_zones.md \
  || { echo "❌ маркер clarify-mvp:done не записан"; exit 1; }

# Skeleton не сломан (presence-only; clarify имеет право оставлять секции пустыми
# для следующего раунда — non-emptiness проверит bootstrap)
validate_brief_presence project_brief \
  || { echo "⛔ Skeleton сломан — откати правки"; exit 1; }

# Stack-ключи на месте (целостность; non-emptiness — забота bootstrap)
for k in backend frontend deploy db; do
  grep -qE "^- ${k}:" project_brief/technical_solutions.md \
    || { echo "❌ потерян ключ '${k}:' в ## Stack"; exit 1; }
done

echo "✓ clarify-валидация пройдена"
```

---

## Шаг 8: Коммит

```bash
bash ~/.claude/playbooks/scripts/clarify-finalize.sh
```

Скрипт стейджит только `project_brief/`, коммитит через `-F msg-file`, возвращает JSON. Без флагов и интерактива.

Если получил `{"skipped": "nothing-to-commit"}` — это норма, например в режиме «отложить» когда ни одна запись не применилась.

Не пиши `git commit -m ...` напрямую. Это активирует `git-commit-contract`.

---

## Финальное сообщение

```
✅ Clarify session завершён.

Стартовый режим: <MODE>; достигнутый уровень: <reached_level>.
Аудит: <N_total> вопросов (critical=<Nc_total>, medium=<Nm_total>, low=<Nl_total>).

В этой сессии:
  закрыто оператором: <K_human>
  закрыто auto:       <K_auto_closed>
  отложено:           <N_pending> (critical=<Nc>)

Self-critique: <skipped | <K_sc>/N refute'нуто, changed=<K_changed>>
Audit log: project_brief/analysis_grey_zones.md
Queue:     project_brief/clarify_queue.jsonl

<если N_pending == 0:>
Brief полностью закрыт. Готов к /bootstrap-mvp.

<если N_pending > 0 и pending_critical == 0:>
Часть вопросов отложена, но критики все закрыты — /bootstrap-mvp пройдёт без подтверждения.
Дозакрыть остальное: /clarify-mvp (продолжит resume).

<если pending_critical > 0:>
⚠ Есть unresolved critical (<Nc>). /bootstrap-mvp потребует подтверждения.
Дозакрой: /clarify-mvp (продолжит с pending critical).
```

---

## Anti-patterns

- НЕ выдумывай факты, которых нет в brief'е. Любой `recommended` должен опираться на текст или явное «отсутствует — нужно решить».
- НЕ выдумывай дыры в идеально-полном brief'е. Если аудит дал ноль находок — запиши маркер с `pending_critical=0; pending_total=0` и выходи.
- НЕ задавай через AskUserQuestion вопросы, на которые brief уже ответил руками между сессиями (resume должен это учесть — при resume пересмотри pending: остаётся ли смысл).
- НЕ удаляй маркер `clarify-mvp:done` — он защищает bootstrap от запуска на старых данных.
- НЕ зови `git-commit-contract` skill. Делай коммит через `clarify-finalize.sh`.
- НЕ генерируй `CLAUDE.md` / `ARCHITECTURE.md` / `.claude/agents/` — работа bootstrap.
- НЕ меняй `## Stack` ключи (`backend`/`frontend`/`deploy`/`db`) без явного ответа оператора в AskQueue. Это контракт prepare.
- НЕ создавай Tier-1 секции «на всякий случай». Только если из brief'а есть прямой сигнал.
- НЕ дублируй список обязательных заголовков. Тяни из `brief-contract.sh`.
- НЕ перезаписывай **файл brief'а** целиком. Точечный Edit — секцию переписывать можно, и это правильный flow для ответа, переопределяющего архитектурный факт (см. Шаг 6, случай 4).
- НЕ склеивай `operator_note` в `answer`. Уточнение — в отдельное поле. Иначе ломается override-эвристика.
- НЕ оставляй `options[0] ≠ recommended` после `verdict=changed`. Это контракт формата (см. 3.0).
- НЕ удаляй `clarify_queue.jsonl` без `--restart`. Это инвариант resume'а.

---

## Будущие расширения (заглушки)

Структура находки уже хранит `recommended_v1` / `self_critique` / `recommended`. Это позволяет добавить:

- **Iterative self-critique** — несколько раундов Pass 2 → Pass 3 → ..., каждый записывает свою verdict-ветку.
- **External critic** — отдельная модель / отдельный prompt-shape для refute-прохода.
- **Adversarial pair** — два независимых аудита (поиск + перепроверка) с расхождениями как отдельный класс находок.

Каждое из этих расширений ложится в существующий формат записи AskQueue без миграции схемы. Менять структуру в первой версии — оверинженеринг; место зарезервировано.
