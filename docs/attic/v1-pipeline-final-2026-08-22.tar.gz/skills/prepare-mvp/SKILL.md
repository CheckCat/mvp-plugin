---
name: prepare-mvp
description: First step of MVP playbook. Reads raw initial files in any format (md/txt/json), packages them into canonical project_brief/ structure required by bootstrap-mvp and plan-mvp. Archives originals to project_brief.raw/. Works only on empty/fresh projects.
---

# prepare-mvp

Превращает «как оператор описал проект» в «как пайплайн ждёт описание». Оператор пишет в свободной форме (один файл, несколько файлов, разные имена, разная разметка). Этот скилл упаковывает всё в каноническую структуру `project_brief/` с обязательными файлами и секциями. Исходники сохраняются в `project_brief.raw/` для трассировки.

**Скилл работает только на пустом/свежем проекте.** Если проект уже начат (есть код, bootstrap-mvp отработал, генерированные мета-файлы) — hard error, без обходных путей. Prepare — это форматтер начальной спеки, не редактор существующего проекта.

Полный контекст плейбука — `~/.claude/playbooks/mvp.md`.

---

## Когда использовать

- Самый первый шаг плейбука — до `/bootstrap-mvp`
- В корне есть исходное описание проекта в любом виде (`project_prompt_files/`, `brief/`, `docs/`, или просто `.md`/`.txt`/`.json` файлы)
- Опционально — путь к папке с исходниками передаётся аргументом: `/prepare-mvp ./my-notes/`

## Когда НЕ использовать

- Проект уже начат — Шаг 0 поймает и завершится с ошибкой
- Нужно отредактировать существующий `project_brief/` — правь файлы руками, prepare не для этого

---

## Шаг 0: Pre-flight checks

Два независимых блока. Первый — hard error при любом сигнале «проект начат». Второй — Stop&Ask про git.

### 0.1 Project-started gate (hard error)

```bash
STARTED=0
SIGNALS=()

[ -d .claude/agents ] && { SIGNALS+=("  - .claude/agents/ exists"); STARTED=1; }
[ -d .claude/state ]  && { SIGNALS+=("  - .claude/state/ exists");  STARTED=1; }
[ -f CLAUDE.md ]      && { SIGNALS+=("  - CLAUDE.md exists");       STARTED=1; }
[ -f ARCHITECTURE.md ] && { SIGNALS+=("  - ARCHITECTURE.md exists"); STARTED=1; }

for f in package.json pyproject.toml Cargo.toml go.mod; do
  [ -f "$f" ] && { SIGNALS+=("  - $f exists in root"); STARTED=1; }
done

for pattern in 'apps/*/package.json' 'services/*/pyproject.toml' 'apps/*/pyproject.toml' 'services/*/package.json'; do
  for f in $pattern; do
    [ -f "$f" ] && { SIGNALS+=("  - $f exists"); STARTED=1; }
  done
done

if [ $STARTED -eq 1 ]; then
  echo "❌ Проект уже начат. /prepare-mvp только для пустых проектов."
  echo ""
  echo "Обнаруженные сигналы:"
  printf '%s\n' "${SIGNALS[@]}"
  echo ""
  echo "Что делать:"
  echo "  • Хочешь отредактировать brief — правь project_brief/ руками."
  echo "  • Хочешь начать с нуля — это другой проект, создай новую папку."
  exit 1
fi
```

Если этот блок не упал — продолжай.

### 0.2 Git Stop&Ask

```bash
if ! command -v git >/dev/null 2>&1 || ! git rev-parse --git-dir >/dev/null 2>&1; then
  GIT_MISSING=1
else
  GIT_MISSING=0
fi
```

Если `GIT_MISSING=1` — **Stop&Ask** через `AskUserQuestion`:

> «Git репозиторий не инициализирован. `bootstrap-mvp` дальше потребует git. Инициализировать сейчас?»
> - **Да, `git init`** — выполнить `git init`, продолжить.
> - **Нет, продолжить без git** — пропустить коммит в Шаге 7, оператор инициализирует руками когда нужно.

Если ответ «да» — выполни:

```bash
git init
# Проверь user.name/email; если нет — Stop&Ask с просьбой настроить, не продолжай
git config user.name >/dev/null && git config user.email >/dev/null || {
  echo "⚠ git user.name / user.email не настроены"
  echo "  выполни: git config user.name '...' && git config user.email '...'"
  echo "  затем повтори /prepare-mvp"
  exit 1
}
```

Если ответ «нет» — сохрани флаг `SKIP_GIT_COMMIT=1` для Шага 7.

---

## Шаг 1: Парсинг ARGUMENTS

`ARGUMENTS` slash-команды содержит максимум один токен — путь к папке с исходниками.

- Если `ARGUMENTS` пуст → `SOURCE_DIR` определяется через discovery (Шаг 2).
- Если `ARGUMENTS` содержит путь → `SOURCE_DIR` = этот путь, проверь `test -d "$SOURCE_DIR"`. Если нет — Stop&Ask «папка не существует».

Нет флагов. Никакого `--force`. Решение о пересоздании задаётся через Stop&Ask в Шаге 3.

---

## Шаг 2: Discovery исходников

Если `SOURCE_DIR` не задан явно — ищи в этом порядке:

1. `project_prompt_files/` (старое имя, наиболее частый случай)
2. `project_brief.raw/` (если был предыдущий prepare-прогон — это наш raw-источник)
3. `brief/`
4. `docs/`
5. `spec/`
6. `requirements/`
7. Файлы `.md` / `.txt` / `.json` в корне репозитория, исключая стандартные:

```
README.md, CLAUDE.md, ARCHITECTURE.md, PROJECT_PLAN.md, REVIEW.md,
LICENSE.md, LICENSE, CHANGELOG.md, CONTRIBUTING.md, SECURITY.md,
package.json, package-lock.json, tsconfig*.json, composer.json,
turbo.json, nx.json, biome.json, .eslintrc.json, pnpm-workspace.yaml,
renovate.json
```

Если найдено в нескольких местах — **Stop&Ask:**

> «Нашёл несколько кандидатов источников: `<список>`. Передай явно: `/prepare-mvp <путь>`.»

Если не найдено нигде — **Stop&Ask:**

```
Создай папку с описанием проекта (любое имя, например project_prompt_files/)
и положи туда минимум:
  • что мы строим (1-2 абзаца про продукт и пользователей)
  • какой стек (backend / frontend / db / deploy)

После — повтори /prepare-mvp [path].
```

Собери полный список найденных файлов и их содержимое — это вход для упаковки в Шаге 4.

---

## Шаг 3: Existing brief check

```bash
if [ -d project_brief ]; then
  EXISTS=1
else
  EXISTS=0
fi
```

Если `EXISTS=1` — **Stop&Ask** через `AskUserQuestion`:

> «`project_brief/` уже существует. Пересоздать его из исходников?»
> - **Да, пересоздать** — старый brief переедет в `project_brief.bak.<ts>/`, новый сгенерируется из `SOURCE_DIR`.
> - **Нет, оставить** — выйти без изменений.

Если ответ «нет» — exit 0 с сообщением «оставлено как было».

Если ответ «да» — пометь `RECREATE=1` для Шага 4 (он сделает backup перед atomic-swap).

---

## Шаг 4: Atomic LLM packaging

Atomic flow гарантирует: либо `project_brief/` валиден и новый, либо его нет вообще (есть `.bak.<ts>/`). Никаких полу-готовых состояний.

### 4.1 Backup + prepare tmp dir

```bash
TS=$(date +%Y%m%d-%H%M%S)

if [ "${RECREATE:-0}" = "1" ]; then
  mv project_brief "project_brief.bak.${TS}"
  echo "✓ backup: project_brief.bak.${TS}/"
fi

rm -rf project_brief.tmp 2>/dev/null
mkdir -p project_brief.tmp
```

Если до этого `project_brief.tmp/` остался от прошлого крашнутого прогона — `rm -rf` его очистит.

### 4.2 LLM packaging в .tmp/

Прочитай все исходники из `SOURCE_DIR` и сгенерируй каноническую структуру **в `project_brief.tmp/`**:

```
project_brief.tmp/
  business_logic.md       — что мы строим, зачем, для кого, ключевые сценарии. 1-3 экрана.
  technical_solutions.md  — стек, архитектурные решения, ключевые библиотеки.
  glossary.md             — термины предметной области (если есть). Опционально.
  analysis_grey_zones.md  — принятые решения по неоднозначным вопросам (если есть). Опционально.
```

#### Обязательные заголовки (skeleton-контракт)

Источник правды — `~/.claude/playbooks/scripts/brief-contract.sh`. Подгружай и сверяйся:

```bash
source ~/.claude/playbooks/scripts/brief-contract.sh
required_headers_tech   # печатает обязательные заголовки technical_solutions.md
required_headers_biz    # печатает обязательные заголовки business_logic.md
```

В **`business_logic.md`** должны быть созданы заголовки:
- `## Goal` — 1 абзац: что и зачем.
- `## Roles` — кто пользуется системой (user / admin / multi-tenant и т.д.).
- `## Core scenarios` — минимум один happy path end-to-end.
- `## MVP scope` — что входит в первую версию / что НЕ входит.
- `## Success criteria` — как поймём, что работает.

В **`technical_solutions.md`** должны быть созданы заголовки:
- `## Stack` — allowlist (см. ниже).
- `## Services` — список модулей/сервисов (для monolith одна запись).
- `## Auth` — допускает значение `none`.
- `## Deploy` — соответствует `## Stack > deploy`.
- `## Layout` — auto-fill (см. ниже).

**Skeleton-правило:** prepare заполняет секции **best-effort из исходников**. Если данных нет — секция создаётся пустой (только заголовок + пустая строка). Закрывать пустые секции — задача clarify или ручной правки оператора. **Заголовок без контента — нормально, отсутствующий заголовок — нет.**

**НЕ создавай опциональные Tier-1 секции** (`## Versions`, `## Scale`, `## Messaging`, `## Observability`, `## Background jobs`, `## Secrets`, `## Compliance`, `## CI`, `## Edge cases`, `## Integrations`). Их добавляет clarify по необходимости.

#### Контракт `technical_solutions.md` — секция `## Stack`

Обязательны ключи и значения из allowlist:

| Ключ | Поддержанные значения |
|---|---|
| `backend` | `nestjs` \| `fastapi` |
| `frontend` | `nextjs` \| `react` \| `none` |
| `deploy` | `docker-dokploy` |
| `db` | `postgresql` (с опциональными добавками: `redis`, `timescaledb`, через запятую) |

Пример:
```markdown
## Stack
- backend: nestjs
- frontend: nextjs
- deploy: docker-dokploy
- db: postgresql, redis
```

**Stop&Ask по стеку — обязателен** при любом из этих сигналов. Не догадывайся ни в одном из случаев, даже под auto-mode bias:

1. **Неявное упоминание** («TypeScript backend», «Python API», «something async like FastAPI/NestJS»).
2. **Явная альтернатива** в исходниках (`NestJS или FastAPI`, `Next.js / Remix`, `Postgres or MySQL`) — оператор не выбрал, не выбирай за него. Сигнал «оператор разрешил позже» — не считается; «позже» наступило в момент prepare.
3. **Неподдержанное значение** из allowlist (`backend: spring-boot`, `frontend: vue`).
4. **Сигналы из инфраструктуры проекта** (агенты в `~/.claude/agents/templates/` под FastAPI, существующие конфиги) — это **не** разрешение выбрать за оператора. Это лишь хорошая «recommended-первая» подсказка для Stop&Ask, но решение всё равно делает он.

Формат Stop&Ask: AskUserQuestion с конкретикой («в исходниках: `NestJS или FastAPI`. Поддерживаются оба. Какой выбираем?») и опциями из allowlist. В options.description упомяни сигналы из инфраструктуры («рекомендуется fastapi: проектные templates под него»), но первая позиция не «Рекомендуется» — оператор выбирает сам.

Анти-паттерн: записать выбор в `analysis_grey_zones.md` как «принято за тебя по сигналам агентов» и продолжить. Это нарушает контракт: brief должен отражать решения оператора, а не модели.

#### Auto-fill секции `## Layout`

Layout — monorepo convention для plan-mvp (как раскладывать сервисы по путям). Заполняется автоматически из `## Stack`:

```bash
source ~/.claude/playbooks/scripts/brief-contract.sh
BACKEND=$(extract_stack_value project_brief.tmp/technical_solutions.md backend)
FRONTEND=$(extract_stack_value project_brief.tmp/technical_solutions.md frontend)
# services_count = число bullet'ов под "## Services"; если ещё пусто — 1
SERVICES_COUNT=$(awk '/^## Services[[:space:]]*$/,/^## /' project_brief.tmp/technical_solutions.md \
  | grep -cE '^- ' || echo 1)
LAYOUT=$(auto_layout_from_stack "$BACKEND" "$FRONTEND" "$SERVICES_COUNT")
```

Записывай в файл блоком:
```markdown
## Layout
<LAYOUT-value>
```

Если оператор позже руками поменяет `## Layout` — это его право, prepare не перезаписывает на следующих прогонах (кроме `RECREATE`).

#### Принципы упаковки

- Не выдумывай факты, которых нет в исходниках. Бизнес-логика описана парой предложений — `business_logic.md` будет короткой, но **обязательные заголовки всё равно создаются** (пустыми).
- Не дублируй содержимое между файлами.
- Сохраняй смысл, переформулируй для структуры. README.md обычно mixed-bag — раздели на `business_logic` и `technical_solutions` по смыслу.
- `glossary.md` — только если в исходниках встречаются доменные термины с пояснениями. Не выдумывай словарь.
- `analysis_grey_zones.md` — только если в исходниках есть явные «решили X а не Y потому что…».

### 4.3 Машинная валидация

После записи файлов в `.tmp/` запусти строгую валидацию. Источник списка заголовков — `brief-contract.sh`, allowlist значений stack остаётся здесь (prepare владеет этим контрактом).

```bash
source ~/.claude/playbooks/scripts/brief-contract.sh
VALID=1
cd project_brief.tmp

# 1. Обязательные файлы непусты
for f in business_logic.md technical_solutions.md; do
  if [ ! -s "$f" ]; then
    echo "❌ $f отсутствует или пуст"; VALID=0
  fi
done

# 2. Skeleton-контракт: ВСЕ обязательные заголовки созданы (контент может быть пуст).
#    validate_*_presence — presence-only (без non-empty); non-emptiness проверит bootstrap.
validate_tech_presence technical_solutions.md || VALID=0
validate_biz_presence  business_logic.md || VALID=0
# Layout обязателен (его auto-fill'ит prepare) — проверяем presence отдельно
header_present technical_solutions.md "## Layout" || { echo "❌ technical_solutions.md: '## Layout' отсутствует (должен быть auto-filled)"; VALID=0; }

# 3. Все обязательные ключи присутствуют в ## Stack
for key in backend frontend deploy db; do
  if ! grep -qE "^- ${key}:" technical_solutions.md; then
    echo "❌ Ключ '${key}:' отсутствует в ## Stack"; VALID=0
  fi
done

# 4. Allowlist значений (контракт prepare, остаётся здесь)
BACKEND=$(extract_stack_value technical_solutions.md backend)
case "$BACKEND" in
  nestjs|fastapi) ;;
  *) echo "❌ backend='$BACKEND' не поддержан (allowed: nestjs|fastapi)"; VALID=0 ;;
esac

FRONTEND=$(extract_stack_value technical_solutions.md frontend)
case "$FRONTEND" in
  nextjs|react|none) ;;
  *) echo "❌ frontend='$FRONTEND' не поддержан (allowed: nextjs|react|none)"; VALID=0 ;;
esac

DEPLOY=$(extract_stack_value technical_solutions.md deploy)
case "$DEPLOY" in
  docker-dokploy) ;;
  *) echo "❌ deploy='$DEPLOY' не поддержан (allowed: docker-dokploy)"; VALID=0 ;;
esac

DB=$(extract_stack_value technical_solutions.md db)
echo "$DB" | grep -qE '(^|,[[:space:]]*)postgresql([[:space:]]*,|[[:space:]]*$)' || {
  echo "❌ db должен включать postgresql, получено: '$DB'"; VALID=0;
}
for token in $(echo "$DB" | tr ',' ' '); do
  t=$(echo "$token" | xargs)
  [ -z "$t" ] && continue
  case "$t" in
    postgresql|redis|timescaledb) ;;
    *) echo "❌ db addon '$t' не поддержан (allowed: postgresql, redis, timescaledb)"; VALID=0 ;;
  esac
done

cd ..

if [ $VALID -eq 0 ]; then
  echo "⛔ Валидация brief провалилась. .tmp/ оставлен для разбора, активный project_brief/ не тронут."
  exit 1
fi
echo "✓ Валидация brief прошла"
```

Если упало — `.tmp/` остаётся на месте для inspection, оригинальный `project_brief/` (если был) — не тронут (он уже в `.bak.<ts>/` если был `RECREATE`). **Stop&Ask** с выводом ошибок. Не переходи к 4.4.

### 4.4 Atomic swap

```bash
mv project_brief.tmp project_brief
echo "✓ project_brief/ обновлён"
```

С этого момента новый brief — официальный.

---

## Шаг 5: Перенос исходников в архив

Архивируем оригиналы, **не теряем** их через collision-overwrite.

```bash
mkdir -p project_brief.raw

# Если SOURCE_DIR — это сам project_brief.raw (re-prepare кейс), нечего переносить
if [ "$(cd "$SOURCE_DIR" && pwd)" = "$(pwd)/project_brief.raw" ]; then
  echo "✓ SOURCE_DIR уже = project_brief.raw, перенос не нужен"
else
  # Используем mv -n (no-clobber): не перезаписываем существующие в архиве.
  # Включаем dotglob для hidden файлов. Ошибки НЕ глушим.
  shopt -s dotglob nullglob
  CONFLICTS=()
  for src in "$SOURCE_DIR"/*; do
    base=$(basename "$src")
    if [ -e "project_brief.raw/$base" ]; then
      CONFLICTS+=("$base")
    fi
  done
  shopt -u dotglob nullglob

  if [ ${#CONFLICTS[@]} -gt 0 ]; then
    echo "⚠ Конфликт имён в project_brief.raw/:"
    printf '  - %s\n' "${CONFLICTS[@]}"
    echo "Stop&Ask: разреши вручную (удали из архива то что устарело) и перезапусти Шаг 5."
    exit 1
  fi

  shopt -s dotglob nullglob
  mv "$SOURCE_DIR"/* project_brief.raw/
  shopt -u dotglob nullglob

  # Если SOURCE_DIR теперь пуст и это не корень — удалим
  if [ "$SOURCE_DIR" != "." ] && [ -z "$(ls -A "$SOURCE_DIR" 2>/dev/null)" ]; then
    rmdir "$SOURCE_DIR"
  fi
fi
```

**Важно:** `mv`, не `cp`. Если был git — оператор может восстановить из истории.

---

## Шаг 6: Diff и подтверждение

Покажи оператору:

```
✓ Создано:
  project_brief/business_logic.md     (XX строк)
  project_brief/technical_solutions.md (XX строк, stack: <ключ>=<значение>, ...)
  project_brief/glossary.md            (XX строк или "пропущено")
  project_brief/analysis_grey_zones.md (XX строк или "пропущено")

✓ Архивировано в project_brief.raw/:
  <список перенесённых файлов>

<если был RECREATE: ⓘ Старый brief сохранён в project_brief.bak.<ts>/ — удали когда убедишься в результате.>

Прочитай файлы — если что-то выпало или искажено, поправь руками сейчас, до /bootstrap-mvp.
```

НЕ блокируй на этом — оператор сам решает, годится или редактировать.

---

## Шаг 7: Коммит

```bash
if [ "${SKIP_GIT_COMMIT:-0}" = "1" ]; then
  echo "ℹ git skipped по выбору оператора. Перед /bootstrap-mvp инициализируй git."
else
  bash ~/.claude/playbooks/scripts/prepare-finalize.sh
fi
```

Скрипт `prepare-finalize.sh` сам:
- проверяет наличие git и user.name/email;
- стейджит только `project_brief/` + `project_brief.raw/` (никакого `-A`);
- коммитит через `-F <msg-file>` (никакого `-m "..."` в промпте — это держит `git-commit-contract` skill вне игры);
- возвращает JSON `{"committed": true, "sha": "..."}` или `{"skipped": "no-git"}`.

Не повторяй `git commit` руками — это активирует `git-commit-contract`.

---

## Финальное сообщение пользователю

```
✅ Prepare завершён.

project_brief/ готов к /bootstrap-mvp:
  - business_logic.md
  - technical_solutions.md (stack: <ключи=значения>)
  - glossary.md / analysis_grey_zones.md (если были)

Исходники сохранены в project_brief.raw/.
<если был backup: ⓘ Старый brief в project_brief.bak.<ts>/ — удали когда не нужен.>
<если git committed: ✓ Закоммичено: <sha>>
<если git skipped: ⚠ Git не инициализирован. Перед /bootstrap-mvp выполни git init.>

Следующий шаг: /clarify-mvp (закроет дыры/несостыковки), затем /bootstrap-mvp
```

---

## Anti-patterns

- НЕ удаляй исходники. Только `mv` в `project_brief.raw/`.
- НЕ выдумывай stack если его нет в исходниках или он не из allowlist. Stop&Ask.
- НЕ перезаписывай существующий `project_brief/` без Stop&Ask. Скилл сам спросит.
- НЕ зови `git-commit-contract` skill. Коммит делает `prepare-finalize.sh`, не пиши `git commit -m ...` руками.
- НЕ создавай `.claude/state/` здесь. Это работа `/bootstrap-mvp`.
- НЕ генерируй `CLAUDE.md` / `ARCHITECTURE.md`. Это работа `/bootstrap-mvp`.
- НЕ пытайся «починить» проект если Шаг 0 нашёл сигналы «уже начат». Скилл не для этого.
- НЕ создавай Tier-1 секции (`## Versions`, `## Scale`, `## Messaging`, `## Observability`, `## Background jobs`, `## Secrets`, `## Compliance`, `## CI`, `## Edge cases`, `## Integrations`). Это работа `/clarify-mvp`.
- НЕ дублируй список обязательных заголовков в коде скилла. Дергай функции из `brief-contract.sh` — это единый источник правды.
