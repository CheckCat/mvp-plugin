---
name: analyze-telemetry
description: Reads .claude/state/telemetry/*.jsonl, aggregates patterns across one or many MVP runs, and produces actionable suggestions for template updates, playbook rules, and per-stack improvements. Use after a finished run or weekly to harvest learnings.
---

# analyze-telemetry

Превращает сырые JSONL-логи в человекочитаемый отчёт с конкретными предложениями: какие шаблоны обновить, какие правила добавить в `_common.md`, на каком стеке плейбук работает хуже.

Полный контекст плейбука — `~/.claude/playbooks/mvp.md`. Формат событий — раздел "Telemetry events" в этом файле.

---

## Когда использовать

- После завершения прогона `/execute-mvp` (Halt reason ∈ {all-done, stop-and-ask, budget-cap})
- Раз в неделю если плейбук активно используется на нескольких проектах
- При подозрении что некий шаблон агента систематически фейлит

---

## Вход

Все JSONL файлы в `.claude/state/telemetry/`:

- `sessions.jsonl` — старт/стоп прогонов
- `decisions.jsonl` — Defer&Continue решения агентов
- `agent-errors.jsonl` — каждый fail имплементации, валидации или ревью
- `budget-usage.jsonl` — расход токенов и время per task
- `retries.jsonl` — каждая retry-попытка

Если хочется агрегации через несколько проектов — пользователь предоставляет список путей; иначе анализируется текущий рабочий каталог.

---

## Что измеряем

### Метрики по ролям

Для каждой роли (`backend-implementer`, `frontend-implementer`, …):
- Кол-во молекул выполнено
- Средний расход токенов на молекулу
- p50 / p90 длительность
- Доля retry (validator-fail rate, review-request-changes rate)
- Топ-3 категории ошибок (из `agent-errors.jsonl`)

### Метрики по стеку

Для каждой пары `<role, stack>`:
- Те же метрики что выше
- Сравнение со средним по роли — если конкретный стек ощутимо хуже, это сигнал что шаблон стека требует правок

### Метрики по фазам

- `bootstrap` — обычно одна сессия, измеряем только время
- `plan` — кол-во итераций планировщика до валидного DAG, размер DAG
- `execute` — % completed, average retries per task, halt reasons distribution
- `graph_refresh` — частота, среднее время, инструмент (Graphify / tree-sitter / grep-fallback)

### Финансы

- Общая стоимость прогона (`budget.spent_usd` из `plan.json` + кросс-проверка с `budget-usage.jsonl`)
- Расход по фазам (plan / execute / review / validator)
- Дельта между `estimate_tokens` и `actual_tokens` — насколько planner точен

---

## Поиск паттернов

Для каждой роли — для каждого типа ошибки:
- Если N >= 3 одинаковых fails в `agent-errors.jsonl` за последние 5 прогонов → это правило, которое стоит добавить в `_common.md` или специализированный шаблон
- Пример: 4 случая «`any` без обоснования» от `backend-implementer.nestjs` → в шаблоне уже есть это правило, но недостаточно строгое; усилить формулировку или добавить пример

Для Defer&Continue решений (`decisions.jsonl`):
- Если N >= 5 одинаковых решений с одинаковым обоснованием → это уже не decision, это паттерн, который стоит зашить как default в шаблон
- Пример: 7 раз агент выбрал `nanoid` поверх `uuid` → добавить в `_common.md`: «id-generation default — nanoid»

Для validator-failures (`retries.jsonl` с `phase: "validator"`):
- Если конкретный check (e.g. `meta_files_freshness`) фейлится чаще остальных → проблема в шаблоне роли, забывает обновлять `ARCHITECTURE.md`

Для review-request-changes:
- Если конкретная категория finding (e.g. `pattern-violation`) преобладает → шаблон роли не достаточно конкретен про существующие паттерны проекта; усилить требование «read existing patterns before writing»

---

## Output

Структурированный markdown-отчёт:

```markdown
# Telemetry report — <date range>

## Summary
- Прогонов: N
- Завершено успехом: K / N
- Средняя стоимость: $X
- Точность planner'а (actual / estimate): Y%

## Top issues

### 1. backend-implementer.nestjs — высокий validator-fail rate (32%)
**Симптом:** check `test` падает в 4 из 12 молекул.
**Причина (гипотеза):** шаблон не требует прогонять `pnpm turbo test --filter` до коммита.
**Действие:** добавить в `backend-implementer.nestjs.template.md` явный пункт в "Готов когда": "test exit code 0 в локально перед summary".

### 2. code-reviewer часто возвращает pattern-violation для имён переменных
**Симптом:** 8 findings за 3 прогона, все про CamelCase vs snake_case в одной кодбазе.
**Причина:** шаблоны не извлекают naming conventions из существующего кода.
**Действие:** добавить в `_common.md` правило: "read 2-3 ближайших файла того же типа и следуй именованию".

### 3. graphify-refresh занимает 18% времени execute-фазы
**Симптом:** среднее `ms` на `graph_refresh` = 4500ms × 20 refreshes = 90s на прогон.
**Причина:** lazy invalidation работает, но многие задачи трогают один и тот же сервис → постоянный rebuild.
**Действие:** инкрементальный rebuild — пересчитывать только узлы изменённых файлов. Открыть issue в `refresh-graph`.

## Per-role breakdown
[таблица: role / molecules / avg-tokens / fail-rate / top-error]

## Per-stack breakdown
[таблица: stack / molecules / fail-rate / delta-vs-avg]

## Decisions worth promoting to defaults
[список Defer&Continue которые встречаются >= 5 раз]

## Open questions
[всё что выглядит подозрительно но не доказано — для ручного разбора]
```

---

## Telemetry events (контракт)

JSONL-схема для каждого файла. Все события всегда содержат `ts` (ISO8601) и `playbook_run_id` (UUID прогона из `sessions.jsonl`).

### `sessions.jsonl`
```json
{"event": "session_start", "playbook": "mvp", "playbook_run_id": "<uuid>", "stack": "nestjs+nextjs", "ts": "..."}
{"event": "session_end", "playbook_run_id": "<uuid>", "halt_reason": "all-done|stop-and-ask|budget-cap|user-interrupt|dag-stuck", "completed": K, "total": N, "spent_usd": X, "ts": "..."}
```

### `decisions.jsonl`
```json
{"event": "decision", "playbook_run_id": "<uuid>", "task_id": "task-007", "role": "backend-implementer", "choice": "use nanoid for id-gen", "why": "shorter, URL-safe, no extra dep", "ts": "..."}
```

### `agent-errors.jsonl`
```json
{"event": "agent_error", "playbook_run_id": "<uuid>", "task_id": "task-007", "role": "backend-implementer", "phase": "implement|validate|review", "retry_count": 1, "error_class": "lint_fail|build_fail|test_fail|diff_mismatch|review_request_changes|stop_and_ask", "details": "first 200 chars of error", "ts": "..."}
```

### `budget-usage.jsonl`
```json
{"event": "task_complete", "playbook_run_id": "<uuid>", "task_id": "task-007", "role": "backend-implementer", "tokens": 18420, "ms": 92000, "ts": "..."}
{"event": "graph_refresh", "playbook_run_id": "<uuid>", "tool": "graphify@0.2.1", "files_scanned": 142, "nodes": 380, "edges": 612, "ms": 4500, "ts": "..."}
```

### `retries.jsonl`
```json
{"event": "retry", "playbook_run_id": "<uuid>", "task_id": "task-007", "phase": "validator|review", "attempt": 2, "reason": "test_fail|diff_mismatch|request-changes", "ts": "..."}
```

---

## Anti-patterns

- НЕ собирай в `budget-usage.jsonl` per-token расход — мы не можем точно знать. Только агрегированные `tokens` из `budget.spent()` per task. Точность ±10% — это OK.
- НЕ выдавай выводы которых нет в данных. Если N < 3 одинаковых fails — это шум, не паттерн. Не предлагай менять шаблоны.
- НЕ предлагай «общие улучшения» без числа из telemetry. Каждое предложение должно иметь привязку к конкретной метрике.
- НЕ пиши в `decisions.jsonl` каждый чих агента. Только реально принятые Defer&Continue решения с обоснованием.
- НЕ агрегируй telemetry из проектов с разных аккаунтов / разных пользователей без явного разрешения. Это локальные логи.
