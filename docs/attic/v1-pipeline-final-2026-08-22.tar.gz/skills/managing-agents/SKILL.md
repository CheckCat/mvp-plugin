---
name: managing-agents
description: Use when about to start a task that spans multiple independent services, components, or workstreams — before any multi-agent implementation begins. Also use when unsure whether a task warrants parallel agents at all.
---

# Managing Agents

## Overview

Actualize the agent pool, then dispatch. Never dispatch agents that are missing, stale, or too broad. This skill ensures agents are fit-for-purpose before any Workflow runs.

## When to Use

```dot
digraph when {
    "Task involves multiple services or components?" [shape=diamond];
    "Could specialized agents help?" [shape=diamond];
    "Single agent is fine" [shape=box];
    "Run managing-agents" [shape=box];

    "Task involves multiple services or components?" -> "Run managing-agents" [label="yes"];
    "Task involves multiple services or components?" -> "Could specialized agents help?" [label="no"];
    "Could specialized agents help?" -> "Run managing-agents" [label="yes"];
    "Could specialized agents help?" -> "Single agent is fine" [label="no"];
}
```

**Use when:**
- Task touches 2+ independent services/modules
- Parallel implementation would speed things up
- You're about to call the Workflow tool

**Don't use when:**
- Task is a simple bug fix or single-file change
- You need interactive back-and-forth to explore the problem first

---

## Phase 1: Agent Pool Actualization

### 1.1 Determine needed roles

Analyze the task. For each independent workstream, name the role needed (not the task — the role):

- `backend-implementer` — implements backend services/APIs
- `frontend-implementer` — implements UI components and pages
- `integration-specialist` — connects services, OAuth, third-party APIs
- `test-writer` — writes unit and integration tests
- `code-reviewer` — reviews for SOLID, DRY, KISS, security
- `devops-engineer` — CI/CD, Docker, deployment, server config
- `refactoring-specialist` — restructures existing code without changing behavior
- `debugger` — investigates and fixes bugs

Add new roles if none of the above fit.

### 1.2 Compare with existing pool

Read agent files:
```bash
ls ~/.claude/agents/     # global roles
ls .claude/agents/       # project-specific roles (if dir exists)
```

For each needed role, determine status:
- **Missing** → create
- **Exists, sufficient** → use as-is
- **Exists, insufficient** → update description/tools
- **Exists, too broad** → split (see 1.3)

### 1.3 Split threshold (LLM judgment)

Split an agent when its description requires "AND" between unrelated domains:
> "implements backend services AND manages deployments AND writes frontend components"

This is too broad. Split into `backend-implementer` + `devops-engineer` + `frontend-implementer`.

**Cohesion test:** Ask — "Could a human specialist in this role reasonably do all these things?" If no → split.

### 1.4 Agent file format

```markdown
---
name: role-name
description: One sentence: what this agent does and its core principle
tools: Read, Edit, Write, Bash
---

You are a [role]. Your responsibilities:
- [Core responsibility 1]
- [Core responsibility 2]

Principles you always follow:
- [Principle: e.g. SOLID, KISS, test-after-implement]
- [Principle: read existing patterns before writing new code]

You do NOT:
- [Out-of-scope item]
- [Out-of-scope item]

Done when:
- [Criterion 1: what must be verified before finishing]
- [Criterion 2]
```

**Global vs project:** 
- Global (`~/.claude/agents/`) — generic roles reusable across any project
- Project (`.claude/agents/`) — only if role is domain-specific enough to be useless outside this project

Default to global. Create a project agent only when it would make no sense elsewhere.

---

## Phase 2: Build and Show Plan

After actualizing agents, build the dispatch plan and **show it to the user before running anything**.

Format:
```
Агенты актуализированы. Вот план:

Phase 1 — Plan (1 агент)
  → planner: декомпозирует задачу, определяет зависимости

Phase 2 — Implement (параллельно, worktree isolation)
  → backend-implementer: [конкретная задача из текущего запроса]
  → integration-specialist: [конкретная задача]

Phase 3 — Verify
  → code-reviewer: SOLID/DRY/KISS + security проверка
  → test-writer: тесты для нового кода

Запускаем?
```

Wait for confirmation before proceeding.

---

## Phase 2.5: Checkpoint Protocol

**Every implementation batch must pass a checkpoint before the next batch begins.**

A checkpoint is a blocking gate — if it fails, the workflow stops and the failure is fixed before continuing.

### What a checkpoint checks

```bash
pnpm turbo lint    # must be zero errors (warnings OK)
pnpm turbo build   # must succeed
pnpm turbo test    # must pass
```

These commands must be **identical** to what CI runs. If they diverge, fix the divergence first.

### How to implement in Workflow script

```javascript
const checkpoint = async (label) => {
  const result = await agent(`
    Run verification for checkpoint "${label}":
    1. pnpm turbo lint --filter=<changed packages>
    2. pnpm turbo build --filter=<changed packages>
    3. pnpm turbo test --filter=<changed packages>
    
    Report: pass/fail per step. If any step fails, list the exact errors.
    Return { passed: boolean, errors: string[] }
  `, { schema: CHECKPOINT_SCHEMA, label: `checkpoint:${label}` })
  
  if (!result.passed) {
    log(`❌ Checkpoint "${label}" FAILED: ${result.errors.join(', ')}`)
    throw new Error(`Checkpoint failed — fix errors before proceeding`)
  }
  log(`✅ Checkpoint "${label}" passed`)
}

// Usage between batches:
phase('Implement — Batch 1')
await parallel([...batch1agents])
await checkpoint('batch-1')   // ← blocking gate

phase('Implement — Batch 2')
await parallel([...batch2agents])
await checkpoint('batch-2')   // ← blocking gate
```

### Checkpoint failure = stop everything

Do not skip. Do not mark as "warning". Do not proceed to the next batch.

Fix the failure in the same session, then re-run the checkpoint.

---

## Phase 3: Launch Workflow

After confirmation, build and call the Workflow tool.

### Context injection pattern

Agent files define the **role** (generic). The Workflow prompt provides the **task context** (specific):

```javascript
phase('Implement')
await parallel([
  () => agent(`
    [Роль: backend-implementer — читай .claude/agents/backend-implementer.md]
    
    Задача: реализуй Scheduler Service.
    
    Контекст:
    ${businessLogic}   // читается из project_brief/ если есть
    ${glossary}        // читается из glossary.md если есть
    
    Требования:
    - Файлы: src/services/scheduler/
    - Тесты: src/services/scheduler/__tests__/
    - Не трогай другие сервисы
  `, { isolation: 'worktree', label: 'scheduler' }),
  
  () => agent(`...`, { isolation: 'worktree', label: 'integration' })
])
```

**Key principle:** Agent file = role definition (reusable). Workflow prompt = specific context (generated per task). Never bake project context into agent files.

### Standard phases

```javascript
export const meta = {
  name: 'task-name',
  description: 'task description',
  phases: [
    { title: 'Plan' },
    { title: 'Implement' },
    { title: 'Verify' }
  ]
}

phase('Plan')
const plan = await agent('Analyze task and decompose into independent workstreams. Return JSON with {workstreams: [{name, files, description}]}', { schema: PLAN_SCHEMA })

phase('Implement')
await parallel(plan.workstreams.map(ws => () =>
  agent(`[role context]\n\nTask: ${ws.description}\nFiles: ${ws.files.join(', ')}`,
    { isolation: 'worktree', label: ws.name })
))

phase('Verify')
await agent('Run linters and tests. Fix any failures. Report results.')
```

---

## Common Mistakes

| Mistake | Fix |
|---|---|
| Baking project context into agent file | Project context goes in Workflow prompt, not agent file |
| Creating project agent for generic role | Default to `~/.claude/agents/`, not `.claude/agents/` |
| Dispatching without showing plan | Always show plan and wait for confirmation |
| Running agents without `isolation: 'worktree'` when they edit files | Parallel file-editing agents MUST use worktree isolation |
| One giant agent for everything | One agent = one cohesive role |
