---
name: plan-mvp
description: Use after /bootstrap-mvp. Reads project_brief and generated meta-files, runs a planner agent to produce plan.json (DAG of tasks) and PROJECT_PLAN.md.
---

# plan-mvp

Второй шаг плейбука MVP. Превращает текстовое описание проекта в исполняемый DAG задач.

Полный контекст плейбука — `~/.claude/playbooks/mvp.md`. План имплементации плейбука и формат `plan.json` — `~/.claude/plans/mvp-playbook.md`.

---

## Когда использовать

- `/bootstrap-mvp` уже выполнен — есть `CLAUDE.md`, `ARCHITECTURE.md`, `.claude/agents/`
- Файл `.claude/state/plan.json` ещё НЕ существует
- `.claude/state/current-task.json` содержит `"phase": "bootstrap-complete"`

Если эти условия не выполнены — Stop&Ask.

---

## Что делает

0. Pre-flight check
1. Собирает компилированный вход для planner-агента
2. Запускает planner — отдельный агент, его ответственность — построить DAG
3. Валидирует структуру `plan.json` против JSON-схемы
4. Генерирует `PROJECT_PLAN.md` (markdown-view)
5. Обновляет `current-task.json`
6. Делает коммит

---

## Шаг 0: Pre-flight check

```bash
MISSING=0
for cmd in bash python3 node git; do
  command -v $cmd >/dev/null 2>&1 || { echo "❌ $cmd не установлен"; MISSING=1; }
done
test $MISSING -eq 0 || { echo "Установи перечисленное и повтори /plan-mvp"; exit 1; }

git rev-parse --git-dir >/dev/null 2>&1 || { echo "❌ Не в git-репозитории"; exit 1; }

test -d .claude/agents && [ -n "$(ls .claude/agents/*.md 2>/dev/null)" ] || { echo "❌ .claude/agents/ пуст или отсутствует — сначала /bootstrap-mvp"; exit 1; }
test ! -f .claude/state/plan.json || { echo "❌ plan.json уже существует — используй /continue-mvp"; exit 1; }
```

---

## Шаг 0.5: Рефреш графа кодовой базы

Перед сбором входа для planner'а — обнови `.claude/state/graphify.json`:

```
Вызови скилл refresh-graph.
```

Это гарантирует что planner видит актуальные интерфейсы уже существующего кода (например, если плейбук стартует на полу-готовом проекте или после `bootstrap-mvp` который уже создал что-то).

Если репозиторий ещё пуст (только мета-файлы) — `refresh-graph` создаст граф с `nodes: []`. Это нормально.

## Шаг 1: Компиляция входа

Прочитай и склей в один контекст для planner'а:
- Все файлы из `project_brief/`
- `CLAUDE.md`, `ARCHITECTURE.md`
- Список сгенерированных проектных ролей: `ls .claude/agents/*.md`
- **Сводку из `graphify.json`** — только список существующих сервисов и кол-во публичных экспортов по каждому. НЕ передавай весь граф planner'у; полный субграф будет инжектиться agent'у-исполнителю под конкретную задачу в `execute-mvp`

---

## Шаг 2: Запуск planner-агента

Дёрни Agent tool с `subagent_type: Plan` (встроенный архитектор) и таким промптом:

```
Ты — архитектор MVP. На основе предоставленных документов построй DAG задач.

Принципы декомпозиции:
- **Атом** — изменение одного поля/метода/функции. Не используй в плане.
- **Молекула** — целая фича внутри одного сервиса (модуль, контроллер, миграция). Помещается в одно контекстное окно одного агента (≤ 25k токенов).
- **Организм** — целый сервис или кросс-сервисное взаимодействие. Разбивай на молекулы.

## Service boundary правила (HARD)

`service_path` — единственный hard gate validator'а (Check 5: `staged_relevant ⊆ service_boundary`). Несоблюдение → валидатор валит каждую затронутую задачу.

- **Все `files` задачи ДОЛЖНЫ быть внутри `service_path`** (быть им или его потомками).
- **ОДНА ЗАДАЧА = ОДИН `service_path`.** Если задача создаёт артефакты в разных сервисах — разбей на отдельные молекулы.
  - Антипример: `files: [services/api/pyproject.toml, services/worker/pyproject.toml, services/beat/pyproject.toml]` под одним `service: api`. Это нарушение в 2 файлах из 3. Правильно: три молекулы, каждая своему сервису.
- **Cross-cutting артефакты** (корневые tooling-configs, docker-compose, `.github/`, `deploy/`, `tests/` в корне репо) → `service: "root", service_path: "."`. Это штатный механизм, `execute-mvp` его поддерживает. **Не имитируй boundary, проставляя cross-cutting задачу под случайный сервис.**
  - Категории cross-cutting:
    - корневые tooling-configs (`pyproject.toml` корневой, `ruff.toml`, `mypy.ini`, `pytest.ini`, `package.json` workspace root)
    - `docker-compose.yml`, `docker-compose.override.yml`, `.env.example`
    - `.github/workflows/*`
    - `deploy/*` (Dokploy compose, env templates, README про секреты)
    - `tests/integration/*` (если convention — тесты в корне репо)

## Архитектурные инварианты, которые planner ОБЯЗАН уважать

Эти инварианты определяют граф зависимостей. Игнорировать = создавать ложные `depends_on` и shared-code конфликты.

**A. Modular monolith — shared domain package**
- `services/api/app/` (или эквивалент основного backend-сервиса) — Python package со всеми доменными модулями.
- `services/worker/`, `services/beat/` — entry points; импортируют доменные сервисы из api через editable install (`pip install -e ../api`).
- Domain code живёт ровно в ОДНОМ месте — в api. Worker НЕ дублирует.
- Следствие: pyproject `worker` `depends_on` pyproject `api`.
- Следствие: Celery saga в `services/worker/app/tasks/` вызывает доменные сервисы из api, не дублирует логику.

**B. Integration workers — stateless HTTP gateway**
- `services/integration-*` (`integration-tiktok`, `integration-youtube` и т.п.) НЕ имеют доступа к БД.
- НЕ имеют CryptoAdapter, НЕ имеют доменных моделей.
- Контракт: принимают `access_token`/`refresh_token` plain в request body, возвращают результат и (опц.) новые токены.
- api/worker оркеструет: достал токен → передал в integration → получил → перешифровал → сохранил.
- **Следствие: integration-задачи НЕ зависят от CryptoAdapter, доменных моделей api и базовых миграций.** Их единственная backend-зависимость — собственный pyproject.
- ARCHITECTURE.md может содержать legacy mermaid с прямым DB-доступом integration — это **баг bootstrap-агента**, не контракт. Игнорируй и не повторяй.

**C. CryptoAdapter — единственная точка крипты, живёт в api**
- Не дублировать в integration, не выносить в отдельную shared lib.
- Все обращения к шифрованию OAuth-токенов / API-ключей — через CryptoAdapter в api.

## Поля задачи

- id (task-NNN)
- title (одно предложение)
- level: "molecule" | "organism"
- service: имя сервиса ИЛИ `"root"` для cross-cutting (см. правила выше)
- service_path (ОБЯЗАТЕЛЬНО): relative путь к корню сервиса. Для `service: root` → `"."`. Иначе:
  - FastAPI single-app: `app`
  - microservices: `services/<service>`
  - Next.js apps в Nx monorepo: `apps/<service>`
  - pnpm-monorepo: `packages/<service>` (fallback)
- role: имя проектного агента (из .claude/agents/*.md)
- files: ключевые файлы которые задача создаёт/меняет — **HINT для наблюдаемости и subgraph extraction, НЕ exhaustive contract**. Все files ДОЛЖНЫ быть ⊆ service_path.
- depends_on: массив id задач которые должны быть выполнены до
- blocks: массив id задач которые ждут эту
- estimate_tokens: грубая оценка (10000-25000 для молекулы)
- status: "pending"
- **complexity_class**: семантический тип задачи (см. ниже) — определяет какую модель получит implement-агент
- **complexity_rationale**: одно предложение, почему именно этот класс (для аудита/отладки plan'а)

**complexity_class — таксономия (обязательно для каждой задачи):**

| Класс | Что это | Признаки |
|---|---|---|
| `boilerplate` | Скаффолд по канону. Решений ноль — только write file по template'у. | Конфиги (`.prettierrc`, `tsconfig`, `eslint`), init фреймворка (`nest new`, `next init` + shadcn), Dockerfile по официальному образцу. Implementer должен знать актуальные версии и идиомы — но НЕ изобретать. |
| `follow-pattern` | Воспроизведение существующего паттерна. Есть готовый пример в репо ИЛИ канонический паттерн стэка. | Новый CRUD-модуль по образцу другого; новая страница по образцу другой; копия `AuthModule` → `HealthModule`; стандартный Zod-контракт; добавление endpoint в существующий паттерн. |
| `novel-design` | Новые решения, нет готового примера. | Первая интеграция библиотеки (Prisma в pnpm, Auth-Guard в проекте), нетривиальные TypeScript-типы (generics, decorator metadata edge cases), архитектурные решения (DI, выбор паттерна), нестандартные edge cases (concurrency, transactions). |

**Как выбирать:**
1. Если в репо уже есть похожий код — это **follow-pattern**, даже если файлов 5+.
2. Если задача = заполнить N конфигов по канону — это **boilerplate**, даже если файлов 10+.
3. Если задача требует выбора между подходами / типовых решений нет / типы нетривиальны — это **novel-design**.

Принцип безопасности: **в сомнительных случаях → `novel-design`** (Opus). Цена ошибки в обратную сторону (Sonnet для реально сложной задачи) — провал validator/review и retry. Цена `novel-design` для simple — потеря ~$2/задача. Asymmetric: сомнения → escalate.

**НЕ ориентируйся на `files.length` или `estimate_tokens`** при выборе класса. Объём ≠ сложность мышления. task-001 (11 файлов конфигов) — `boilerplate`. task-005 (3 файла Guard'а) — `novel-design`.

**Семантика `files`:**
- Перечисляй ключевые artefact-файлы которые отражают суть задачи (модули, сервисы, контроллеры, главные конфиги, миграции с понятным именем)
- НЕ пытайся перечислить вспомогательные файлы которые implementer создаст сам в рамках DoD своей роли:
  - `*.spec.ts` / `*.test.ts` / `tests/` — backend/frontend implementer сам решает где они нужны
  - `*.dockerignore`, lock-файлы внутри package — devops/implementer добавит при необходимости
  - вспомогательные barrel-файлы `index.ts`
- Validator проверяет что staged файлы НЕ ВЫХОДЯТ за `packages/<service>/**`, а НЕ что они точно совпадают с `files`. Поэтому overlist'ить `files` спеками — лишнее, underlist — тоже не страшно

## Фазы и обязательные задачи

Разбей план на фазы. Внутри bootstrap-infra и frontend есть обязательные задачи, которые planner не должен пропускать.

**Фаза 1: bootstrap-infra**
- root tooling-configs (`pyproject.toml` корневой, `ruff.toml`, `mypy.ini`, `pytest.ini`) → `service: root`, role: devops, complexity: boilerplate. ОДНА молекула.
- per-service pyproject — **ОТДЕЛЬНАЯ молекула на каждый backend-сервис** (`api`, `worker`, `beat`, и каждый `integration-*`). Запрещено батчить.
- per-service Dockerfile — **ОТДЕЛЬНАЯ молекула на каждый сервис**. Альтернатива: один organism с `service: root, service_path: "."` если Dockerfile-ы идентичны по шаблону.
- frontend `package.json` + Vite + tsconfig → `service: frontend`
- frontend Tailwind + shadcn init + базовые UI primitives (Button/Input/Card/Dialog) → `service: frontend`, отдельная молекула, complexity: boilerplate
- frontend Dockerfile (Vite build + nginx) → `service: frontend`
- `docker-compose.yml` + `.env.example` → `service: root`
- `.github/workflows/ci.yml` → `service: root`
- Dokploy compose template → `service: root`

**Фаза 2: foundation** — shared lib, миграции, базовый app skeleton, observability, CryptoAdapter, Celery skeleton. Каждая внутри своего сервиса.

**Фаза 3: adapters** — GeneratorAdapter, LLMAdapter (если есть в стеке) — внутри api package.

**Фаза 4: services-api** — доменные модули по молекуле каждый.

**Фаза 5: integrations** — задачи для каждого `services/integration-*`. Помни инвариант B: integration-задачи зависят ТОЛЬКО от собственного pyproject. Никаких CryptoAdapter / доменных моделей / миграций.

**Фаза 6: frontend** (расширенная под требования frontend-implementer template'а)
- skeleton + routing + API client + auth context
- auth flow (login/register/refresh)
- accounts + OAuth connect UI
- strategies CRUD
- cycles dashboard
- settings (API keys)
- **frontend unit test setup (Vitest + RTL + msw) — ОБЯЗАТЕЛЬНО**
- **frontend e2e setup (Playwright + smoke flow) — ОБЯЗАТЕЛЬНО**

Если шаблон `frontend-implementer.*.template.md` требует Vitest/RTL/Playwright (как React+Vite template) — planner должен включить соответствующие test-setup задачи. Не «backend test-writer покроет всё».

**Фаза 7: integration-tests** — pytest+testcontainers e2e для backend. `service: root, service_path: "."` если тесты в корне репо.

**Фаза 8: deploy** — финализация Dokploy compose, env-vars template, healthcheck verification. `service: root`.

Дополнительно:
- Зависимости должны образовать корректный DAG без циклов.
- Используй роли из .claude/agents/. Не выдумывай новые.

Верни JSON, валидный против схемы plan.json (см. ~/.claude/plans/mvp-playbook.md, раздел "Формат plan.json").
```

Передай ему `schema: PLAN_SCHEMA` (см. ниже).

---

## Шаг 3: Валидация plan.json

После того как planner вернул JSON:

**Базовые проверки:**
- `tasks[]` непуст
- для каждого `depends_on` есть соответствующий id
- DAG ацикличен (топологическая сортировка проходит)
- все `role` из задач существуют как файлы в `.claude/agents/`
- в каждой задаче `level` ∈ {"molecule", "organism"}

**Boundary check (HARD):**
```python
for t in tasks:
    sp = t.get('service_path') or f"packages/{t['service']}"
    if sp == '.':
        continue  # root — boundary не ограничивает
    for f in t['files']:
        if not (f == sp or f.startswith(sp.rstrip('/') + '/')):
            errors.append(f"{t['id']}: file {f} вне service_path {sp}")
```

**Integration-* инвариант (Инвариант B из промпта planner'а):**
```python
crypto_ids = {t['id'] for t in tasks
              if 'crypto' in t['title'].lower()
              or 'CryptoAdapter' in t.get('complexity_rationale','')}
for t in tasks:
    if t['service'].startswith('integration-'):
        bad = [d for d in t['depends_on'] if d in crypto_ids]
        if bad:
            errors.append(f"{t['id']}: integration не должен зависеть от crypto {bad}")
```

**Frontend test/UI setup (если frontend в стеке):**
```python
fe_tasks = [t for t in tasks if t['service'] == 'frontend']
if fe_tasks:
    titles = ' '.join(t['title'].lower() for t in fe_tasks)
    if not any(k in titles for k in ('vitest', 'rtl', 'unit test')):
        errors.append("missing frontend unit test setup task (Vitest/RTL)")
    if not any(k in titles for k in ('playwright', 'e2e')):
        errors.append("missing frontend e2e test setup task (Playwright)")
    if not any(k in titles for k in ('shadcn', 'tailwind', 'ui primitive')):
        errors.append("missing frontend Tailwind/shadcn init task")
```

**Role compatibility (test-writer stack):**
```python
# test-writer.<backend>.template.md (fastapi / nestjs) — pytest или jest.
# Frontend-тесты (Vitest, RTL, Playwright) пишет frontend-implementer:
# его template уже требует эти инструменты. Назначить test-writer на
# service: frontend = implementer провалится (будет писать pytest для TS).
for t in tasks:
    if t['role'] == 'test-writer' and t['service'] == 'frontend':
        errors.append(f"{t['id']}: test-writer не покрывает frontend; "
                      f"frontend-тесты пишет frontend-implementer (его template "
                      f"требует Vitest/RTL/Playwright)")
```

Если валидация падает — дай агенту фидбек и попроси переработать (максимум 2 итерации, потом Stop&Ask).

**Топ-уровневые поля + динамический budget:**

```python
novel = sum(1 for t in tasks if t.get('complexity_class') == 'novel-design')
simple = sum(1 for t in tasks if t.get('complexity_class') in ('boilerplate', 'follow-pattern'))
# avg per task с MODEL_FOR (Opus / Sonnet / Sonnet validate+review):
#   novel-design ≈ $1.7, simple ≈ $0.4
# +30% buffer на retry/escalation
raw = (novel * 1.7 + simple * 0.4) * 1.3
budget_usd = max(50, round(raw / 10) * 10 + 10)  # минимум $50, округление вверх до 10 + buffer 10
```

```json
{
  "version": "1.0",
  "playbook": "mvp",
  "stack": "<backend>+<frontend>+<deploy>",
  "created_at": "<ISO8601>",
  "updated_at": "<ISO8601>",
  "budget": {
    "total_usd": <budget_usd>,
    "spent_usd": 0,
    "hard_cap": true
  },
  "current_focus": "<id первой задачи без зависимостей>",
  "completed_count": 0,
  "total_count": <длина tasks[]>
}
```

`stack` — строка вида `nestjs+nextjs+docker-dokploy` или `fastapi+react+docker-dokploy`. Считай из `project_brief/technical_solutions.md` секции `## Stack`. Используется в `/execute-mvp` для stack-specific prereq checks (pnpm/ruff/pytest).

Сохрани в `.claude/state/plan.json`.

---

## Шаг 4: Генерация PROJECT_PLAN.md

Сгенерируй человекочитаемый view DAG:

```markdown
# Project Plan — <название>

Автогенерация из `.claude/state/plan.json`. **Не редактируй вручную** — правки потеряются. Меняй `plan.json` напрямую.

## Прогресс
- Всего задач: N
- Выполнено: 0 / N
- Бюджет: $0 / $<budget_usd>

## Фазы

### Phase: foundation
- [ ] task-001 — Создать Prisma-схему auth-service (backend-implementer)
- [ ] task-002 — ...

### Phase: services
- [ ] task-010 — ...

## Граф зависимостей
\`\`\`mermaid
graph TD
  task-001 --> task-005
  task-002 --> task-005
  ...
\`\`\`
```

---

## Шаг 5: Обновление current-task.json

```json
{
  "phase": "plan-complete",
  "next_command": "/execute-mvp",
  "current_focus": "<id первой задачи>",
  "updated_at": "<ISO8601>"
}
```

---

## Шаг 6: Коммит

`git-commit-contract`. Сообщение:
```
chore: plan MVP DAG

- Generated plan.json with N tasks across M phases
- PROJECT_PLAN.md view for manual review
```

---

## Финальное сообщение пользователю

```
✅ План построен.

Задач: N
Фаз: M (foundation, services, integration, deploy)
Бюджет: $<budget_usd> hard cap (рассчитан по complexity counts)

Прочитай PROJECT_PLAN.md и при нужде поправь .claude/state/plan.json.

Следующий шаг: /execute-mvp
```

---

## PLAN_SCHEMA (для structured output)

```json
{
  "type": "object",
  "required": ["tasks"],
  "properties": {
    "tasks": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["id", "title", "level", "service", "role", "files", "depends_on", "estimate_tokens", "status", "complexity_class", "complexity_rationale"],
        "properties": {
          "id": {"type": "string", "pattern": "^task-\\d{3,}$"},
          "title": {"type": "string"},
          "level": {"enum": ["molecule", "organism"]},
          "service": {"type": "string"},
          "service_path": {"type": "string", "description": "Опционально. Relative путь к корню сервиса. Fallback на packages/<service>."},
          "role": {"type": "string"},
          "files": {"type": "array", "items": {"type": "string"}},
          "depends_on": {"type": "array", "items": {"type": "string"}},
          "blocks": {"type": "array", "items": {"type": "string"}},
          "estimate_tokens": {"type": "integer", "minimum": 1000, "maximum": 50000},
          "status": {"enum": ["pending"]},
          "complexity_class": {"enum": ["boilerplate", "follow-pattern", "novel-design"]},
          "complexity_rationale": {"type": "string"}
        }
      }
    }
  }
}
```

---

## Anti-patterns

- НЕ позволяй planner'у создавать атомы в плане. Молекула — минимальная единица.
- НЕ принимай план без проверки DAG-ацикличности.
- НЕ дублируй задачи между фазами.
- НЕ зашивай в задачу больше чем одно контекстное окно агента (estimate_tokens > 25000 — разбей).
- НЕ выдумывай новые роли. Только то что есть в `.claude/agents/`.
- НЕ предугадывай в `files` спеки/миграции/dockerignore/lock-файлы — это implementer's call внутри service boundary. Перечисление этого здесь создаёт contract drift между planner и validator (один из источников fix-validator loop'ов в прошлых прогонах).
- НЕ путай `service` и `files`. `service` — hard boundary (validator gate). `files` — hint для subgraph и наблюдаемости.
- **НЕ объединяй артефакты разных сервисов в одну молекулу** (batched bootstrap). Каждый сервис — свой service_path; cross-cutting → `service: root, service_path: "."`. Реальный кейс из прошлого прогона: task-001 имел files для api+worker+beat под `service: api` — validator Check 5 валит каждый файл вне `services/api/`.
- **НЕ ставь `integration-*` в зависимость от CryptoAdapter, доменных моделей api или миграций.** Они stateless HTTP gateway (Инвариант B). Их единственная backend-зависимость — собственный pyproject. ARCHITECTURE.md может содержать legacy mermaid с прямым DB-доступом — это **баг bootstrap**, не контракт.
- **НЕ забывай frontend test/UI setup задачи**, если шаблон `frontend-implementer.*` требует Vitest+RTL+Playwright+shadcn (React+Vite template — требует). Без них фаза frontend проваливает валидацию.
- **НЕ назначай `test-writer` на `service: frontend`.** Шаблон test-writer привязан к pytest (FastAPI) или jest (NestJS), он не умеет Vitest/Playwright. Frontend-тесты пишет `frontend-implementer` — его шаблон уже включает Vitest+RTL+Playwright. Реальный кейс v2: planner проставил test-writer на frontend Vitest+Playwright задачи, validator завалил бы их немедленно.
- **НЕ захардкоживай `budget.total_usd`**. Считай по complexity counts: `(novel × 1.7 + simple × 0.4) × 1.3`, минимум $50.
