---
name: continue-mvp
description: Use to resume an MVP playbook run from a cold context (new session, after compact/clear, or after user interrupted execution). Reads .claude/state/, decides next action (resume execute, ask for blocker resolution, or warn), then dispatches.
---

# continue-mvp

Точка восстановления плейбука. Запускается из пустого контекстного окна, читает `.claude/state/`, понимает на каком этапе остановилась работа, решает что делать дальше.

Полный контекст плейбука — `~/.claude/playbooks/mvp.md`. Состояния и переходы — `~/.claude/plans/mvp-playbook.md`.

---

## Когда использовать

- Сессия Claude Code только что начата (или после `/compact`, `/clear`)
- Существует `.claude/state/plan.json` (значит плейбук уже стартовал)
- Нужно продолжить с того места где остановились

Если `.claude/state/plan.json` отсутствует — это первый запуск, направь пользователя на `/bootstrap-mvp`.

---

## Что делает

0. Pre-flight check
1. Читает `.claude/state/current-task.json` — определяет `phase` и `next_command`
2. Читает `.claude/state/plan.json` — узнаёт прогресс
3. Читает `.claude/state/blockers.md` — есть ли активные Stop&Ask
4. Проверяет `.claude/state/user-interrupt.md` — есть ли активный interrupt
5. Принимает решение: запустить execute, попросить разрешить блокер, или сообщить о завершении

---

## Шаг 0: Pre-flight check

```bash
MISSING=0
for cmd in bash python3 node git; do
  command -v $cmd >/dev/null 2>&1 || { echo "❌ $cmd не установлен"; MISSING=1; }
done
test $MISSING -eq 0 || { echo "Установи перечисленное и повтори /continue-mvp"; exit 1; }
git rev-parse --git-dir >/dev/null 2>&1 || { echo "❌ Не в git-репозитории"; exit 1; }
```

Дальше скилл сам читает state-файлы (Шаг 1) и реагирует на их отсутствие в Шаге 2 (направляет на /prepare-mvp или /bootstrap-mvp).

---

## Шаг 1: Сбор состояния

```bash
test -f .claude/state/current-task.json || echo "NO_STATE"
test -f .claude/state/plan.json || echo "NO_PLAN"
test -f .claude/state/blockers.md && cat .claude/state/blockers.md
test -f .claude/state/user-interrupt.md && cat .claude/state/user-interrupt.md
```

---

## Шаг 2: Решение о следующем шаге

| Состояние | Действие |
|---|---|
| Нет `plan.json` | Сказать "Плейбук не инициализирован, вызови `/bootstrap-mvp`" |
| Нет `current-task.json` но есть `plan.json` | Восстановить `current-task.json` из `plan.json` (статус → in-progress, current_focus → первая pending без deps) |
| `phase: "bootstrap-complete"` | Сказать "Bootstrap готов, вызови `/plan-mvp`" |
| `phase: "plan-complete"` или `"in-progress"`, есть `user-interrupt.md` | Сказать "Активный interrupt. Удали `.claude/state/user-interrupt.md` и повтори `/continue-mvp`" |
| Есть активные `stop-and-ask` блокеры в `blockers.md` | Показать блокеры пользователю, попросить ответы, ждать |
| `phase: "plan-complete"` или `"in-progress"`, блокеров нет | Запустить `execute-mvp` |
| `completed_count == total_count` | Сказать "🎉 Все задачи выполнены. Следующее — проверка деплоя." |

---

## Шаг 3: Резюме контекста для пользователя

Перед тем как делать что-либо ещё, выведи краткое резюме:

```
📌 Resuming MVP playbook

Прогресс: <N> / <M> задач
Текущий фокус: <current_focus> — <title>
Бюджет: $<spent> / $<total>
Последнее обновление: <updated_at>

<если есть блокеры — список с пометкой>
<если есть interrupt — указание>
<решение что делаю дальше>
```

Это даёт пользователю мгновенную ситуационную осведомлённость без необходимости лезть в файлы вручную.

---

## Шаг 4: Действие

В зависимости от решения из Шага 2:

- **Stop&Ask активен** → не запускать execute. Ждать ответа пользователя в текущей сессии. Когда пользователь ответил — занеси его решение в `decisions.log`, очисти соответствующую запись в `blockers.md`, обнови `plan.json` (статус задачи → pending), затем вызови `execute-mvp`.
- **Interrupt активен** → не запускать execute. Сказать что нужно сделать чтобы продолжить.
- **Готов исполнять** → вызови скилл `execute-mvp`.
- **Bootstrap не завершён** → сказать что нужно сделать.
- **Всё выполнено** → поздравить и подсказать следующий ручной шаг (проверка деплоя, дымовые тесты).

---

## Anti-patterns

- НЕ начинай экзекьюшен пока не вывел резюме пользователю. Cold start без summary = риск что пользователь не понимает что происходит.
- НЕ перезатирай блокеры в `blockers.md` без явного решения. Это лог истории.
- НЕ предполагай что пользователь видел предыдущую сессию. Каждый вызов `/continue-mvp` ведёт себя как первый.
- НЕ запускай `execute-mvp` если есть `user-interrupt.md`. Это нарушит явное намерение пользователя остановиться.
- НЕ редактируй `plan.json` руками здесь. Только `execute-mvp` владеет записью в `plan.json`. Исключение — восстановление сломанного `current-task.json` из `plan.json` (Шаг 2).
