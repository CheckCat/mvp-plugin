---
name: execute-mvp
description: Use after /plan-mvp. Drives autonomous implementation of plan.json — picks ready tasks from DAG, dispatches role-specific agents, runs checkpoint between molecules, commits each completed task, halts on Stop&Ask / interrupt-file / budget cap.
---

# execute-mvp

Сердце плейбука MVP. Автономное исполнение DAG задач: цикл «выбрать готовую молекулу → запустить агента → checkpoint → коммит → следующая» до завершения, остановки или превышения бюджета.

Полный контекст плейбука — `~/.claude/playbooks/mvp.md`. Формат `plan.json` и поведенческие правила — `~/.claude/plans/mvp-playbook.md`.

---

## Когда использовать

- `.claude/state/plan.json` существует и валиден
- `.claude/state/current-task.json` содержит `"phase": "plan-complete"` или `"phase": "in-progress"`
- Все агенты-исполнители существуют в `.claude/agents/`

Если эти условия не выполнены — Stop&Ask.

---

## Что делает (high-level)

0. Pre-flight check (runtime + git + plan.json + stack-specific tools)
1. Парсит ARGUMENTS на budget cap и optional task_id (см. ниже)
2. Вызывает Workflow tool с **scriptPath** на `~/.claude/playbooks/scripts/executeMvp.workflow.mjs` — это **единственный source of truth** для логики плейбука.
3. Workflow читает `plan.json`, итерирует по готовым задачам DAG (или выполняет один таргет), для каждой: implement → validate → review (с patch flow) → commit
4. При halt — persist plan.json и current-task.json гарантированно

---

## Шаг 0: Pre-flight check

```bash
MISSING=0
for cmd in bash python3 node git; do
  command -v $cmd >/dev/null 2>&1 || { echo "❌ $cmd не установлен"; MISSING=1; }
done

git rev-parse --git-dir >/dev/null 2>&1 || { echo "❌ Не в git-репозитории"; MISSING=1; }
test -f .claude/state/plan.json || { echo "❌ plan.json отсутствует — сначала /plan-mvp"; MISSING=1; }

# Stack-specific tools — читаем поле plan.json.stack (если есть) или CLAUDE.md fallback'ом
STACK=$(python3 -c "import json; print(json.load(open('.claude/state/plan.json')).get('stack',''))" 2>/dev/null || true)
if [ -z "$STACK" ] && [ -f CLAUDE.md ]; then
  STACK=$(grep -iE '^\| backend |^\| frontend |^\| deploy ' CLAUDE.md 2>/dev/null | tr -d '|' | tr '[:upper:]' '[:lower:]' || true)
fi

if echo "$STACK" | grep -qE 'nestjs|nextjs|react'; then
  command -v pnpm >/dev/null 2>&1 || { echo "❌ pnpm не установлен (нужен для TS-стэка)"; MISSING=1; }
fi
if echo "$STACK" | grep -qE 'fastapi'; then
  command -v python3 >/dev/null 2>&1 && python3 -c "import ruff" 2>/dev/null || command -v ruff >/dev/null 2>&1 || { echo "⚠ ruff не найден — validator lint-check провалится"; }
  command -v pytest >/dev/null 2>&1 || { echo "⚠ pytest не найден — validator test-check провалится"; }
fi
if [ -z "$STACK" ]; then
  echo "⚠ Не удалось определить stack ни из plan.json, ни из CLAUDE.md — stack-specific проверки пропущены"
fi

test $MISSING -eq 0 || { echo "Установи перечисленное и повтори /execute-mvp"; exit 1; }
```

---

## Условия остановки

Workflow останавливается чисто (не throw) при:
- Все задачи `done` — `halt_reason: 'all-done'`
- `.claude/state/user-interrupt.md` существует (проверка между молекулами) — `'user-interrupt'`
- Бюджет: `args.budget_tokens` исчерпан — `'budget-cap'`
- Implementer вернул `blocker` — `'stop-and-ask'`
- Validator fail после 1 retry — `'validator-failed-after-retry'`
- Review request-changes:
  - patch применён, но validator после него fail — `'validator-failed-after-patch'`
  - patch не применился (search not found / ambiguous) — `'patch-apply-failed'`
  - retry без patches → review всё равно request-changes — `'review-still-blocking'`
  - retry → validator fail — `'validator-failed-after-review-fix'`
- Total attempts cap (`retry_count + review_retry_count ≥ 2`) — задача `failed`, parking

**Hard cap на retry = 1** для каждой фазы. Это сознательный trade-off против старой схемы (3 retry × $1+ = до $3 утечки) — лучше Stop&Ask и решение оператора чем тихая сжига.

---

## Model mapping (cost optimization)

Каждый `agent()` вызов получает `model: <tier>` параметр. Без него наследует main loop (Opus). На прокладочных операциях это **15× дороже** чем нужно.

| Tier | Модель | Output $/M | Когда использовать |
|---|---|---|---|
| `opus` | claude-opus-4-7 | $75 | `implement` для `novel-design` задач; **любой retry** implement'а (escalation). |
| `sonnet` | claude-sonnet-4-6 | $15 | `implement` для `boilerplate` и `follow-pattern`; `validate`, `review` всегда. |
| `haiku` | claude-haiku-4-5-20251001 | $5 | `tel`, `stage-planned`, `persist`, `commit`, `invalidate-graph`, `check-interrupt`, `subgraph-extract`, `batch-tel`. Bash-обёртки, простые file rewrites. |

Правило: **по умолчанию `haiku`**, downgrade-and-up. Opus — только когда planner явно поставил `novel-design` или произошёл retry (escalation).

### Выбор модели для implement

Делается **по `task.complexity_class`**, который planner проставил в `plan.json`. **Никаких эвристик по `files.length` / `estimate_tokens` — объём ≠ сложность мышления.**

```javascript
const implementModel = (task, attempt) => {
  if (attempt > 0) return 'opus'  // escalation: ретрай implement'а всегда на Opus
  switch (task.complexity_class) {
    case 'boilerplate':    return 'sonnet'
    case 'follow-pattern': return 'sonnet'
    case 'novel-design':   return 'opus'
    default:               return 'opus'  // поле отсутствует — баг плана; safe default + tel('plan_drift')
  }
}
```

Если `complexity_class` отсутствует — это сигнал «planner забыл поле / план старый». Мы НЕ падаем: дефолтимся на Opus (безопасно) и пишем `agent-errors.jsonl` с `error_class: 'plan_drift'` чтобы analyze-telemetry это поднял.

**Escalation на retry:** если первый implement attempt прошёл, но validator или review зафейлил — следующий fix-attempt идёт через Opus вне зависимости от класса. Self-healing: ошибка планнера или хитрая задача автоматически получает голову.

В скелете скрипта см. `MODEL_FOR` mapping ниже.

## Args и budget cap

**Критично:** директива `+\d+[km]` в ARGUMENTS slash-команды (`/execute-mvp +50k`) **НЕ** автоматически устанавливает `budget.total` в Workflow runtime — это особенность Claude Code. Поэтому скилл сам парсит её из ARGUMENTS и передаёт как `args.budget_tokens` явно.

Алгоритм:
1. Прочитай ARGUMENTS строки скилла. Если есть подстрока матчующая `/^\+(\d+)([km])\b/`:
   - Группа 1 — число
   - Группа 2 — `k` (×1000) или `m` (×1000000)
   - Результат — `budget_tokens = Number(g1) * (g2 === 'm' ? 1_000_000 : 1_000)`
2. Если нет — `budget_tokens = null` (без cap'а — НЕ рекомендуется без явного желания пользователя).
3. Передай в Workflow через `args.budget_tokens`.
4. В скрипте поддерживай **локальную** переменную `localSpent` через ловлю `budget.spent()` до/после каждой task. Используй её против `args.budget_tokens` — НЕ полагайся на `budget.total`, который не выставлен.

Пример Workflow args при вызове:
```json
{
  "run_id": "<uuid>",
  "now": "<ISO8601>",
  "stack": "nestjs+nextjs+docker-dokploy",
  "budget_tokens": 50000
}
```

В скрипте перед запуском задачи:
```javascript
const cap = args.budget_tokens
if (cap && (budget.spent() - START_TOKENS) + task.estimate_tokens + 10000 > cap) {
  halted = true; haltReason = 'budget-cap'; break
}
```

`+10000` overhead — на validator + review + commit + persist agents.

---

## Вызов dispatcher

Pipeline-скрипты — **глобальные**, в `~/.claude/playbooks/scripts/`:
- `executeMvp.workflow.mjs` — DAG dispatcher (передаётся Workflow tool как `scriptPath`)
- `apply-patches.py` — детерминированный patch applier с uniqueness check
- `finalize.sh` — stage + commit + verify + invalidate + cleanup в одном bash

Проект имеет только **данные** в `.claude/state/`: `plan.json`, `current-task.json`, `decisions.log`, `telemetry/*.jsonl`, `blockers.md`, `graphify.json`. Никаких скриптов в репозитории проекта.

```javascript
// 1. Парсинг ARGUMENTS
const m = ARGUMENTS.match(/\+(\d+)([km])\b/)
const budget_tokens = m ? Number(m[1]) * (m[2] === 'm' ? 1_000_000 : 1_000) : null

// 2. Опциональный single-task targeting: /execute-mvp task-007
const taskMatch = ARGUMENTS.match(/\btask-(\d+)\b/)
const task_id = taskMatch ? `task-${taskMatch[1]}` : null

// 3. UUID и now генерируются ДО Workflow call'а — workflow body их не имеет.
// Способ — Bash:
//   run_id=$(uuidgen 2>/dev/null || python3 -c "import uuid;print(uuid.uuid4())")
//   now=$(date -u +%Y-%m-%dT%H:%M:%SZ)
const run_id = '<uuid v4>'
const now = '<ISO8601 UTC>'

await Workflow({
  scriptPath: '/Users/<user>/.claude/playbooks/scripts/executeMvp.workflow.mjs',
  // Note: Workflow tool требует absolute path. ~ не expand'ится.
  // Раскрой $HOME через Bash до вызова Workflow.
  args: {
    run_id,
    now,
    stack: 'nestjs+nextjs+docker-dokploy',
    budget_tokens,
    task_id
  }
})
```

**Если нужно резюмировать прерванный run** — передай `resumeFromRunId: '<wf_...>'`. Workflow-runner вернёт cached результаты для всех `agent()` calls с неизменёнными prompt+opts. Same args + same script = 100% cache hit на пройденных шагах.

## Что внутри dispatcher

См. `~/.claude/playbooks/scripts/executeMvp.workflow.mjs`. Гарантии:

- **Patch flow для reviewer**: на request-changes reviewer возвращает `patches[]`, workflow применяет через `apply-patches.py` БЕЗ нового implementer-агента. Экономия ~$1.5 на каждом цикле фикса.
- **Patch flow для validator**: на простых lint/build ошибках (unused-disable, missing import) validator тоже возвращает patches.
- **Retry=1 hard cap** на validator-fail и review request-changes. Дальше Stop&Ask, не сжигаем токены.
- **Total-attempts cap = 2** (retry_count + review_retry_count).
- **Harness filter** в коде (`HARNESS_RE`): только truly-universal — `.claude/`, `.git/`, `node_modules/`. Stack-specific артефакты (`next-env.d.ts`, `.turbo/`, `__pycache__/`, `prisma/generated/`) фильтруются динамически через `.gitignore` в validator Check 5 — generic mechanism, не нужно править workflow при добавлении нового стека.
- **Batched telemetry**: один flush на задачу + один на завершение. Run_id из args.
- **Один subgraph read на весь run**.
- **finalize.sh** делает stage explicit files (без `git add -A`), commit, проверяет subject prefix matches `feat:`/`fix:`/`ci:`/`chore:`/`test:`, invalidate graphify, cleanup temp. Skill `git-commit-contract` НЕ активируется потому что промпт агента содержит только `bash <path>`, без слов "git"/"commit".

## Доказанная стоимость

Прогон task-013..016 (4 молекулы frontend+devops) cold-start: **~$0.7 total**, ~$0.18 per task average. Старый pipeline: $6-12 per task. **15-20× cheaper.**

---

## Архитектурные решения (WHY)

Текущая стоимость достигнута через последовательность оптимизаций. Реализация — в `executeMvp.workflow.mjs`; ниже только обоснования (для аудита и будущих правок). Подробности bug-историй — в [[feedback-mvp-pipeline]] и observations.

- **MODEL_FOR mapping + complexity-aware implement.** Default Haiku, Sonnet для validate/review, Opus только для `complexity_class: novel-design` или escalation на retry. Без явного `model:` параметра Workflow наследует Opus и сжигает 15× больше на прокладочных операциях. Выбор по `complexity_class`, не по `files.length` — объём ≠ сложность мышления.
- **Batched telemetry.** Один agent call на flush per task вместо 5-10 sub-agent'ов на каждое JSONL событие. Экономия 25-45k/task.
- **Skip code-reviewer на trivial molecules — НЕ применяется.** Телеметрия vireo показала 44% review-catch rate (7/16 задач), включая реальные баги в boilerplate-задачах. Skip = регрессия качества, паттерн отвергнут.
- **Merged commit+persist+invalidate через `finalize.sh`.** Один bash-скрипт делает stage/commit/verify/invalidate без активации `git-commit-contract` skill (которая запускалась раньше когда промпт содержал "git"/"commit"). Workflow вызывает только `bash <path>` — skill не триггерит.
- **Validator не пишет в state.** Template ужесточён до read-only Bash (запрещены `>`, `git add`, `python -c '...write...'`); `guardStateFiles()` после ревью снят как избыточный.
- **Bash output suppress flags обязательны** в промптах для validator/reviewer (`--reporter=silent`, `--output-logs=errors-only`, `| tail -50`) — иначе десятки тысяч токенов на мусорный stdout.
- **Прокладочные haiku-агенты без `agentType`** — значительно меньше system prompt overhead. `agentType: task.role` только для implement/fix; `validator`/`code-reviewer` для своих фаз; всё остальное (stage, persist, flush) — default haiku worker.
- **Один subgraph read на весь run.** Граф читается в начале, JS-фильтр подаёт subgraph per task в имплементер-промпт. Старая схема (haiku-call subgraph на каждую задачу) убрана.
- **Patch flow для validator и reviewer.** На `request-changes` / простом validator-fail агент возвращает `patches[]`, workflow применяет через `apply-patches.py` без implementer-фикс-агента. Экономия ~$1.5 на каждом цикле. Контракт: `patches[i].search` должен быть уникальным в файле; если нет — fallback на single implementer retry (hard cap=1), потом Stop&Ask.
- **Hard cap retry=1 на validator-fail и review request-changes**, total-attempts cap=2. Старая схема (3 retry × $1+) сжигала деньги тихо; новая — Stop&Ask и решение оператора.
- **Stack-specific harness через `.gitignore`, не хардкод.** В `HARNESS_RE` только universal `.claude/`/`.git/`/`node_modules/`. Артефакты конкретного стека (`next-env.d.ts`, `.turbo/`, prisma generated) фильтруются validator Check 5 через `git check-ignore` — пайплайн становится stack-agnostic без правок workflow.

Историческая справка: ранее в этом файле был inline JS-скелет workflow + `guardStateFiles` + отдельные commit/persist/invalidate шаги; всё это снято после регрессии с `git-commit-contract` subversion и появления `finalize.sh`. Source of truth — `executeMvp.workflow.mjs`.

---

## Финальное сообщение пользователю

```
✅ Execute завершён.

Halt reason: <all-done | user-interrupt | stop-and-ask | budget-cap | dag-stuck>
Выполнено: N / M задач
Потрачено токенов: K

<если stop-and-ask: ссылка на .claude/state/blockers.md>
<если user-interrupt: подсказка удалить файл и вызвать /continue-mvp>
<если all-done: 🎉 + следующий шаг (деплой, если ещё не сделан) + подсказка вызвать /analyze-telemetry чтобы собрать паттерны ошибок и решений для будущих прогонов>
```

После `halt=all-done` обязательно подсказывай `/analyze-telemetry` отдельной строкой: это единственный момент когда телеметрия накоплена и оператор ещё в контексте проекта. Без подсказки скилл забывается и feedback loop рвётся.

---

## Anti-patterns

- НЕ запускай агента без `isolation: 'worktree'` если две задачи могут редактировать пересекающиеся файлы. В Блоке 1-4 идём последовательно (по одной задаче), поэтому worktree не нужен.
- НЕ переходи к следующей молекуле без прохождения validator текущей.
- НЕ коммить без validator pass. validator — последний детерминированный gate перед коммитом, code-reviewer — после него.
- НЕ модифицируй `plan.json` вне Workflow напрямую — только через шаг persist.
- НЕ интерпретируй "validator failed" как "пропустить и идти дальше". Три попытки → `failed`, ветка паркуется.
- НЕ блокируй на nit/simplify findings от code-reviewer'а. Только `bug`, `security`, `pattern-violation` запускают fix-loop.
- НЕ переоценивай `estimate_tokens` — это hint, не контракт. Если задача реально не помещается — это сигнал planner'у разбить её, поднимай Stop&Ask.
- НЕ трактуй `task.files` как exhaustive contract. Это **hint** от планнера. Service boundary (`packages/<service>/**` или explicit для infra) — единственный hard gate. Implementer может добавлять spec/migration/config файлы внутри boundary в рамках DoD своей роли — это не нарушение, а норма. Гнать planner'а перечислять все возможные artefacts — anti-pattern «contract drift между planner и validator».
- НЕ путай validator и code-reviewer. Validator — boolean per check. Code-reviewer — semantic findings. Они разные агенты.
- НЕ полагайся на `budget.total` от Claude Code runtime — он НЕ выставляется через ARGUMENTS slash-команды. Парси `+\d+[km]` сам и используй `args.budget_tokens`.
- НЕ принимай результаты validator/code-reviewer как доверенные если они затрагивают state-файлы. После каждого их вызова — `guardStateFiles()`. Если был drift — это баг роли, откатываем `git checkout -- .claude/state/` и логируем.
- НЕ позволяй per-phase retry-counters работать независимо без общего `total_attempts` cap. Реальные runaway-loop'ы происходят когда validator и reviewer чередуются, и ни один из счётчиков не достигает 3, а суммарная работа — 5+ итераций.
- НЕ запускай sub-agents без `model:` параметра — без него Workflow наследует Opus (~$75/M output), и прокладочные операции стоят в 15× дороже чем должны. См. секцию «Optimization patterns / Pattern 1».
- НЕ делай отдельный sub-agent на каждую JSONL-строку телеметрии. Буферизуй и flush одним вызовом в конце задачи (Pattern 2).
- НЕ гоняй code-reviewer на каждой trivial molecule (≤3 файла, не публичный API). Validator уже даёт детерминированную гарантию (Pattern 3).
- НЕ оставляй `guardStateFiles()` после того как validator-template шаблон ужесточён — это was-защита от старого validator с свободным Bash. Удалить (Pattern 5).
- НЕ запускай Bash-команды без output-suppress флагов (`--reporter=silent`, `--output-logs=errors-only`, `| tail -50`). На validate-фазе это десятки тысяч токенов мусорного stdout (Pattern 6).
- НЕ доверяй `result.modified_files` напрямую — implementer часто включает в этот список harness-файлы (`.claude/state/telemetry/decisions.jsonl` через Defer&Continue, `.claude/state/current-task.json` если workflow runtime обновил между шагами). Фильтруй через service_boundary (`productFiles`) до staging, validator, review, commit. Иначе ловишь `modified_files_drift` → validator fail (как было в task-007 → wf_a90b4f4d-c8f).
- НЕ позволяй implementer'у/reviewer'у "размазывать" tool calls по turn'ам. Каждый дополнительный turn умножает cache_read линейно: на 5-м turn'е accumulated cache ~50k, на 40-м — ~500k. На task-004 implementer Opus сделал 39 turns = 1.6M cache_read = $2.40 только на чтение кэша. Promt'ы implementer'а и reviewer'а должны явно требовать batch-чтения (несколько Read блоков в одном message), batch-write, и Bash-chaining через `&&`. См. "TOKEN EFFICIENCY RULES" в implement/review prompts.
