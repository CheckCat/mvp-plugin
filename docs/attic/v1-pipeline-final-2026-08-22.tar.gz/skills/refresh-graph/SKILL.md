---
name: refresh-graph
description: Build or refresh the code knowledge graph in .claude/state/graphify.json. Use after manual edits, before /plan-mvp on existing code, or when execute-mvp validator detects staleness. Wraps Graphify CLI with a tree-sitter fallback.
---

# refresh-graph

Строит компилированный контекст кодовой базы и сохраняет в `.claude/state/graphify.json`. Этот файл — единственный источник правды о структуре кода для `plan-mvp` и `execute-mvp`; агенты не читают сырые исходники когда подходит subgraph.

Полный контекст плейбука — `~/.claude/playbooks/mvp.md`. Описание формата `graphify.json` — ниже.

---

## Когда использовать

- После `/bootstrap-mvp` — построение начального графа (пустого если код ещё не написан)
- В начале `/plan-mvp` — чтобы planner видел уже существующие интерфейсы
- В конце каждой фазы `/execute-mvp` — рефреш после новых коммитов
- Руками — после ручных правок файлов в обход плейбука
- Из валидатора — если `mtime` изменённых файлов новее `generated_at` графа

---

## Зависимости

Скилл пытается использовать инструменты в этом порядке:

1. **Graphify** (предпочтительный) — `graphify` CLI в PATH
2. **tree-sitter fallback** — `node -e ...` со скриптом который парсит файлы через `@typescript-eslint/parser` (для TS/JS) или `ast` (для Python)
3. **Минимальный fallback** — `grep`-based извлечение публичных экспортов

Проверь что доступно:
```bash
which graphify 2>/dev/null && graphify --version
which node 2>/dev/null && node --version
```

Если Graphify не установлен — предложи пользователю:
```bash
pip install graphify-ai      # Python-вариант
# или
pnpm add -g graphify         # Node-вариант
```

Не падай если ничего нет — используй grep-fallback и пометь `tool: "grep-fallback"` в выходном файле.

---

## Шаги

### Шаг 1: Определение области

Прочитай `package.json` / `pyproject.toml` чтобы понять структуру монорепо. Скан только в:
- `packages/*/src/**` (TypeScript монорепо)
- `services/*/app/**` (Python монорепо)
- `apps/*/src/**` (Next.js apps в монорепо)

Игнорируй:
- `node_modules/`, `__pycache__/`, `.next/`, `dist/`, `build/`
- Файлы тестов (`*.spec.ts`, `*.test.ts`, `*_test.py`) — они не источник интерфейсов
- Сгенерированный код (`prisma/generated/`, `*.pb.ts`)

### Шаг 2: Запуск инструмента

**Graphify path:**
```bash
graphify build \
  --source $(pwd) \
  --include 'packages/*/src/**/*.{ts,tsx}' \
  --include 'services/*/app/**/*.py' \
  --output /tmp/graphify-raw.json
```

**tree-sitter fallback:** запусти подскрипт который извлекает:
- Имена классов/функций/типов/интерфейсов
- Сигнатуры (без тел)
- Top-level docstrings
- Imports (для edges)

**grep fallback:** только публичные экспорты:
```bash
rg --no-heading --line-number '^export (class|function|interface|type|const|enum) (\w+)' \
   --type ts --type tsx
```

### Шаг 3: Нормализация в `graphify.json`

Преобразуй вывод выбранного инструмента в наш стабильный формат:

```json
{
  "version": "1.0",
  "generated_at": "<ISO8601>",
  "tool": "graphify@0.2.1" | "tree-sitter" | "grep-fallback",
  "source_root": "<absolute path>",
  "files_scanned": 142,
  "files_hash": "sha256:...",
  "nodes": [
    {
      "id": "packages/auth-service/src/users/users.service.ts#UsersService",
      "kind": "class",
      "file": "packages/auth-service/src/users/users.service.ts",
      "exports": ["UsersService"],
      "signature": "class UsersService { create(dto: CreateUserDto): Promise<User>; findById(id: string): Promise<User | null>; }",
      "docstring": "Manages users — creation, retrieval, password updates."
    }
  ],
  "edges": [
    {
      "from": "packages/auth-service/src/users/users.controller.ts#UsersController",
      "to": "packages/auth-service/src/users/users.service.ts#UsersService",
      "kind": "calls"
    }
  ]
}
```

**Виды узлов:** `class` | `function` | `interface` | `type` | `enum` | `const`
**Виды связей:** `imports` | `calls` | `extends` | `implements` | `references`

**files_hash** — стабильный отпечаток списка сканированных файлов и их mtime. Используется в `execute-mvp` для определения "граф устарел".

### Шаг 4: Запись

```bash
mkdir -p .claude/state
mv /tmp/graphify-normalized.json .claude/state/graphify.json
```

### Шаг 5: Подсчёт экономии (опционально, для telemetry)

Если включена telemetry (с Блока 5):
```jsonl
{"event": "graph_refresh", "tool": "<tool>", "files_scanned": N, "nodes": K, "edges": E, "ms": T, "ts": "..."}
```

---

## Subgraph extraction (используется в execute-mvp)

Дана задача с `files: [a, b, c]`. Извлечение:

1. Найди все `nodes` где `node.file ∈ files`. Это **own nodes**.
2. Найди все `edges` где `edge.to ∈ own_nodes`. Источники — это **incoming dependents** (кто зависит от моего кода).
3. Найди все `edges` где `edge.from ∈ own_nodes`. Цели — это **outgoing dependencies** (что я использую).
4. Обрежь до глубины 1 (только прямые соседи). Глубина 2 — только если общее число узлов < 30.
5. Сериализуй в человекочитаемый промпт:

```
=== Modifying ===
- UsersService (packages/auth-service/src/users/users.service.ts):
    class UsersService {
      create(dto: CreateUserDto): Promise<User>
      findById(id: string): Promise<User | null>
    }
    /// Manages users — creation, retrieval, password updates.

=== I depend on ===
- PrismaService (calls):
    class PrismaService { /* exposed Prisma Client */ }
- CreateUserDto (imports):
    interface CreateUserDto { email: string; password: string; roles: Role[] }

=== Depends on me ===
- UsersController (calls):
    class UsersController { ... }
- AuthService (calls):
    class AuthService { ... }
```

Это блок инжектится в промпт агента вместо инструкции "прочитай файлы X, Y, Z".

---

## Anti-patterns

- НЕ читай весь `graphify.json` в промпт — только subgraph для текущей задачи
- НЕ перестраивай граф между молекулами без необходимости. Рефреш — в конце фазы или при флаге устаревания
- НЕ кладй в граф тела функций. Только signatures + docstrings
- НЕ строй граф во время `execute-mvp` если он уже свежий (`files_hash` совпадает с актуальным состоянием)
- НЕ полагайся на raw output Graphify напрямую — всегда нормализуй в наш формат. Иначе смена инструмента сломает потребителей
