#!/usr/bin/env bash
# export-brief-decisions.sh
#
# Дёргает ключевые решения из project_brief/ и clarify_queue.jsonl и пишет их
# в .claude/state/decisions.log как первичный snapshot для будущего
# /continue-mvp.
#
# Зачем: decisions.log — это то, что читает следующая сессия после реcет/
# compact, чтобы понять "почему мы выбрали FastAPI, а не NestJS, и кто это
# решил". project_brief/ — большой; читать целиком из cold context дорого и
# теряется фокус. Этот snapshot — короткий ответ "что было решено и почему",
# с указателями обратно в brief для деталей.
#
# Что попадает:
#   1. Stack (backend/frontend/deploy/db) + Layout — из technical_solutions.md.
#   2. Все closed критики/medium с custom answer из clarify_queue.jsonl —
#      это пользовательские корректировки, которые нельзя потерять.
#   3. Все critical-решения вообще (даже recommended-принятые) — это якоря
#      архитектуры.
#
# Что НЕ попадает:
#   - low-вопросы без custom answer (документация, не код).
#   - сами тексты brief'а (зачем дублировать).
#   - pending — там нет решения.
#
# Идемпотентность: если в decisions.log уже есть блок "## brief snapshot"
# с той же датой clarify-маркера — не дублирует.

set -u

BRIEF_DIR="${1:-project_brief}"
DECISIONS="${2:-.claude/state/decisions.log}"

[ -f "$BRIEF_DIR/technical_solutions.md" ] || { echo "❌ no $BRIEF_DIR/technical_solutions.md" >&2; exit 2; }
[ -d "$(dirname "$DECISIONS")" ] || { echo "❌ no dir for $DECISIONS" >&2; exit 2; }

# shellcheck disable=SC1090
source ~/.claude/playbooks/scripts/brief-contract.sh

BACKEND=$(extract_stack_value "$BRIEF_DIR/technical_solutions.md" backend)
FRONTEND=$(extract_stack_value "$BRIEF_DIR/technical_solutions.md" frontend)
DEPLOY=$(extract_stack_value "$BRIEF_DIR/technical_solutions.md" deploy)
DB=$(extract_stack_value "$BRIEF_DIR/technical_solutions.md" db)

LAYOUT=$(awk '/^## Layout[[:space:]]*$/{flag=1; next} flag && /^## /{exit} flag && NF{print; exit}' "$BRIEF_DIR/technical_solutions.md")

GREY="$BRIEF_DIR/analysis_grey_zones.md"
CLARIFY_DATE=""
CLARIFY_MODE=""
if clarify_marker_present "$GREY"; then
  CLARIFY_DATE=$(clarify_marker_field "$GREY" date)
  CLARIFY_MODE=$(clarify_marker_field "$GREY" mode)
fi

# Idempotency: если уже есть запись для этой даты + этого clarify-маркера — выходим.
SNAPSHOT_TAG="<!-- brief-snapshot clarify-date=${CLARIFY_DATE:-none} -->"
if [ -f "$DECISIONS" ] && grep -qF "$SNAPSHOT_TAG" "$DECISIONS"; then
  echo "ℹ decisions.log уже содержит snapshot для clarify-date=${CLARIFY_DATE:-none} — пропускаю."
  exit 0
fi

QUEUE="$BRIEF_DIR/clarify_queue.jsonl"
HAS_QUEUE=0
[ -f "$QUEUE" ] && HAS_QUEUE=1

{
  echo ""
  echo "$SNAPSHOT_TAG"
  echo "## brief snapshot — ${CLARIFY_DATE:-no-clarify-marker} (${CLARIFY_MODE:-no-mode})"
  echo ""
  echo "Stack:"
  echo "- backend: $BACKEND"
  echo "- frontend: $FRONTEND"
  echo "- deploy: $DEPLOY"
  echo "- db: $DB"
  echo "- layout: ${LAYOUT:-<unset>}"
  echo ""
  echo "Source of truth: \`$BRIEF_DIR/technical_solutions.md\` (## Stack, ## Layout)."

  if [ "$HAS_QUEUE" -eq 1 ]; then
    echo ""
    echo "### Closed clarify decisions"
    echo ""
    python3 - "$QUEUE" <<'PY'
import sys, json, re
path = sys.argv[1]

REC_RE = re.compile(r"\s*\((?:Р|р)екомендуется[^)]*\)\s*$")

def strip_recommended(s: str) -> str:
    return REC_RE.sub("", (s or "").strip()).strip()

def is_override(q: dict) -> bool:
    """Override = answer существенно отличается от первой (recommended) опции.
    Сравниваем по началу строки без хвоста «(Рекомендуется)» и без регистра —
    устойчиво и к "(Рекомендуется по умолчанию)" вариантам, и к custom-ответам
    оператора в свободной форме."""
    options = q.get("options") or []
    if not options:
        return True
    rec = strip_recommended(options[0]).casefold()
    ans = strip_recommended(q.get("answer") or "").casefold()
    if not rec or not ans:
        return True
    # answer считается «тем же», если он начинается с recommended (или наоборот).
    # Это покрывает «Pika 2.x» vs «Pika 2.x (Рекомендуется)» и «полная строка» vs «короткое имя».
    return not (ans.startswith(rec) or rec.startswith(ans))

groups = {"critical": [], "medium-custom": []}
with open(path, encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if not line: continue
        q = json.loads(line)
        if q.get("status") not in ("answered_human", "answered_auto"):
            continue
        sev = q.get("severity")
        if sev == "critical":
            groups["critical"].append(q)
        elif sev == "medium":
            if is_override(q):
                groups["medium-custom"].append(q)

def fmt(q, show_rec=False):
    lines = [f"- **[{q['id']}/{q['severity']}/{q['category']}]** {q['summary']}",
             f"  → **{q['answer']}** (source={q.get('source','?')})"]
    if show_rec:
        rec = (q.get("options") or [""])[0]
        lines.append(f"  recommended was: _{rec}_")
    return "\n".join(lines)

if groups["critical"]:
    print("**Critical (architectural anchors):**\n")
    for q in groups["critical"]:
        print(fmt(q))
    print()
if groups["medium-custom"]:
    print("**Medium — operator overrides (answer ≠ recommended):**\n")
    for q in groups["medium-custom"]:
        print(fmt(q, show_rec=True))
    print()
if not groups["critical"] and not groups["medium-custom"]:
    print("_(no closed critical or operator-overridden medium decisions)_")
PY
  else
    echo ""
    echo "_clarify_queue.jsonl отсутствует — clarify не прогонялся_"
  fi

  echo ""
  echo "Подробности и контекст каждого вопроса: \`$BRIEF_DIR/clarify_queue.jsonl\` + \`$BRIEF_DIR/analysis_grey_zones.md\` (Clarify sessions)."
} >> "$DECISIONS"

LINES=$(wc -l < "$DECISIONS")
echo "✓ decisions.log дополнен (теперь $LINES строк)"
