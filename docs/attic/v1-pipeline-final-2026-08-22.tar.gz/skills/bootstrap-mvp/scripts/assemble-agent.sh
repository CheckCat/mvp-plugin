#!/usr/bin/env bash
# assemble-agent.sh — механическая склейка проектного агент-файла.
#
# Структура результата:
#   1. Frontmatter из <role>.<stack>.template.md (или <role>.template.md)
#   2. _common.md целиком
#   3. Разделитель ---
#   4. Тело шаблона роли (всё после второго ---)
#
# Использование:
#   assemble-agent.sh <role> [stack]
#
# Пример:
#   assemble-agent.sh backend-implementer nestjs
#   assemble-agent.sh code-reviewer            # роли без стек-вариантов
#
# Переменные окружения:
#   TEMPLATES_DIR — путь к шаблонам (default: ~/.claude/agents/templates)
#   OUT_DIR       — куда писать (default: .claude/agents — относительно cwd)

set -euo pipefail

ROLE="${1:?usage: assemble-agent.sh <role> [stack]}"
STACK="${2:-}"
TEMPLATES_DIR="${TEMPLATES_DIR:-$HOME/.claude/agents/templates}"
OUT_DIR="${OUT_DIR:-.claude/agents}"

COMMON="$TEMPLATES_DIR/_common.md"
[[ -f "$COMMON" ]] || { echo "ERROR: $COMMON missing" >&2; exit 1; }

if [[ -n "$STACK" && -f "$TEMPLATES_DIR/$ROLE.$STACK.template.md" ]]; then
  TEMPLATE="$TEMPLATES_DIR/$ROLE.$STACK.template.md"
elif [[ -f "$TEMPLATES_DIR/$ROLE.template.md" ]]; then
  TEMPLATE="$TEMPLATES_DIR/$ROLE.template.md"
else
  echo "ERROR: no template for role=$ROLE stack=$STACK in $TEMPLATES_DIR" >&2
  exit 1
fi

mkdir -p "$OUT_DIR"
OUT="$OUT_DIR/$ROLE.md"

# 1. Frontmatter (от первого --- до второго ---, включительно)
awk '
  /^---$/ {
    print
    c++
    if (c == 2) exit
    next
  }
  c == 1 { print }
' "$TEMPLATE" > "$OUT"

# 2. Пустая строка + _common.md целиком
printf "\n" >> "$OUT"
cat "$COMMON" >> "$OUT"

# 3. Разделитель
printf "\n---\n\n" >> "$OUT"

# 4. Тело шаблона роли (всё после второго ---, ведущие пустые строки срезаются)
awk '
  /^---$/ { c++; next }
  c >= 2 {
    if (!started) {
      if (NF == 0) next
      started = 1
    }
    print
  }
' "$TEMPLATE" >> "$OUT"

echo "Assembled: $OUT  (template: $(basename "$TEMPLATE"))"
