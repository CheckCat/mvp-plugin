#!/usr/bin/env bash
# verify-agents-drift.sh
#
# Post-bootstrap invariant check:
# every .claude/agents/<role>.md must contain the contents of _common.md
# byte-for-byte. assemble-agent.sh inserts _common.md verbatim between the
# frontmatter and the role body — so the entire common file must appear as a
# contiguous byte substring of the assembled agent file.
#
# Why substring-match (not awk-parse): _common.md itself uses "---" lines as
# section separators internally, so trying to slice the "common block" out of
# an assembled file by finding "---" boundaries is fragile. Substring presence
# is unambiguous: either the verbatim file is in the assembled output, or it
# isn't.
#
# Drift = bug in assemble-agent.sh or manual tampering. Exits non-zero on any
# drift, with a per-file report on stderr.
#
# Usage: verify-agents-drift.sh [agents_dir] [common_md]
#   agents_dir defaults to .claude/agents (relative to CWD)
#   common_md  defaults to ~/.claude/agents/templates/_common.md
#
# This script is REQUIRED by /bootstrap-mvp Step 4.5 — the SKILL must not
# paraphrase or weaken it. If a project needs a different invariant, fork the
# script, do not rewrite it inline.

set -u

AGENTS_DIR="${1:-.claude/agents}"
COMMON_MD="${2:-$HOME/.claude/agents/templates/_common.md}"

if [ ! -d "$AGENTS_DIR" ]; then
  echo "❌ agents dir not found: $AGENTS_DIR" >&2
  exit 2
fi
if [ ! -f "$COMMON_MD" ]; then
  echo "❌ _common.md not found: $COMMON_MD" >&2
  exit 2
fi

DRIFT=0
TOTAL=0

for f in "$AGENTS_DIR"/*.md; do
  [ -f "$f" ] || continue
  TOTAL=$((TOTAL + 1))

  # python is the simplest portable way to check "is file A a byte-for-byte
  # substring of file B". No shell quoting / locale / newline-translation
  # surprises. Both _common.md and assembled files are UTF-8.
  python3 - "$COMMON_MD" "$f" <<'PY'
import sys, pathlib
common = pathlib.Path(sys.argv[1]).read_bytes()
agent  = pathlib.Path(sys.argv[2]).read_bytes()
sys.exit(0 if common in agent else 1)
PY
  rc=$?
  if [ "$rc" -ne 0 ]; then
    echo "❌ DRIFT: $f — _common.md not present byte-for-byte" >&2
    DRIFT=$((DRIFT + 1))
  fi
done

if [ "$TOTAL" -eq 0 ]; then
  echo "❌ no agent files in $AGENTS_DIR" >&2
  exit 2
fi

if [ "$DRIFT" -gt 0 ]; then
  echo "" >&2
  echo "FAIL: $DRIFT/$TOTAL agent files drifted from _common.md" >&2
  echo "Diagnose: rerun assemble-agent.sh for the drifted role(s), or inspect manual edits." >&2
  exit 1
fi

echo "✓ DRIFT-check passed: $TOTAL agent files embed _common.md byte-for-byte"
exit 0
