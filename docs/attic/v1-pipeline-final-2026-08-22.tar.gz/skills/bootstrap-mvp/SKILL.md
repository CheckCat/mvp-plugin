---
name: bootstrap-mvp
description: Use at the very start of MVP playbook. Reads project_brief/, validates stack, generates CLAUDE.md, ARCHITECTURE.md, project agents from templates, and initializes .claude/state/.
---

# bootstrap-mvp

Первый шаг плейбука MVP. Превращает пустой репозиторий с `project_brief/` в готовую к планированию структуру: правила, архитектура, проектные агенты, пустое состояние.

Полный контекст плейбука — `~/.claude/playbooks/mvp.md`. План имплементации — `~/.claude/plans/mvp-playbook.md`.

---

## Когда использовать

- Текущая директория — пустой репозиторий (только `.git/` и опционально `project_brief/`)
- В `project_brief/` есть `technical_solutions.md` с секцией `## Stack`
- Файл `.claude/state/plan.json` ещё не существует

Если хоть одно условие не выполнено — Stop&Ask, не пытайся "починить" входные данные.

---

## Что делает

0. Pre-flight check (runtime + git + project_brief)
1. Валидирует вход
2. Парсит стек
3. Маппит стек на шаблоны агентов
4. Генерирует мета-файлы
5. Инициализирует `.claude/state/`
6. Делает первый коммит

---

## Шаг 0: Pre-flight check

Запусти Bash. Любая hard-проверка fail'ит — Stop&Ask с понятным сообщением.

```bash
MISSING=0
for cmd in bash python3 node git; do
  command -v $cmd >/dev/null 2>&1 || { echo "❌ $cmd не установлен"; MISSING=1; }
done
test $MISSING -eq 0 || { echo "Установи перечисленное и повтори /bootstrap-mvp"; exit 1; }

git rev-parse --git-dir >/dev/null 2>&1 || { echo "❌ Не в git-репозитории. Выполни: git init"; exit 1; }

test -d project_brief || { echo "❌ project_brief/ отсутствует. Сначала запусти /prepare-mvp."; exit 1; }
```

---

## Шаг 1: Валидация входа

### 1.1 Базовая структура

```bash
test -f project_brief/business_logic.md || echo "BLOCKER: business_logic.md missing"
test -f project_brief/technical_solutions.md || echo "BLOCKER: technical_solutions.md missing"
test ! -f .claude/state/plan.json || echo "BLOCKER: plan.json already exists — use /continue-mvp instead"
```

Если есть хоть один BLOCKER — Stop&Ask, обычно с предложением повторить `/prepare-mvp`.

### 1.2 Brief-контракт: заголовки + непустота

Bootstrap — синтаксический gate. Никакого LLM-разбора brief'а здесь. Только проверка, что нужные заголовки на месте **и** под ними есть содержимое. Источник списка заголовков — `brief-contract.sh`.

```bash
source ~/.claude/playbooks/scripts/brief-contract.sh

# validate_brief = presence + non-emptiness для всех обязательных заголовков.
if ! validate_brief project_brief; then
  echo "⛔ Brief не закрывает контракт."
  echo "Варианты:"
  echo "  • запусти /clarify-mvp — закроет дыры интерактивно"
  echo "  • заполни секции руками в project_brief/"
  exit 1
fi
echo "✓ Brief-контракт пройден"
```

### 1.3 Реакция на маркер clarify

Если clarify прогонялся — проверь, остались ли unresolved critical вопросы.

```bash
GREY=project_brief/analysis_grey_zones.md
if clarify_marker_present "$GREY"; then
  PC=$(clarify_marker_field "$GREY" pending_critical)
  PT=$(clarify_marker_field "$GREY" pending_total)
  if [ -n "$PC" ] && [ "$PC" -gt 0 ] 2>/dev/null; then
    echo "⚠ clarify прогонялся, но pending_critical=$PC (из $PT)."
    echo "Stop&Ask: закрыть оставшиеся critical через /clarify-mvp или подтвердить запуск bootstrap на unresolved."
    # Stop&Ask через AskUserQuestion: "Дозакрыть clarify" | "Продолжить bootstrap (рискованно)"
  fi
fi
```

Если оператор выбрал «Продолжить» — продолжай. Если «Дозакрыть» — выйди с просьбой запустить `/clarify-mvp`.

---

## Шаг 2: Парсинг стека

Прочитай `project_brief/technical_solutions.md` и найди секцию `## Stack` строгим заголовком (без хвоста — `^## Stack[[:space:]]*$`). Контракт значений уже валидирован prepare-mvp, здесь только извлекаем:

```bash
source ~/.claude/playbooks/scripts/brief-contract.sh
BACKEND=$(extract_stack_value project_brief/technical_solutions.md backend)
FRONTEND=$(extract_stack_value project_brief/technical_solutions.md frontend)
DEPLOY=$(extract_stack_value project_brief/technical_solutions.md deploy)
DB=$(extract_stack_value project_brief/technical_solutions.md db)
```

Минимально нужны:
- `backend` — `nestjs` | `fastapi`
- `frontend` — `nextjs` | `react` (или `none` для backend-only)
- `deploy` — `docker-dokploy` (других пока не поддержано)
- `db` — `postgresql` (с возможными добавлениями redis, timescaledb)

Если значения не из allowlist — это означает, что prepare-mvp пропустил валидацию (баг плейбука) либо оператор отредактировал brief вручную после prepare. Stop&Ask с предложением вернуться в prepare либо переключиться на поддержанный стек.

---

## Шаг 3: Stack mapping → шаблоны агентов

Маппинг ключей стека на файлы шаблонов в `~/.claude/agents/templates/`:

| Ключ стека | Шаблон | Имя проектного агента |
|---|---|---|
| `backend: nestjs` | `backend-implementer.nestjs.template.md` | `backend-implementer.md` |
| `backend: fastapi` | `backend-implementer.fastapi.template.md` | `backend-implementer.md` |
| `frontend: nextjs` | `frontend-implementer.nextjs.template.md` | `frontend-implementer.md` |
| `frontend: react` | `frontend-implementer.react.template.md` | `frontend-implementer.md` |
| `deploy: docker-dokploy` + `backend: nestjs` | `devops-engineer.docker-dokploy.nestjs.template.md` | `devops-engineer.md` |
| `deploy: docker-dokploy` + `backend: fastapi` | `devops-engineer.docker-dokploy.fastapi.template.md` | `devops-engineer.md` |
| всегда | `integration-specialist.template.md` | `integration-specialist.md` |
| всегда | `code-reviewer.template.md` | `code-reviewer.md` |
| всегда | `validator.template.md` | `validator.md` |
| `backend: nestjs` | `test-writer.nestjs.template.md` | `test-writer.md` |
| `backend: fastapi` | `test-writer.fastapi.template.md` | `test-writer.md` |

Все шаблоны для NestJS+Next.js+Docker-Dokploy и FastAPI+React+Docker-Dokploy реализованы. Если требуется стек вне таблицы — Stop&Ask с двумя опциями:
1. Добавить шаблон под этот стек (см. `~/.claude/playbooks/mvp.md`, раздел "Расширение плейбука")
2. Сменить стек на поддержанный

---

## Шаг 4: Генерация проектных агентов

Склейку делает тул `~/.claude/skills/bootstrap-mvp/scripts/assemble-agent.sh`. Он механически собирает файл из двух источников и **не** требует от ассистента ничего переписывать.

Структура результата (одинакова для всех ролей):
1. Frontmatter из шаблона роли (`---name/description/tools---`)
2. `_common.md` целиком — байт-в-байт
3. Разделитель `---`
4. Тело шаблона роли (стек-специфика, всё после frontmatter)

### Вызов

Для каждой роли из mapping'а Шага 3:

```bash
# Роли со стеком
~/.claude/skills/bootstrap-mvp/scripts/assemble-agent.sh backend-implementer <stack>
~/.claude/skills/bootstrap-mvp/scripts/assemble-agent.sh frontend-implementer <stack>
~/.claude/skills/bootstrap-mvp/scripts/assemble-agent.sh devops-engineer "docker-dokploy.<backend>"
~/.claude/skills/bootstrap-mvp/scripts/assemble-agent.sh test-writer <stack>

# Роли без стека (всегда копируются)
~/.claude/skills/bootstrap-mvp/scripts/assemble-agent.sh integration-specialist
~/.claude/skills/bootstrap-mvp/scripts/assemble-agent.sh code-reviewer
~/.claude/skills/bootstrap-mvp/scripts/assemble-agent.sh validator
```

Аргумент `<stack>`: `nestjs` | `fastapi` для backend/test-writer; `nextjs` | `react` для frontend; `docker-dokploy.<backend>` для devops (composite, чтобы выбрать Python/Node вариант).

Если шаблон не найден — тул вернёт ненулевой exit code с сообщением, плейбук должен Stop&Ask (см. таблицу стеков в Шаге 3).

### Правила

- **Ассистент НЕ переписывает результат тула.** Файлы агентов идут в коммит как есть.
- **Ассистент НЕ модифицирует шаблоны в `~/.claude/agents/templates/`.** Проектный контекст инжектится через Workflow-промпт во время `execute-mvp`.
- Имя проектного агента — всегда `<role>.md` (без `.template`, без стека). `execute-mvp` работает с ролями, не зная стека.

### Post-bootstrap инвариант (для самопроверки и для validator'а)

Каждый `.claude/agents/<role>.md` содержит `_common.md` **байт-в-байт**. Это инвариант, не пожелание.

---

## Шаг 4.5: DRIFT-check (обязательный)

**Запусти ровно эту команду. Не упрощай, не переписывай, не «проверяй заголовок вместо тела».** Скрипт делает substring-match `_common.md` ⊂ каждый собранный агент-файл — это надёжнее парсинга `---` границ, потому что `_common.md` сам по себе содержит внутренние `---` separators.

```bash
~/.claude/skills/bootstrap-mvp/scripts/verify-agents-drift.sh
```

Поведение:
- `exit 0` + `✓ DRIFT-check passed: N agent files embed _common.md byte-for-byte` — продолжай.
- `exit 1` + список `DRIFT: <file>` — какой-то агент собрался криво или был отредактирован руками после `assemble-agent.sh`. Не продолжай:
  1. **Не «правь руками»** drifted-файл, чтобы прошёл. Запусти `assemble-agent.sh <role> [<stack>]` повторно — это вернёт файл к каноническому виду.
  2. Если повтор не помог — баг в `assemble-agent.sh` или в `_common.md`. Stop&Ask с выводом скрипта.
- `exit 2` — нет агентов / нет `_common.md`. Stop&Ask, проблема в Шаге 4.

Анти-паттерн (ОТКЛОНЁН): «упростить» проверку до `grep -q '^# Common Agent Principles' <file>`. Эта замена ловит факт наличия заголовка, но пропускает любые модификации тела common-блока. История правок плейбука уже знает такие срезания угла — не повторяй.

---

## Шаг 5: Генерация CLAUDE.md

Сгенерируй проектный `CLAUDE.md`, **до 150 строк**:

- Краткое описание проекта (1 абзац из `business_logic.md`)
- Стек (короткая таблица, не копируй весь `technical_solutions.md`)
- Структура монорепо (если применимо) — packages, общие конвенции
- Правила разработки специфичные для стека (если NestJS + pnpm — обязательные файлы в Dockerfile, изоляция guards в тестах, CI команды)
- Ссылки на `project_brief/` как первичные источники

Не дублируй содержимое `project_brief/` в CLAUDE.md. CLAUDE.md — это правила, не документация.

---

## Шаг 6: Генерация ARCHITECTURE.md

Сгенерируй начальный `ARCHITECTURE.md`:

- Список сервисов с одним предложением роли каждого (из `technical_solutions.md`)
- Mermaid-диаграмма зависимостей (если возможно вывести из `technical_solutions.md`)
- Раздел "Living document" — этот файл обновляется агентами после имплементации новых сервисов

### Архитектурные инварианты — обязательная секция

В конце `ARCHITECTURE.md` создай секцию **«Ключевые архитектурные инварианты»** с пронумерованными правилами. `plan-mvp` будет на них опираться. Минимум — invariant'ы для multi-tenant, observability, healthcheck. Если стек подпадает под один из паттернов ниже — добавь соответствующие инварианты ДОСЛОВНО, не переформулируй:

**Паттерн «modular monolith + integration workers»** (backend=fastapi, services/integration-* в `technical_solutions.md`):

> **Integration workers stateless.** `services/integration-*` не имеют доступа к БД, не имеют CryptoAdapter, не имеют доменных моделей. Контракт: принимают `access_token`/`refresh_token` plain в request body, возвращают результат + (опц.) новые токены. api/worker оркеструет state.
>
> **Shared domain package.** `services/api/app/` — Python package. `services/worker/`, `services/beat/` импортируют доменные сервисы из api через editable install (`pip install -e ../api`). Domain code живёт ровно в одном месте.
>
> **CryptoAdapter единственная точка крипты, в api.** Не дублировать в integration, не выносить в shared lib.

В mermaid-диаграмме для этого паттерна:

- **Запрещено** рисовать прямую стрелку `integration-* --> DB`. Integration не работает с БД.
- **Обязательно** рисовать `worker --> integration-*` (worker оркеструет, передаёт токены в request body).
- DB-стрелки: только `api --> DB` и `worker --> DB`.

**Антипример (из реального прогона Vireo):** bootstrap-агент сгенерировал `ITK --> PG` и `IYT --> PG`. Позже planner интерпретировал это как «integration работает с БД» → проставил ложные `depends_on` на CryptoAdapter. Validator потом валил каждую integration-задачу.

---

## Шаг 7: Инициализация .claude/state/

```bash
mkdir -p .claude/state/telemetry
touch .claude/state/decisions.log
touch .claude/state/blockers.md
touch .claude/state/telemetry/sessions.jsonl
touch .claude/state/telemetry/decisions.jsonl
touch .claude/state/telemetry/agent-errors.jsonl
touch .claude/state/telemetry/budget-usage.jsonl
touch .claude/state/telemetry/retries.jsonl
```

Контракт telemetry-событий — в `~/.claude/skills/analyze-telemetry/SKILL.md`.

Создай `.claude/state/current-task.json` со скелетом:
```json
{
  "phase": "bootstrap-complete",
  "next_command": "/plan-mvp",
  "updated_at": "<ISO8601>"
}
```

`plan.json` НЕ создаётся на этом шаге — это работа `/plan-mvp`.

## Шаг 7.5: Инициализация graphify.json

Вызови скилл `refresh-graph`. На пустом репозитории получишь файл с `nodes: []` — это нормально, граф просто стартует пустым и будет наполняться по мере того как агенты пишут код. Этот файл нужен `/plan-mvp` и `/execute-mvp` как контракт.

---

## Шаг 7.6: Снимок ключевых решений в decisions.log (обязательный)

`decisions.log` — это то, что читает следующая сессия после `/compact` / reset / `/continue-mvp`, чтобы понять «почему мы выбрали FastAPI, а не NestJS, и кто это решил». `project_brief/` большой; читать целиком из cold context дорого. Скрипт ниже формирует короткий snapshot с указателями обратно в brief для деталей.

```bash
~/.claude/skills/bootstrap-mvp/scripts/export-brief-decisions.sh
```

Что попадает в snapshot:
- **Stack + Layout** — backend/frontend/deploy/db + layout строка из `## Layout`.
- **Все closed critical-вопросы** из `clarify_queue.jsonl` — это якоря архитектуры, по которым потом будет проверяться отклонение в `/execute-mvp`.
- **Все closed medium с operator override** (answer ≠ options[0] / recommended) — корректировки оператора, которые особо важно не потерять.

Что НЕ попадает:
- low-вопросы без override (документация, не код).
- Тексты brief'а (зачем дублировать; в snapshot есть ссылки).
- Pending записи (там нет решения).

Скрипт идемпотентен по тегу `<!-- brief-snapshot clarify-date=<date> -->`: повторный вызов с тем же clarify-маркером — no-op. При смене clarify-даты добавляется новый блок.

Анти-паттерны:
- НЕ копируй `clarify_queue.jsonl` целиком в decisions.log. Это short-term снимок, не журнал.
- НЕ редактируй вывод скрипта руками после генерации. Если что-то не так — фикси сам скрипт или соответствующее место в brief/queue, и перезапусти.

---

## Шаг 8: Коммит

Вызови скилл `git-commit-contract`. Сообщение:
```
chore: bootstrap MVP playbook scaffolding

- Generated CLAUDE.md, ARCHITECTURE.md from project_brief
- Generated .claude/agents/ from templates (stack: <stack>)
- Initialized .claude/state/
```

Только после успешного коммита плейбук считается забутстраплённым.

---

## Финальное сообщение пользователю

```
✅ Bootstrap завершён.

Стек: backend=<...>, frontend=<...>, deploy=<...>
Сгенерированы агенты: <список .claude/agents/*.md>
Создано: CLAUDE.md, ARCHITECTURE.md, .claude/state/

Следующий шаг: /plan-mvp
```

---

## Anti-patterns

- НЕ зашивай проектный контекст в файлы агентов (`.claude/agents/*.md`). Контекст инжектится в Workflow-промпт.
- НЕ создавай `plan.json` на этом шаге. Это контракт `/plan-mvp`.
- НЕ модифицируй `project_brief/`. Это вход, не вывод.
- НЕ пиши Dockerfile'ы и CI-конфиги. Это работа `execute-mvp` через `devops-engineer`.
- НЕ делай семантический разбор brief'а здесь. Bootstrap — синтаксический gate; качество brief'а — задача clarify-mvp. Если bootstrap встал на пустой секции, направляй оператора в `/clarify-mvp`, а не пытайся «угадать» содержимое.
- НЕ дублируй regex/список заголовков. Дёргай `brief-contract.sh`.
- НЕ пиши в CLAUDE.md (Шаг 5) негативные запреты о технологиях, **не выбранных в `## Stack`** («не используй Sora 2», «не вводи RabbitMQ»). Если технология вне стека — её нет в проектном лексиконе, запрет про неё нерелевантен. Запреты пиши только про то, что **реально может попасть в код по ошибке** («не используй FastAPI BackgroundTasks — у нас Celery»; «не делай прямых SELECT через границы bounded contexts»).
