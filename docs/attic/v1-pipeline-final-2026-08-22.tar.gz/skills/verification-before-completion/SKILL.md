---
name: verification-before-completion
description: Run before marking any implementation done. Ensures local state matches CI exactly — lint, build, test, git status, Docker if applicable.
---

# Verification Before Completion

## When to Use

Before any of these:
- Declaring a task or batch done
- Committing code
- Asking the user to review

**Not optional.** If CI is wired, local verification is the last line of defense before wasted CI minutes.

---

## Verification Steps

Run these in order. **Stop at the first failure and fix before continuing.**

### 1. Lint

```bash
pnpm turbo lint          # monorepo
# or: pnpm lint          # single package
```

These must be the **exact same commands** used in CI. Not "similar" — identical.

### 2. Build

```bash
pnpm turbo build
```

### 3. Tests

```bash
pnpm turbo test
```

### 4. Git status

```bash
git status
git diff --stat
```

Check for:
- Untracked files that should be committed (configs, migrations, new files)
- Accidentally modified files outside task scope
- Files that should be in `.gitignore` but aren't

### 5. Docker (if Dockerfiles were changed)

Don't run a full build — verify the checklist:

- [ ] Copies root config files: `package.json pnpm-workspace.yaml pnpm-lock.yaml turbo.json tsconfig.base.json`
- [ ] Uses `--frozen-lockfile` for install
- [ ] Production stage does NOT copy devDependencies
- [ ] `CMD` uses the correct entrypoint

---

## Failure Protocol

| Failure | Action |
|---|---|
| Lint error | Fix, re-run lint only, then continue |
| Build error | Fix, re-run build + test, then continue |
| Test failure | Fix, re-run test only, then continue |
| Untracked file | Stage it or add to `.gitignore`, then re-run `git status` |
| Docker checklist item missing | Fix Dockerfile, do NOT skip |

Never mark done until all 5 steps pass.

---

## Local = CI Parity Rule

If you discover local commands differ from CI commands, fix CI to match local (or vice versa) **before** continuing. Divergence between local and CI is a bug, not a minor inconsistency.

CI reference: `.github/workflows/ci.yml` (or equivalent).
