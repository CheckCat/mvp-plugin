---
name: git-commit-contract
description: Use before every commit. A commit is a contract — it guarantees the codebase works at that point. Enforces verification before committing and defines commit message standards.
---

# Git Commit Contract

## The Contract

A commit is a **promise** to anyone who checks out that SHA: "this code compiles, tests pass, linters are clean."

Breaking this promise means:
- CI fails on a commit that "should have worked"
- Bisect finds a broken intermediate state
- Reviewers can't trust the history

---

## Before Every Commit

**Run `verification-before-completion` first.** Not a summary of what you think passed — actually run the commands and verify the output.

Only proceed to commit after all steps pass.

---

## Commit Message Format

```
<type>: <imperative description of WHY, not WHAT>

[optional body: context, trade-offs, constraints]
```

**Type:** `feat` | `fix` | `refactor` | `test` | `ci` | `chore` | `docs`

**Good:**
```
fix: guard NestJS DI from leaking between test modules
ci: block Docker build until CI passes
refactor: extract generator factory to eliminate switch duplication
```

**Bad:**
```
fix: add missing mock to test          # describes WHAT, not WHY
update auth service                    # no type, no imperative verb
WIP                                    # not a contract
```

---

## Atomic Commits

One commit = one logical change. If verification passes for part A but not part B, commit A separately.

Split commits by:
- Service/package boundary (when possible)
- Feature vs. config vs. test

Do NOT split by file type ("all .ts files", "all package.json files") — that breaks logical atomicity.

---

## What NOT to Commit

- `console.log` debug statements
- `.env` files or credentials
- Build artifacts (`dist/`, `.next/`, `coverage/`)
- Lock file changes without dependency changes (investigate first)

If `git status` shows unexpected files, investigate before staging with `-A`.

---

## Batch Commit Protocol (multi-service tasks)

When implementing across multiple services:

1. Finish one service/batch → run `verification-before-completion`
2. If all pass → commit that batch with a focused message
3. Move to next batch

Never accumulate all services into one giant commit. Granular history = useful bisect + rollback.
