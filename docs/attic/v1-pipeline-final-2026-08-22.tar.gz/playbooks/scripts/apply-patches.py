#!/usr/bin/env python3
"""
Apply search-replace patches from reviewer to product files.

Usage: python3 apply-patches.py <patches.json>

Input JSON: [{"file": str, "search": str, "replace": str, "rationale"?: str}, ...]
Output JSON (stdout): {"applied": [str, ...], "failures": [{"file", "reason", "snippet"?}, ...]}

Failure modes (each leaves the file unchanged):
- file-not-found
- search-not-found (search string не встречается в файле)
- search-ambiguous-xN (search встречается N>1 раз — unsafe replace)

Process exit code: 0 if any patches applied AND no failures; 1 if any failure or all failed.
Stdout is always valid JSON for workflow consumption regardless of exit code.
"""

import json
import pathlib
import sys


def main() -> int:
    if len(sys.argv) != 2:
        print(json.dumps({"applied": [], "failures": [{"reason": "usage", "snippet": "apply-patches.py <patches.json>"}]}))
        return 1

    patches_path = pathlib.Path(sys.argv[1])
    if not patches_path.exists():
        print(json.dumps({"applied": [], "failures": [{"reason": "patches-json-missing", "snippet": str(patches_path)}]}))
        return 1

    try:
        patches = json.loads(patches_path.read_text())
    except json.JSONDecodeError as e:
        print(json.dumps({"applied": [], "failures": [{"reason": "patches-json-invalid", "snippet": str(e)[:120]}]}))
        return 1

    if not isinstance(patches, list) or len(patches) == 0:
        print(json.dumps({"applied": [], "failures": [{"reason": "patches-empty"}]}))
        return 1

    applied: list[str] = []
    failures: list[dict] = []

    for p in patches:
        if not isinstance(p, dict) or "file" not in p or "search" not in p or "replace" not in p:
            failures.append({"reason": "patch-malformed", "snippet": str(p)[:120]})
            continue

        path = pathlib.Path(p["file"])
        if not path.exists():
            failures.append({"file": p["file"], "reason": "file-not-found"})
            continue

        text = path.read_text()
        search = p["search"]
        cnt = text.count(search)
        if cnt == 0:
            failures.append({"file": p["file"], "reason": "search-not-found", "snippet": search[:120]})
            continue
        if cnt > 1:
            failures.append({"file": p["file"], "reason": f"search-ambiguous-x{cnt}", "snippet": search[:120]})
            continue

        path.write_text(text.replace(search, p["replace"]))
        applied.append(p["file"])

    print(json.dumps({"applied": applied, "failures": failures}))
    return 0 if (applied and not failures) else 1


if __name__ == "__main__":
    sys.exit(main())
