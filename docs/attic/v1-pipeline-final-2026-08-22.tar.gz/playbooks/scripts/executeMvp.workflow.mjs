export const meta = {
  name: 'execute-mvp',
  description: 'Single dispatcher for MVP playbook. Drives DAG of tasks with implement → validate → review → (patch | retry=1) → commit. Hard caps on retry and review-fix.',
  phases: [
    { title: 'Load' },
    { title: 'Execute' },
    { title: 'Finalize' }
  ]
}

// ---------- schemas ----------

const PLAN_SCHEMA = {
  type: 'object',
  required: ['version', 'tasks'],
  properties: {
    version: { type: 'string' },
    tasks: {
      type: 'array',
      items: {
        type: 'object',
        required: ['id', 'title', 'level', 'service', 'role', 'files', 'depends_on', 'blocks', 'estimate_tokens', 'status', 'complexity_class']
      }
    }
  }
}

const VALIDATOR_SCHEMA = {
  type: 'object',
  required: ['task_id', 'checks', 'verdict'],
  properties: {
    task_id: { type: 'string' },
    checks: {
      type: 'array',
      items: {
        type: 'object',
        required: ['name', 'status'],
        properties: {
          name: { enum: ['lint', 'build', 'test', 'diff_within_service_boundary', 'modified_files_reported', 'meta_files_freshness', 'plan_adherence'] },
          status: { enum: ['pass', 'fail', 'skipped'] },
          details: { type: 'string' },
          reason: { type: 'string' }
        }
      }
    },
    verdict: { enum: ['pass', 'fail'] },
    first_failure: { type: ['string', 'null'] },
    suggested_fix: { type: ['string', 'null'] },
    // Если validator может предложить точечный patch (lint --fix есть строки, unused
    // disable, missing import, mistyped path) — возвращает patches[]. Workflow применит
    // их через apply-patches.py БЕЗ повторного запуска implementer-агента.
    // Условия и формат — те же что у reviewer (см. .claude/agents/code-reviewer.md
    // секция "Patch protocol").
    patch_attached: { type: 'boolean' },
    patches: {
      type: 'array',
      items: {
        type: 'object',
        required: ['file', 'search', 'replace'],
        properties: {
          file: { type: 'string' },
          search: { type: 'string' },
          replace: { type: 'string' },
          rationale: { type: 'string' }
        }
      }
    }
  }
}

// Reviewer теперь может вернуть patches вместе с findings.
// Если patch_attached=true и verdict=request-changes — workflow применит patches
// одним Bash-call'ом и пройдёт validator повторно БЕЗ нового implementer-агента.
// Это убирает 60+ turns × ~$1.5 на каждом review request-changes.
const REVIEW_SCHEMA = {
  type: 'object',
  required: ['findings', 'verdict'],
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        required: ['severity', 'file', 'title'],
        properties: {
          severity: { enum: ['bug', 'security', 'pattern-violation', 'simplify', 'nit'] },
          file: { type: 'string' },
          line: { type: 'integer' },
          title: { type: 'string' },
          explanation: { type: 'string' },
          suggestion: { type: 'string' }
        }
      }
    },
    summary: { type: 'string' },
    verdict: { enum: ['approve', 'comment', 'request-changes'] },
    patch_attached: { type: 'boolean' },
    patches: {
      type: 'array',
      items: {
        type: 'object',
        required: ['file', 'search', 'replace'],
        properties: {
          file: { type: 'string' },
          search: { type: 'string' },
          replace: { type: 'string' },
          rationale: { type: 'string' }
        }
      }
    }
  }
}

const TASK_RESULT_SCHEMA = {
  type: 'object',
  required: ['success', 'modified_files', 'summary'],
  properties: {
    success: { type: 'boolean' },
    modified_files: { type: 'array', items: { type: 'string' } },
    blocker: { type: ['string', 'null'] },
    summary: { type: 'string' }
  }
}

const SUBGRAPH_SCHEMA = {
  type: 'object',
  required: ['block'],
  properties: { block: { type: 'string' }, stale: { type: 'boolean' } }
}

const PATCH_APPLY_SCHEMA = {
  type: 'object',
  required: ['applied', 'failures'],
  properties: {
    applied: { type: 'array', items: { type: 'string' } },
    failures: { type: 'array', items: { type: 'object' } }
  }
}

const INTERRUPT_SCHEMA = {
  type: 'object',
  required: ['interrupted'],
  properties: { interrupted: { type: 'boolean' } }
}

// ---------- constants ----------

// Harness files leak в result.modified_files от implementer'а — известная утечка
// (см. memory feedback-modified-files-harness-filter). Раньше это лечилось
// только через service_boundary fallback; теперь — explicit filter в коде.
//
// ВАЖНО: список содержит ТОЛЬКО truly-universal harness (не зависит от стека).
// Stack-specific артефакты (next-env.d.ts для Next.js, .turbo/ для Turborepo,
// __pycache__/ для Python, prisma/generated/ и т.д.) НЕ хардкодятся здесь —
// они обрабатываются динамически через `.gitignore` в validator Check 5.
// Это generic mechanism который работает для любого стека без правки workflow.
//
// pnpm-lock.yaml НЕ harness — это валидный артефакт когда задача меняет deps.
// Если он вне service boundary — отсечётся boundary-фильтром (infra-задачи перечисляют
// его явно в planned_files, для service-задач он в корне → за boundary).
const HARNESS_RE = [
  /^\.claude\//,
  /^\.git\//,
  /^node_modules\//
]
const isHarness = (f) => HARNESS_RE.some(r => r.test(f))

const MODEL_FOR = { validate: 'sonnet', review: 'sonnet' }
const m = (k) => MODEL_FOR[k] || 'haiku'

const implementModel = (task, attempt) => {
  if (attempt > 0) return 'opus'                       // escalation на retry
  switch (task.complexity_class) {
    case 'boilerplate':    return 'sonnet'
    case 'follow-pattern': return 'sonnet'
    case 'novel-design':   return 'opus'
    default:               return 'opus'
  }
}

// Boundary uses `task.service_path` when planner set it (FastAPI single-app
// `app/`, microservices `services/<svc>/`, etc.). Falls back to pnpm-monorepo
// convention `packages/<service>/` — preserves behavior for existing plans
// that don't set the field. Bootstrap/planner are responsible for picking the
// layout; workflow stays stack-agnostic.
const computeServiceBoundary = (task) => {
  if (task.service === 'infra') return { type: 'explicit', files: task.files }
  const root = task.service_path || `packages/${task.service}`
  return { type: 'glob', patterns: [`${root}/**`], root }
}

const isInBoundary = (boundary, file) =>
  boundary.type === 'glob'
    ? boundary.patterns.some(pat => file.startsWith(pat.replace(/\*\*$/, '')))
    : boundary.files.includes(file)

const updateTask = (plan, id, patch) => ({
  ...plan,
  tasks: plan.tasks.map(t => t.id === id ? { ...t, ...patch } : t),
  updated_at: args.now
})

const commitTypeFor = (task) =>
  task.role.includes('test') ? 'test'
  : task.role.includes('devops') ? 'ci'
  : task.title.toLowerCase().startsWith('fix') ? 'fix'
  : 'feat'

const pickReady = (plan) =>
  plan.tasks.filter(t =>
    t.status === 'pending' &&
    t.depends_on.every(d => plan.tasks.find(x => x.id === d)?.status === 'done')
  )

// ---------- batched telemetry ----------
// Один agent call в конце вместо 5-10 per task. Cache_create на каждый agent ~50K,
// батч экономит ~$0.1-0.15 на задачу.

const telBuffer = []
const tel = (file, payload) => {
  telBuffer.push({
    file,
    line: JSON.stringify({ ...payload, playbook_run_id: args.run_id, ts: args.now })
  })
}
// flushTel см. flushTelToDisk ниже — определён вместе с другими finalize helpers.

// ---------- patch apply ----------
// Reviewer возвращает patches[]. Workflow пишет их в проектный временный файл
// .claude/state/patches-<label>.json и запускает GLOBAL helper apply-patches.py
// из ~/.claude/playbooks/scripts/. Скрипт возвращает {applied, failures} через
// stdout. Uniqueness search проверяется внутри — patch применяется только если
// строка встречается ровно 1 раз.

const applyPatches = async (patches, label) => {
  if (!patches || patches.length === 0) {
    return { applied: [], failures: [{ reason: 'empty-patches' }] }
  }
  const patchesFile = `.claude/state/patches-${label}.json`
  const patchesJson = JSON.stringify(patches, null, 2)

  return await agent(`
Запусти ВСЕ команды по очереди через Bash:

cat > ${patchesFile} <<'PATCHES_EOF'
${patchesJson}
PATCHES_EOF

python3 ~/.claude/playbooks/scripts/apply-patches.py ${patchesFile}
`, { schema: PATCH_APPLY_SCHEMA, label: `apply-patches:${label}`, model: 'haiku' })
}

// ---------- subagent helpers ----------

const stageFiles = async (files, label) => {
  if (files.length === 0) return
  await agent(
    `Запусти ОДНУ Bash-команду:\ngit reset HEAD -- . 2>/dev/null; git add ${files.map(f => JSON.stringify(f)).join(' ')}`,
    { label: `stage:${label}`, model: 'haiku' }
  )
}

// ---------- finalize helpers (защита от haiku самодеятельности) ----------
// Старый "cat > file <<EOF" подход проваливался: haiku-агент переписывал
// JSON содержимое heredoc (пересчитывал поля, добавлял summary). Решение:
// Write tool — точная запись, без интерпретации.

const persistJsonFiles = async (filesMap, label) => {
  // filesMap: { 'rel/path.json': contentString, ... }
  const entries = Object.entries(filesMap)
  if (entries.length === 0) return
  const blocks = entries.map(([path, content]) => {
    // Содержимое передаём через triple-quoted markdown block; в промпте явно
    // просим использовать Write tool (точная запись) и НЕ ПОДКЛЮЧАТЬ skills.
    return `### File: ${path}\n\n<<<FILE_CONTENT_BEGIN\n${content}\n<<<FILE_CONTENT_END`
  }).join('\n\n')

  await agent(`
DETERMINISTIC FILE PERSIST.

For each file below, use the Write tool with the EXACT content between the FILE_CONTENT_BEGIN/END markers. Do NOT modify, parse, or interpret the content. Do NOT add/remove fields. Do NOT use Bash heredoc.

DO NOT invoke any Skill tool (no git-commit-contract, no other skills). Skip the standard skill check — this is an internal workflow call.

Files to write:

${blocks}

Output exactly the word "DONE" when all Write calls succeeded. If any Write fails, output the file path and the error.
`, { label: `persist:${label}`, model: 'haiku' })
}

// writeMsgFile удалён: commit-msg.tmp записывается через persistJsonFiles
// (тот же Write-tool agent, что и для plan.json/current-task.json) одним
// call'ом — экономия ~10k tokens/task. persistJsonFiles не парсит content,
// просто пишет байт-в-байт, поэтому plain text работает идентично JSON.

// Wrapper around GLOBAL finalize.sh (~/.claude/playbooks/scripts/finalize.sh).
// Stage + commit + verify + invalidate + cleanup — всё внутри bash скрипта.
// Скрипт работает с .claude/state/.commit-msg.tmp как проектным временным файлом
// (cwd = project root). Prompt НЕ содержит слов git/commit чтобы
// git-commit-contract skill не активировалась (она триггерит по семантике).
const finalizeTask = async (label, expectedTypePrefix, files) => {
  const filesArg = files.map(f => JSON.stringify(f)).join(' ')
  const finalizeOutSchema = {
    type: 'object',
    required: ['committed'],
    properties: {
      committed: { type: 'boolean' },
      subject: { type: 'string' },
      sha: { type: 'string' },
      error: { type: 'string' }
    }
  }
  return await agent(`
DETERMINISTIC SCRIPT RUN.

Run exactly this Bash command (one tool call, nothing else):

\`\`\`
bash ~/.claude/playbooks/scripts/finalize.sh ${JSON.stringify(expectedTypePrefix)} .claude/state/.commit-msg.tmp ${filesArg}
\`\`\`

The script outputs single-line JSON to stdout. Return that JSON as your structured output. Do NOT add any explanation, do NOT invoke any Skill tool, do NOT run any other command. If the script exits non-zero, still return the JSON it printed (it contains the error reason).
`, { schema: finalizeOutSchema, label: `finalize-script:${label}`, model: 'haiku' })
}

const flushTelToDisk = async (label) => {
  if (telBuffer.length === 0) return
  const byFile = telBuffer.reduce((acc, e) => { (acc[e.file] ||= []).push(e.line); return acc }, {})
  // Один atomic Bash batch — printf >> file. Никакого commit, никаких heredoc.
  const commands = Object.entries(byFile).map(([f, lines]) =>
    `printf '%s\\n' ${lines.map(l => `'${l.replace(/'/g, `'\\''`)}'`).join(' ')} >> .claude/state/telemetry/${f}`
  ).join('\n')
  await agent(`
DETERMINISTIC TELEMETRY FLUSH. Run EXACTLY these Bash commands in order:

\`\`\`
${commands}
\`\`\`

DO NOT invoke any Skill tool. DO NOT modify the commands. After all run, output "DONE".
`, { label: `flush-tel:${label}`, model: 'haiku' })
  telBuffer.length = 0
}

// invalidateGraph moved into ~/.claude/playbooks/scripts/finalize.sh (Step D)

const validate = async (task, modifiedFiles, attempt) => {
  const boundary = computeServiceBoundary(task)
  const servicePath = boundary.root || (task.service === 'infra' ? '.' : `packages/${task.service}`)
  return await agent(`
[Роль: validator — читай .claude/agents/validator.md]

Run deterministic checklist for task ${task.id}.
Input:
- task_id: ${task.id}
- planned_files: ${JSON.stringify(task.files)}
- modified_files_reported: ${JSON.stringify(modifiedFiles)}
- service: ${task.service}
- service_path: ${servicePath}   # use this for any path-based bash command (ruff/pytest/etc.)
- service_boundary: ${JSON.stringify(boundary)}

Execute checks 1-7. Return per VALIDATOR_SCHEMA.
Bash commands MUST use suppress flags: --output-logs=errors-only, | tail -50.

**Patch protocol:** если verdict=fail на check lint/build/test и проблема локальная
(unused-eslint-disable, missing semicolon, missing import, mistyped path) — попробуй вернуть patches[].
Workflow применит их через apply-patches.py БЕЗ повторного спавна implementer-агента.
Условия uniqueness и формат — те же что в .claude/agents/code-reviewer.md секция "Patch protocol".

Если fix требует архитектурного изменения (новый файл, рефактор сигнатур) — patch_attached: false,
workflow вызовет implementer на 1 retry.
`, { schema: VALIDATOR_SCHEMA, label: `validate:${task.id}:${attempt}`, model: m('validate'), agentType: 'validator' })
}

const review = async (task, modifiedFiles, attempt) => {
  return await agent(`
[Роль: code-reviewer — читай .claude/agents/code-reviewer.md]

Run semantic review for task ${task.id}.
Modified files: ${modifiedFiles.join(', ')}.
Diff command: \`git diff --cached -- ${modifiedFiles.join(' ')} | head -500\`.

**Patch protocol:** если verdict=request-changes — постарайся вернуть patches[] для каждого blocking finding (bug/security/pattern-violation). Это убирает необходимость в новом implementer-агенте и экономит ~$1.5 на этом цикле. Условия и формат patches — в .claude/agents/code-reviewer.md секция "Patch protocol".

**TOKEN EFFICIENCY:**
1. Получи diff ОДНОЙ Bash командой за первый turn.
2. Прочитай modified files параллельно в одном turn'е.
3. Цель: ≤ 5 turn'ов.

Return per REVIEW_SCHEMA.
`, { schema: REVIEW_SCHEMA, label: `review:${task.id}:${attempt}`, model: m('review'), agentType: 'code-reviewer' })
}

const isInterrupted = async () => {
  const r = await agent(
    `Run: test -f .claude/state/user-interrupt.md && echo '{"interrupted":true}' || echo '{"interrupted":false}'`,
    { schema: INTERRUPT_SCHEMA, label: 'check-interrupt', model: 'haiku' }
  )
  return r.interrupted
}

// ---------- main ----------

phase('Load')
let plan = await agent(`Read .claude/state/plan.json and return JSON.`, {
  schema: PLAN_SCHEMA, label: 'load-plan', model: 'haiku'
})
tel('sessions.jsonl', {
  event: 'session_start',
  playbook: 'mvp',
  stack: args.stack,
  mode: args.task_id ? 'single-task' : 'all-pending',
  target: args.task_id ?? null
})

phase('Execute')

let halted = false
let haltReason = null
const START_TOKENS = budget.spent()

// Один runtime subgraph context — читаем graphify.json ОДИН раз за весь run,
// потом отдаём подмножество per task через JS-фильтр в промпте. Это убирает
// один haiku-call на каждую задачу.
//
// ВАЖНО про "stale after task 1": после finalize.sh мы выставляем
// graphifyRaw.stale = true (см. ниже), и subgraphFor возвращает placeholder
// для всех последующих задач. Это by-design tradeoff: для greenfield MVP
// (где каждая молекула — новый scaffold) `task.files.includes(n.file)` и так
// возвращает пустой набор — subgraph бесполезен. Цена rebuild'а между задачами
// (refresh-graph haiku-call + graphify CLI) превышает выгоду. Если на проекте
// много задач, ЭДИТЯщих существующие файлы (extend модулей, добавление
// сигнатур) — стоит добавить in-loop refresh; для греенфилд пока выкл.
let graphifyRaw = null
try {
  graphifyRaw = await agent(
    `Read .claude/state/graphify.json and return JSON. If file missing or generated_at == "1970-01-01T00:00:00Z" — return {"stale": true, "nodes": [], "edges": []}.`,
    {
      schema: { type: 'object', properties: { stale: { type: 'boolean' }, nodes: { type: 'array' }, edges: { type: 'array' }, generated_at: { type: 'string' } } },
      label: 'load-graph', model: 'haiku'
    }
  )
} catch (e) {
  graphifyRaw = { stale: true, nodes: [], edges: [] }
}

const subgraphFor = (task) => {
  if (!graphifyRaw || graphifyRaw.stale) return '(graph stale — fresh service or rebuild pending)'
  const own = (graphifyRaw.nodes || []).filter(n => task.files.includes(n.file))
  if (own.length === 0) return '(no existing code matches task files — fresh module)'
  return own.slice(0, 30).map(n => `- ${n.file}: ${n.name} (${n.kind})`).join('\n')
}

while (!halted) {
  // 1. user-interrupt check
  if (await isInterrupted()) { halted = true; haltReason = 'user-interrupt'; break }

  // 2. pick task (single-task mode short-circuits после первой задачи)
  let task
  if (args.task_id) {
    task = plan.tasks.find(t => t.id === args.task_id)
    if (!task) { halted = true; haltReason = 'task-not-found'; break }
    if (task.status === 'done') { halted = true; haltReason = 'already-done'; break }
    const depsOk = task.depends_on.every(d => plan.tasks.find(x => x.id === d)?.status === 'done')
    if (!depsOk) { halted = true; haltReason = 'deps-not-met'; break }
  } else {
    const ready = pickReady(plan)
    if (ready.length === 0) {
      const remaining = plan.tasks.filter(t => t.status === 'pending').length
      halted = true
      haltReason = remaining === 0 ? 'all-done' : 'dag-stuck'
      break
    }
    task = ready[0]
  }

  // 3. budget cap
  const cap = args.budget_tokens
  if (cap && (budget.spent() - START_TOKENS) + (task.estimate_tokens ?? 50000) + 10000 > cap) {
    halted = true; haltReason = 'budget-cap'; break
  }

  // 4. total attempts cap (≤ 2 в новой схеме: 1 implement + 1 retry)
  const totalAttempts = (task.retry_count ?? 0) + (task.review_retry_count ?? 0)
  if (totalAttempts >= 2) {
    plan = updateTask(plan, task.id, { status: 'failed' })
    tel('agent-errors.jsonl', { event: 'agent_error', task_id: task.id, phase: 'cap', error_class: 'total-attempts-cap' })
    log(`✗ ${task.id} total-attempts cap (2) — parking`)
    if (args.task_id) { halted = true; haltReason = 'failed'; break }
    continue
  }

  log(`▶ ${task.id} — ${task.title} (${task.role}) [class=${task.complexity_class}]`)

  // 5. plan-drift check
  if (!task.complexity_class) {
    tel('agent-errors.jsonl', {
      event: 'agent_error', task_id: task.id, role: task.role,
      phase: 'plan-check', error_class: 'plan_drift',
      details: 'complexity_class missing → defaulted to opus'
    })
  }

  // 6. implement
  const boundary = computeServiceBoundary(task)
  const boundaryHuman = boundary.type === 'glob'
    ? `packages/${task.service}/** (всё внутри этого пути)`
    : `точный список: ${boundary.files.join(', ')}`
  const implModel = implementModel(task, 0)

  const result = await agent(`
Ты — агент роли "${task.role}". Читай свою роль из .claude/agents/${task.role}.md, секции "Canonical patterns" если есть.

Задача: ${task.title}
Service: ${task.service}
Complexity class: ${task.complexity_class}

Service boundary (HARD): ${boundaryHuman}
— Любые файлы за этой границей запрещены.

Planned files (HINT): ${task.files.join(', ')}
— Это ориентир, не контракт. Внутри boundary можешь создавать дополнительные файлы (spec, миграции, и т.п.) если они нужны для DoD твоей роли.

Зависимости (уже выполнены): ${task.depends_on.join(', ') || '(нет)'}

### Compiled code context (subgraph)
${subgraphFor(task)}

### TOKEN EFFICIENCY (обязательно)
1. **Контекст за ОДИН batch.** Все нужные Read'ы — параллельно в первом turn'е.
2. **Write батчем.** Все новые файлы — параллельно через несколько Write блоков в одном message.
3. **Bash chaining** через && — не размазывай по turn'ам.
4. **Suppress flags:** \`--reporter=silent\`, \`--output-logs=errors-only\`, \`| tail -50\`.
5. **Не делай "проверочные" Read'ы файлов которые сам только что написал.**
6. **Цель:** ≤ 8 turn'ов для scaffold-молекулы. >12 turns = делаешь что-то лишнее.

### Modified files contract
В \`modified_files\` верни ТОЛЬКО файлы внутри service boundary. НЕ возвращай:
- harness-файлы (.claude/, .git/, node_modules/, next-env.d.ts, .turbo/, pnpm-lock.yaml)
- файлы которые ты не трогал
Workflow всё равно отфильтрует, но честный список упрощает trace.

### Defer&Continue
Если принимаешь самостоятельное решение по неоднозначному вопросу (имя приватной функции, trade-off между похожими реализациями, выбор стандартного утилитарного подхода) — допиши ОДНУ JSONL-строку в .claude/state/telemetry/decisions.jsonl через Bash:

\`\`\`bash
printf '%s\\n' '{"event":"decision","playbook_run_id":"${args.run_id}","task_id":"${task.id}","role":"${task.role}","choice":"<коротко что выбрал>","why":"<обоснование>","ts":"${args.now}"}' >> .claude/state/telemetry/decisions.jsonl
\`\`\`

Подставь \`<choice>\` и \`<why>\` своими значениями (избегай кавычек " внутри — используй ' или экранируй). Если decision не было — НЕ пиши ничего. Это телеметрия для analyze-telemetry, не лог отладки.

По окончании верни { success, modified_files, blocker, summary }.
`, { schema: TASK_RESULT_SCHEMA, label: task.id, phase: 'Execute', model: implModel, agentType: task.role })

  if (result.blocker) {
    plan = updateTask(plan, task.id, { status: 'blocked' })
    halted = true; haltReason = 'stop-and-ask'; break
  }
  if (!result.success) {
    const retries = (task.retry_count ?? 0) + 1
    plan = updateTask(plan, task.id, { retry_count: retries })
    tel('retries.jsonl', { event: 'retry', task_id: task.id, phase: 'implement', attempt: retries, reason: 'implementer-failed' })
    if (args.task_id) { halted = true; haltReason = 'implement-failed'; break }
    continue
  }

  // 7. filter modified_files: harness + boundary
  const cleanFiles = result.modified_files
    .filter(f => !isHarness(f))
    .filter(f => isInBoundary(boundary, f))
  const dropped = result.modified_files.filter(f => !cleanFiles.includes(f))
  if (dropped.length > 0) {
    log(`⚠ filtered ${dropped.length} non-product files from modified_files: ${dropped.join(', ')}`)
    tel('agent-errors.jsonl', {
      event: 'agent_error', task_id: task.id, role: task.role,
      phase: 'post-implement', error_class: 'modified_files_drift',
      details: `dropped: ${dropped.join(', ')}`
    })
  }
  if (cleanFiles.length === 0) {
    plan = updateTask(plan, task.id, { status: 'blocked' })
    tel('agent-errors.jsonl', { event: 'agent_error', task_id: task.id, phase: 'post-implement', error_class: 'no-product-files' })
    halted = true; haltReason = 'no-product-files'; break
  }

  await stageFiles(cleanFiles, `${task.id}:initial`)

  // 8. validate (1 retry на validator fail; patch path если validator вернул patches)
  let v = await validate(task, cleanFiles, 1)
  if (v.verdict === 'fail') {
    tel('agent-errors.jsonl', { event: 'agent_error', task_id: task.id, role: task.role, phase: 'validate', retry_count: 1, error_class: v.first_failure, details: v.suggested_fix?.slice(0, 200) })
    tel('retries.jsonl', { event: 'retry', task_id: task.id, phase: 'validator', attempt: 1, reason: v.first_failure })

    if (v.patch_attached && v.patches && v.patches.length > 0) {
      // ===== VALIDATOR PATCH FLOW =====
      log(`⚠ validator failed (${v.first_failure}) — patches attached (${v.patches.length}), applying without implementer`)
      const ap = await applyPatches(v.patches, `${task.id}:v`)
      if (ap.failures.length > 0) {
        log(`✗ validator patch apply failed: ${JSON.stringify(ap.failures).slice(0, 200)}`)
        tel('agent-errors.jsonl', { event: 'agent_error', task_id: task.id, phase: 'validator-patch-apply', error_class: 'patch-failed', details: JSON.stringify(ap.failures).slice(0, 200) })
        plan = updateTask(plan, task.id, { status: 'blocked', retry_count: 1 })
        halted = true; haltReason = 'validator-patch-apply-failed'; break
      }
      log(`  patches applied to ${ap.applied.length} files — re-staging & re-validating`)
      await stageFiles(cleanFiles, `${task.id}:post-v-patch`)
      v = await validate(task, cleanFiles, 'post-v-patch')
      if (v.verdict === 'fail') {
        plan = updateTask(plan, task.id, { status: 'failed', retry_count: 1 })
        tel('agent-errors.jsonl', { event: 'agent_error', task_id: task.id, phase: 'validate-post-v-patch', error_class: 'validator-failed-after-v-patch', details: v.first_failure })
        log(`✗ validator still fails after its own patch — Stop&Ask`)
        halted = true; haltReason = 'validator-failed-after-v-patch'; break
      }
    } else {
      // ===== IMPLEMENTER FALLBACK =====
      log(`⚠ validator failed (${v.first_failure}) — no patches, single implementer retry with opus escalation`)
      await agent(`
[Роль: ${task.role}] Task ${task.id} failed validation. SINGLE retry — потом Stop&Ask.
First failure: ${v.first_failure}
Suggested fix: ${v.suggested_fix}
Details: ${JSON.stringify(v.checks)}
Исправь и заверши — НЕ делай попутный рефакторинг.
`, { label: `fix-validator:${task.id}`, model: implementModel(task, 1), agentType: task.role })

      await stageFiles(cleanFiles, `${task.id}:fix-v`)
      v = await validate(task, cleanFiles, 2)
      if (v.verdict === 'fail') {
        plan = updateTask(plan, task.id, { status: 'failed', retry_count: 1 })
        tel('agent-errors.jsonl', { event: 'agent_error', task_id: task.id, phase: 'validate-retry', error_class: 'validator-failed-after-retry', details: v.first_failure })
        log(`✗ validator failed after retry — Stop&Ask`)
        halted = true; haltReason = 'validator-failed-after-retry'; break
      }
    }
  }

  // 9. review (patch flow!)
  let rev = await review(task, cleanFiles, 1)
  if (rev.verdict === 'request-changes') {
    tel('agent-errors.jsonl', {
      event: 'agent_error', task_id: task.id, role: 'code-reviewer',
      phase: 'review', retry_count: 1, error_class: 'request-changes',
      details: rev.summary?.slice(0, 200)
    })
    tel('retries.jsonl', { event: 'retry', task_id: task.id, phase: 'review', attempt: 1, reason: 'request-changes' })

    const blocking = rev.findings.filter(f =>
      f.severity === 'bug' || f.severity === 'security' || f.severity === 'pattern-violation'
    )
    log(`◇ review request-changes: ${blocking.length} blocking findings`)

    if (rev.patch_attached && rev.patches && rev.patches.length > 0) {
      // ===== PATCH FLOW =====
      log(`  patches attached (${rev.patches.length}) — applying without implementer agent`)
      const ap = await applyPatches(rev.patches, task.id)
      if (ap.failures.length > 0) {
        log(`✗ patch apply failed: ${JSON.stringify(ap.failures).slice(0, 200)}`)
        tel('agent-errors.jsonl', { event: 'agent_error', task_id: task.id, phase: 'patch-apply', error_class: 'patch-failed', details: JSON.stringify(ap.failures).slice(0, 200) })
        plan = updateTask(plan, task.id, { status: 'blocked', review_retry_count: 1 })
        halted = true; haltReason = 'patch-apply-failed'; break
      }
      log(`  patches applied to ${ap.applied.length} files — re-staging & re-validating`)

      await stageFiles(cleanFiles, `${task.id}:post-patch`)
      const vAfter = await validate(task, cleanFiles, 'post-patch')
      if (vAfter.verdict === 'fail') {
        plan = updateTask(plan, task.id, { status: 'failed', review_retry_count: 1 })
        tel('agent-errors.jsonl', { event: 'agent_error', task_id: task.id, phase: 'validate-post-patch', error_class: 'validator-failed-after-patch', details: vAfter.first_failure })
        log(`✗ validator failed after patch — Stop&Ask`)
        halted = true; haltReason = 'validator-failed-after-patch'; break
      }
      plan = updateTask(plan, task.id, { review_retry_count: 1 })
    } else {
      // ===== IMPLEMENTER FALLBACK (1 retry, hard cap) =====
      log(`  no patches attached — single implementer retry (then Stop&Ask)`)
      await agent(`
[Роль: ${task.role}] Task ${task.id} получил blocking findings от code-reviewer:
${JSON.stringify(blocking, null, 2)}
Это ЕДИНСТВЕННАЯ попытка фикса. Исправь ровно эти findings, без рефакторинга.
`, { label: `fix-review:${task.id}`, model: implementModel(task, 1), agentType: task.role })

      await stageFiles(cleanFiles, `${task.id}:post-fix`)
      const vAfter = await validate(task, cleanFiles, 'post-fix')
      if (vAfter.verdict === 'fail') {
        plan = updateTask(plan, task.id, { status: 'failed', review_retry_count: 1 })
        halted = true; haltReason = 'validator-failed-after-review-fix'; break
      }
      const revAfter = await review(task, cleanFiles, 2)
      if (revAfter.verdict === 'request-changes') {
        log(`✗ review still request-changes after retry — Stop&Ask`)
        plan = updateTask(plan, task.id, { status: 'blocked', review_retry_count: 1 })
        tel('agent-errors.jsonl', {
          event: 'agent_error', task_id: task.id, phase: 'review-retry',
          error_class: 'review-still-blocking',
          details: revAfter.summary?.slice(0, 200)
        })
        halted = true; haltReason = 'review-still-blocking'; break
      }
      plan = updateTask(plan, task.id, { review_retry_count: 1 })
    }
  }

  // 10. FINALIZE: telemetry → persist → commit → verify → invalidate.
  // Каждый шаг отдельный agent с жёсткой защитой от skill subversion.
  // ВАЖНО: telemetry flush ПЕРЕД commit — гарантия что данные на диске
  // даже если последующие шаги упадут.

  plan = updateTask(plan, task.id, { status: 'done', actual_tokens: budget.spent() })
  tel('budget-usage.jsonl', { event: 'task_complete', task_id: task.id, role: task.role, tokens: budget.spent() - START_TOKENS })

  const commitType = commitTypeFor(task)
  const commitMsg = `${commitType}: ${task.title}\n\n${result.summary}`
  const completedCount = plan.tasks.filter(t => t.status === 'done').length
  const nextFocus = pickReady(plan)[0]?.id ?? 'none'
  const currentTask = {
    phase: 'in-progress',
    current_focus: nextFocus,
    completed_count: completedCount,
    total_count: plan.tasks.length,
    updated_at: args.now
  }

  // Step A: flush telemetry до commit
  await flushTelToDisk(`pre-commit:${task.id}`)

  // Step B: persist plan.json + current-task.json + commit-msg одним agent call.
  // persistJsonFiles ничего не парсит, просто Write tool на каждый файл — plain
  // text работает идентично JSON. Объединение убирает один haiku-call.
  await persistJsonFiles({
    '.claude/state/plan.json': JSON.stringify(plan, null, 2),
    '.claude/state/current-task.json': JSON.stringify(currentTask, null, 2),
    '.claude/state/.commit-msg.tmp': commitMsg
  }, task.id)

  // Step C: finalize via bash script — stage explicit files + commit + verify
  // + invalidate graphify + cleanup temp. Один agent call, никакой skill activation.
  const commitResult = await finalizeTask(
    task.id,
    commitType,
    [...cleanFiles, '.claude/state/plan.json', '.claude/state/current-task.json']
  )
  if (!commitResult.committed) {
    log(`✗ finalize failed: ${commitResult.error ?? 'unknown'} subject="${commitResult.subject ?? ''}"`)
    tel('agent-errors.jsonl', {
      event: 'agent_error', task_id: task.id, phase: 'finalize-script',
      error_class: commitResult.error ?? 'finalize-failed',
      details: `subject="${commitResult.subject?.slice(0,120) ?? ''}"`
    })
    await flushTelToDisk(`post-finalize-fail:${task.id}`)
    halted = true; haltReason = 'finalize-failed'; break
  }
  log(`✓ commit ${commitResult.sha} — ${commitResult.subject}`)

  // graphify already invalidated inside finalize.sh
  graphifyRaw = { stale: true, nodes: [], edges: [] }

  if (args.task_id) { halted = true; haltReason = 'only-target-done'; break }
}

phase('Finalize')

// Гарантированный persist на любых halt-reasons (даже при stop-and-ask /
// budget-cap / dag-stuck) — иначе plan.json остаётся stale.
const finalCurrentTask = {
  phase: haltReason === 'all-done' ? 'complete' : 'in-progress',
  current_focus: pickReady(plan)[0]?.id ?? 'none',
  completed_count: plan.tasks.filter(t => t.status === 'done').length,
  total_count: plan.tasks.length,
  halt_reason: haltReason,
  updated_at: args.now
}

// Persist через Write tool (не heredoc — haiku-агент его переписывает)
await persistJsonFiles({
  '.claude/state/plan.json': JSON.stringify(plan, null, 2),
  '.claude/state/current-task.json': JSON.stringify(finalCurrentTask, null, 2)
}, 'finalize')

tel('sessions.jsonl', {
  event: 'session_end',
  halt_reason: haltReason,
  completed: plan.tasks.filter(t => t.status === 'done').length,
  total: plan.tasks.length,
  mode: args.task_id ? 'single-task' : 'all-pending',
  target: args.task_id ?? null
})
await flushTelToDisk('finalize')

log(`Halted: ${haltReason}`)
return {
  haltReason,
  completed: plan.tasks.filter(t => t.status === 'done').length,
  total: plan.tasks.length,
  target: args.task_id ?? null
}
