#!/usr/bin/env bash
# Finalize prepare-mvp: stage project_brief/ and project_brief.raw/, commit.
#
# Usage:
#   bash ~/.claude/playbooks/scripts/prepare-finalize.sh
#
# Output (stdout, always single-line JSON):
#   {"committed": true,  "sha": "abc1234"}
#   {"committed": false, "sha": "",        "error": "..."}
#   {"committed": false, "sha": "",        "skipped": "no-git"}
#
# Exit 0 on success or graceful skip (no-git), non-zero on real failure.
#
# Why this exists: invoking `git commit` inside an LLM agent prompt triggers
# the git-commit-contract skill which (a) calls `git add -A`, (b) creates extra
# chore commits, (c) sometimes rewrites the commit message, (d) demands
# verification-before-completion which is meaningless for a brief commit.
# Wrapping the steps in a shell script that the agent only runs via
# `bash <path>` keeps "commit" out of the agent prompt and skips skill
# activation.

set -euo pipefail

json_str() {
  python3 -c 'import sys,json; print(json.dumps(sys.argv[1]))' "$1"
}

emit_fail() {
  printf '{"committed":false,"sha":"","error":%s}\n' "$(json_str "$1")"
  exit 1
}

emit_skip() {
  printf '{"committed":false,"sha":"","skipped":%s}\n' "$(json_str "$1")"
  exit 0
}

git rev-parse --git-dir >/dev/null 2>&1 || emit_skip "no-git"

if ! git config user.name >/dev/null 2>&1 || ! git config user.email >/dev/null 2>&1; then
  emit_fail "git-user-not-configured: run 'git config user.name <name> && git config user.email <email>'"
fi

[[ -d project_brief ]] || emit_fail "project_brief/ missing — nothing to finalize"

FILES=(project_brief)
[[ -d project_brief.raw ]] && FILES+=(project_brief.raw)

git add -- "${FILES[@]}"

STAGED_IN_SCOPE=$(git diff --cached --name-only -- "${FILES[@]}")
if [[ -z "$STAGED_IN_SCOPE" ]]; then
  emit_fail "nothing-staged-in-scope"
fi

EXTRA=$(git diff --cached --name-only | grep -vxF -f <(printf '%s\n' "${FILES[@]}") | grep -vE "^(project_brief|project_brief\.raw)/" || true)
if [[ -n "$EXTRA" ]]; then
  printf 'prepare-finalize.sh: note — staged files outside scope, kept out of this commit:\n%s\n' "$EXTRA" >&2
fi

MSG_FILE=$(mktemp)
trap 'rm -f "$MSG_FILE"' EXIT
printf 'chore: prepare project_brief from raw inputs\n' > "$MSG_FILE"

COMMIT_OUT=$(mktemp)
trap 'rm -f "$MSG_FILE" "$COMMIT_OUT"' EXIT
if ! git commit -F "$MSG_FILE" -- "${FILES[@]}" >"$COMMIT_OUT" 2>&1; then
  emit_fail "commit-failed: $(head -c 200 "$COMMIT_OUT")"
fi

SHA=$(git log -1 --pretty=format:'%h')
printf '{"committed":true,"sha":%s}\n' "$(json_str "$SHA")"
