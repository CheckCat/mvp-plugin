#!/usr/bin/env bash
# Finalize one MVP task: stage explicit files, commit, verify subject prefix,
# invalidate graphify sentinel, cleanup temp artifacts.
#
# Usage:
#   bash .claude/state/finalize.sh <expected_prefix> <msg_file> <files...>
#
# Output (stdout, always single-line JSON):
#   {"committed": true,  "subject": "feat: ...", "sha": "abc1234"}
#   {"committed": false, "subject": "",          "sha": "",        "error": "..."}
#
# Exit 0 on success, non-zero on any failure.
#
# Why this exists: invoking `git commit` via an LLM agent triggers the
# git-commit-contract skill which (a) does `git add -A`, (b) creates extra
# chore commits, (c) sometimes rewrites the commit message. Wrapping the same
# steps in a shell script that the agent only runs via `bash <path>` keeps
# "commit" out of the agent prompt and avoids skill activation.

set -euo pipefail

if [[ $# -lt 3 ]]; then
  printf '{"committed":false,"subject":"","sha":"","error":"usage: finalize.sh <prefix> <msg_file> <files...>"}\n'
  exit 1
fi

EXPECTED_PREFIX="$1"
MSG_FILE="$2"
shift 2
FILES=("$@")

json_str() {
  python3 -c 'import sys,json; print(json.dumps(sys.argv[1]))' "$1"
}

emit_fail() {
  local reason="$1"
  local subj="${2:-}"
  local sha="${3:-}"
  printf '{"committed":false,"subject":%s,"sha":%s,"error":%s}\n' \
    "$(json_str "$subj")" "$(json_str "$sha")" "$(json_str "$reason")"
  exit 1
}

# Sanity: message file exists and non-empty
if [[ ! -s "$MSG_FILE" ]]; then
  emit_fail "msg-file-missing-or-empty: $MSG_FILE"
fi

# Explicit stage: add ONLY listed files (no -A, no glob expansion).
# We do NOT `git reset HEAD -- .` because that silently unstages whatever the
# operator pre-staged between molecules. Instead we use a path-restricted commit
# (`git commit -- FILES`) so the operator's index entries are preserved and any
# stale leftover in the index from a previously-killed finalize stays out of
# our commit.
git add -- "${FILES[@]}"

# Observability: if there are staged files outside our scope (operator changes
# or stale leftover from a killed prior run), log them but do not fail — the
# path-restricted commit below excludes them automatically.
STAGED_ALL=$(git diff --cached --name-only)
if [[ -n "$STAGED_ALL" ]]; then
  EXTRA=$(printf '%s\n' $STAGED_ALL | grep -vxF -f <(printf '%s\n' "${FILES[@]}") || true)
  if [[ -n "$EXTRA" ]]; then
    printf 'finalize.sh: note — staged files outside scope, kept out of this commit:\n%s\n' "$EXTRA" >&2
  fi
fi

# Guard: at least one of OUR files actually has a staged diff.
if [[ -z "$(git diff --cached --name-only -- "${FILES[@]}")" ]]; then
  emit_fail "nothing-staged-in-scope"
fi

# Commit with the prepared message file, restricted to OUR paths.
COMMIT_OUT=$(mktemp)
trap 'rm -f "$COMMIT_OUT"' EXIT
if ! git commit -F "$MSG_FILE" -- "${FILES[@]}" >"$COMMIT_OUT" 2>&1; then
  emit_fail "commit-failed: $(head -c 200 "$COMMIT_OUT")"
fi

SUBJ=$(git log -1 --pretty=format:'%s')
SHA=$(git log -1 --pretty=format:'%h')

# Verify subject prefix matches the expected type (feat/fix/chore/...)
if [[ "$SUBJ" != "${EXPECTED_PREFIX}: "* ]]; then
  emit_fail "subject-mismatch-expected-${EXPECTED_PREFIX}" "$SUBJ" "$SHA"
fi

# Invalidate graphify cache sentinel — next subgraph request triggers rebuild
python3 -c "
import json, pathlib
p = pathlib.Path('.claude/state/graphify.json')
if p.exists():
    d = json.loads(p.read_text())
    d['generated_at'] = '1970-01-01T00:00:00Z'
    p.write_text(json.dumps(d, indent=2))
" 2>/dev/null || true

# Cleanup temp artifacts (commit msg, applied patch JSONs)
rm -f .claude/state/.commit-msg.tmp 2>/dev/null || true
find .claude/state -maxdepth 1 -name 'patches-*.json' -delete 2>/dev/null || true

printf '{"committed":true,"subject":%s,"sha":%s}\n' \
  "$(json_str "$SUBJ")" "$(json_str "$SHA")"
