#!/usr/bin/env bash
# Single source of truth for the brief contract shared by:
#   - prepare-mvp  (creates the skeleton)
#   - clarify-mvp  (fills it)
#   - bootstrap-mvp (validates structure + non-emptiness)
#
# Usage:
#   source ~/.claude/playbooks/scripts/brief-contract.sh
#
# Then call the functions below. Do not duplicate header lists in skills —
# every change goes through this file.
#
# All functions are pure: no side-effects, no I/O except reading the file
# argument and writing to stderr on failures.

# ---------------------------------------------------------------------------
# Required headers
# ---------------------------------------------------------------------------

# required_headers_tech
#   Print, one per line, headers that MUST exist in technical_solutions.md.
required_headers_tech() {
  cat <<'EOF'
## Stack
## Services
## Auth
## Deploy
EOF
}

# required_headers_biz
#   Print, one per line, headers that MUST exist in business_logic.md.
required_headers_biz() {
  cat <<'EOF'
## Goal
## Roles
## Core scenarios
## MVP scope
## Success criteria
EOF
}

# optional_headers_tech
#   Headers that prepare may pre-create (currently only ## Layout, which
#   prepare auto-fills from ## Stack). clarify may add others as needed.
optional_headers_tech() {
  cat <<'EOF'
## Layout
EOF
}

# ---------------------------------------------------------------------------
# Layout auto-fill
# ---------------------------------------------------------------------------

# auto_layout_from_stack <backend> <frontend> [services_count]
#   Print the default value for the "## Layout" section based on stack keys.
#   services_count defaults to 1; pass >1 for multi-service projects.
#
#   Mapping:
#     nestjs + *                -> packages/<service>   (pnpm-monorepo)
#     fastapi + react + N>1     -> services/<service>   (microservices)
#     fastapi + *  + N=1        -> app                  (single FastAPI app)
#     anything else             -> packages/<service>   (safe default)
auto_layout_from_stack() {
  local backend="${1:-}"
  local frontend="${2:-}"
  local services_count="${3:-1}"

  case "$backend" in
    nestjs)
      echo "packages/<service>"
      ;;
    fastapi)
      if [ "$services_count" -gt 1 ]; then
        echo "services/<service>"
      else
        echo "app"
      fi
      ;;
    *)
      echo "packages/<service>"
      ;;
  esac
}

# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

# has_content_under_header <file> <header>
#   Return 0 if there is any non-whitespace content between <header> and the
#   next "## " heading (or EOF), 1 otherwise.
has_content_under_header() {
  local file="$1"
  local header="$2"
  awk -v hdr="^${header}[[:space:]]*$" '
    $0 ~ hdr { in_section = 1; next }
    in_section && /^## / { exit }
    in_section && /[^[:space:]]/ { found = 1; exit }
    END { exit !found }
  ' "$file"
}

# header_present <file> <header>
#   Return 0 if the exact header line is present (strict: no trailing chars),
#   1 otherwise. Used so "## Stack" does not match "## Stack overview".
header_present() {
  local file="$1"
  local header="$2"
  grep -qE "^${header}[[:space:]]*\$" "$file"
}

## Internal helpers: iterate headers from a producer fn without word-splitting.
##
## Why: required_headers_* emit "## Foo" lines. A naive `for h in $(fn)` breaks
## on the space between "##" and "Foo". We always iterate line-by-line via
## `while IFS= read -r`. The helpers below encapsulate that so callers don't
## have to remember.

# _check_headers_presence <producer_fn> <file>
#   For each header line printed by <producer_fn>, verify presence in <file>.
#   Returns 0 if all present, 1 otherwise. Writes ❌ lines to stderr.
_check_headers_presence() {
  local producer="$1"
  local file="$2"
  local rc=0
  local header
  while IFS= read -r header; do
    [ -z "$header" ] && continue
    if ! header_present "$file" "$header"; then
      echo "❌ $file: заголовок '${header}' отсутствует" >&2
      rc=1
    fi
  done < <("$producer")
  return $rc
}

# _check_headers_full <producer_fn> <file>
#   For each header line printed by <producer_fn>, verify presence AND
#   non-empty section content in <file>. Returns 0 if all OK, 1 otherwise.
_check_headers_full() {
  local producer="$1"
  local file="$2"
  local rc=0
  local header
  while IFS= read -r header; do
    [ -z "$header" ] && continue
    if ! header_present "$file" "$header"; then
      echo "❌ $file: заголовок '${header}' отсутствует" >&2
      rc=1
      continue
    fi
    if ! has_content_under_header "$file" "$header"; then
      echo "❌ $file: секция '${header}' пуста" >&2
      rc=1
    fi
  done < <("$producer")
  return $rc
}

# Public high-level validators. Three skills (prepare/clarify/bootstrap) call
# these — no callsite ever has to know the header list. Update the producer
# functions above, and every skill picks up the change.

# validate_tech_presence <file>
#   Used by prepare/clarify: skeleton-level check (all required tech headers
#   exist; section content may be empty).
validate_tech_presence() {
  local file="${1:-project_brief/technical_solutions.md}"
  [ -f "$file" ] || { echo "❌ $file: файл отсутствует" >&2; return 1; }
  _check_headers_presence required_headers_tech "$file"
}

# validate_biz_presence <file>
#   Used by prepare/clarify: skeleton-level check for business_logic.md.
validate_biz_presence() {
  local file="${1:-project_brief/business_logic.md}"
  [ -f "$file" ] || { echo "❌ $file: файл отсутствует" >&2; return 1; }
  _check_headers_presence required_headers_biz "$file"
}

# validate_tech <file>
#   Used by bootstrap: full check (presence + non-empty sections).
validate_tech() {
  local file="${1:-project_brief/technical_solutions.md}"
  [ -f "$file" ] || { echo "❌ $file: файл отсутствует" >&2; return 1; }
  _check_headers_full required_headers_tech "$file"
}

# validate_biz <file>
#   Used by bootstrap: full check (presence + non-empty sections).
validate_biz() {
  local file="${1:-project_brief/business_logic.md}"
  [ -f "$file" ] || { echo "❌ $file: файл отсутствует" >&2; return 1; }
  _check_headers_full required_headers_biz "$file"
}

# validate_brief_presence <brief_dir>
#   Convenience: prepare/clarify-level full brief check.
validate_brief_presence() {
  local dir="${1:-project_brief}"
  local rc=0
  validate_tech_presence "$dir/technical_solutions.md" || rc=1
  validate_biz_presence  "$dir/business_logic.md" || rc=1
  return $rc
}

# validate_brief <brief_dir>
#   Convenience: bootstrap-level full brief check.
validate_brief() {
  local dir="${1:-project_brief}"
  local rc=0
  validate_tech "$dir/technical_solutions.md" || rc=1
  validate_biz  "$dir/business_logic.md" || rc=1
  return $rc
}

# ---------------------------------------------------------------------------
# Stack extraction (used by all three skills)
# ---------------------------------------------------------------------------

# extract_stack_value <file> <key>
#   Pull a single key value from the "## Stack" bullet list.
#   Key is one of: backend | frontend | deploy | db
extract_stack_value() {
  local file="$1"
  local key="$2"
  grep -E "^- ${key}:" "$file" | head -1 | sed -E "s/^- ${key}:[[:space:]]*//"
}

# ---------------------------------------------------------------------------
# Clarify marker parsing
# ---------------------------------------------------------------------------

# clarify_marker_field <analysis_grey_zones_file> <field>
#   Extract a field from the LATEST clarify marker.
#   Marker format:
#     <!-- clarify-mvp:done <ISO-date>; mode=<m>; pending_critical=<N>; pending_total=<M> -->
#   Field names: date | mode | pending_critical | pending_total
#   Prints empty string and returns 1 if marker or field is absent.
#
#   NOTE: clarify can be run multiple times on the same brief (light → hard,
#   resume etc.), producing several markers in the file. Bootstrap and other
#   consumers MUST see the most recent one — take the LAST occurrence, not the
#   first. Trailing strip of \r handles CRLF files.
clarify_marker_field() {
  local file="$1"
  local field="$2"
  [ -f "$file" ] || { echo ""; return 1; }
  local line
  line=$(grep -E '^<!-- clarify-mvp:done' "$file" 2>/dev/null | tail -n1 | tr -d '\r') || { echo ""; return 1; }
  [ -n "$line" ] || { echo ""; return 1; }

  case "$field" in
    date)
      echo "$line" | sed -E 's/^<!-- clarify-mvp:done[[:space:]]+([^;[:space:]]+).*/\1/'
      ;;
    mode|pending_critical|pending_total)
      echo "$line" | grep -oE "${field}=[^;[:space:]]+" | head -1 | sed -E "s/^${field}=//"
      ;;
    *)
      echo ""
      return 1
      ;;
  esac
}

# clarify_marker_present <analysis_grey_zones_file>
#   Return 0 if clarify ran on this brief (marker exists), 1 otherwise.
clarify_marker_present() {
  local file="$1"
  [ -f "$file" ] || return 1
  grep -qE '^<!-- clarify-mvp:done' "$file"
}
