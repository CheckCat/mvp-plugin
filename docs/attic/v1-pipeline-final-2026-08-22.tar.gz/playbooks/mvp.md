# Плейбук MVP — от пустого репозитория до работающего MVP

Автономный flow генерации, имплементации и деплоя MVP с минимальным вмешательством оператора. Состояние хранится на диске, любой шаг можно прервать и продолжить с пустого контекстного окна командой `/continue-mvp`.

---

## Когда использовать

- Новый pet-проект, пустой репозиторий
- Есть исходное описание проекта в любом виде (один файл, несколько файлов, любая папка). `/prepare-mvp` упакует это в каноническую структуру.

Каноническая структура после `/prepare-mvp`:
```
project_brief/
  business_logic.md       — что мы вообще делаем и зачем
  technical_solutions.md  — обязательно содержит секцию ## Stack
  glossary.md             — термины предметной области (опционально)
  analysis_grey_zones.md  — принятые решения по неоднозначным вопросам (опционально)
project_brief.raw/        — исходники, перенесены сюда автоматически (можно удалить руками после успешного bootstrap)
```

## Когда НЕ использовать

- Существующий проект с кодовой базой → плейбука пока нет, используй обычные скиллы
- Расширение MVP уже работающего → плейбука пока нет
- Простая задача в 1-2 файла → обычная сессия Claude Code

---

## Pre-flight requirements

Каждый скилл плейбука запускает inline-проверку на Шаге 0. Если что-то отсутствует — Stop&Ask с понятным сообщением.

| Инструмент | Когда нужен | Hard / Soft |
|---|---|---|
| `bash`, `python3`, `node` | Все этапы | Hard для всех |
| `git` + репозиторий | `/bootstrap-mvp` и далее | Hard. `/prepare-mvp` — Soft (warn если нет, коммит пропустится) |
| `pnpm` | execute с TS-стэком (nestjs/nextjs/react) | Hard на execute |
| `ruff`, `pytest` | execute с FastAPI | Soft warn (validator упадёт явно если их нет) |
| Graphify CLI | refresh-graph | Soft (есть tree-sitter/grep fallback) |

---

## Команды

| Команда | Когда вызывать | Что делает |
|---|---|---|
| `/prepare-mvp [path] [--force]` | Самый первый шаг | Discovery исходников (`.md`/`.txt`/`.json`) → LLM packaging в каноническую `project_brief/` → перенос исходников в `project_brief.raw/`. Опционально коммит. |
| `/clarify-mvp [--auto] [--force]` | После `/prepare-mvp`, до `/bootstrap-mvp` | Audit `project_brief/` на дыры (несостыковки / бизнес-логика / стек) → закрывает их через AskUserQuestion или reasonable defaults (`--auto`) → дописывает ответы в brief + audit log в `analysis_grey_zones.md` |
| `/bootstrap-mvp` | После `/clarify-mvp` | Читает `project_brief/`, генерирует `CLAUDE.md`, `ARCHITECTURE.md`, `.claude/agents/` (из шаблонов под стек), `.claude/state/` |
| `/plan-mvp` | После `/bootstrap-mvp` | Запускает planner → создаёт `.claude/state/plan.json` (с top-level `stack` полем) и `PROJECT_PLAN.md` |
| `/execute-mvp` | После `/plan-mvp` | Запускает Workflow: молекула → checkpoint → коммит → следующая молекула. Останавливается на Stop&Ask, interrupt-file или завершении |
| `/continue-mvp` | После остановки в новой сессии | Читает `.claude/state/`, восстанавливает контекст, продолжает с того же места |
| `/refresh-graph` | После ручных правок кода | Перестраивает `.claude/state/graphify.json` — компилированный контекст кодовой базы (классы, функции, типы, edges) |
| `/analyze-telemetry` | После прогона или раз в неделю | Агрегирует JSONL-логи в actionable отчёт: какие шаблоны обновить, какие правила добавить |

---

## Стандартный flow

```
1. Положи описание проекта в любом виде (свободные .md/.txt в корне, или в любой папке)
2. /prepare-mvp
   → формируется project_brief/, исходники в project_brief.raw/
   → проверь project_brief/, поправь если что-то выпало
3. /clarify-mvp
   → отвечаешь на вопросы по дырам/несостыковкам через AskUserQuestion
   → (или /clarify-mvp --auto для закрытия дыр reasonable defaults без вопросов)
   → ответы дописываются в business_logic.md / technical_solutions.md
   → полный audit log в analysis_grey_zones.md
4. /bootstrap-mvp
   → проверь CLAUDE.md, ARCHITECTURE.md, .claude/agents/*.md
5. /plan-mvp
   → проверь PROJECT_PLAN.md (markdown-view DAG)
   → если хочешь — поправь plan.json вручную
6. /execute-mvp
   → дождись остановки или завершения
7. Если остановка по Stop&Ask:
   → читай .claude/state/blockers.md
   → впиши решение в тот же файл
   → /continue-mvp
8. Если хочешь вмешаться посередине:
   → touch .claude/state/user-interrupt.md
   → дождись стопа между молекулами
   → внеси правки в код или plan.json
   → /continue-mvp
9. Если закрыл сессию (compact/clear/новое окно):
   → просто /continue-mvp в новой сессии
```

---

## Точки автономности vs точки внимания

| Без тебя | Нужен ты |
|---|---|
| Имплементация молекулы агентом | Подтверждение крупных архитектурных решений (Stop&Ask) |
| Lint/build/test checkpoint | Выбор внешних сервисов (Stripe vs Lemon и т. п.) |
| Коммит после прохождения checkpoint | Security-чувствительный код (auth flow, шифрование) |
| Переход к следующей молекуле | Решение конфликта когда агент трижды не смог пройти review |
| Запись в decisions.log мелких выборов | Изменение публичного API между сервисами |
| Резюмирование через `/continue-mvp` | Изменение схемы БД с миграцией данных |

---

## Цикл качества молекулы

Каждая молекула проходит фиксированный пайплайн:

```
implement → validator → code-review → commit → next
   ↑          ↓             ↓
   └──fix──── fail ────request-changes
   (max 3 раза implement-retry, max 3 раза review-fix-loop)
```

**Validator** — детерминированный агент. Запускается всегда. Чек-лист (lint/build/test exit codes, diff matches planned files, modified_files_reported соответствует реальности, ARCHITECTURE.md свежее, plan adherence). Boolean pass/fail per check, общий verdict pass/fail. Без свободного анализа.

**Code-reviewer** — семантический агент. Запускается после validator pass. Возвращает findings с severity (`bug` / `security` / `pattern-violation` / `simplify` / `nit`) и verdict (`approve` / `comment` / `request-changes`). Только `bug` / `security` / `pattern-violation` блокируют коммит и запускают fix-loop.

**Ограничения цикла:**
- 3 implement-retry на validator-fail → задача `failed`, ветка DAG паркуется (`Block&Park`)
- 3 review-fix-loop на `request-changes` → задача `blocked`, Stop&Ask с findings в `blockers.md`

После `commit` молекула считается завершённой и плейбук переходит к следующей готовой задаче DAG. `code-reviewer` не блокирует следующую молекулу если verdict ∈ {`approve`, `comment`} — это и есть «асинхронность» обещанная в acceptance: nit/simplify findings лежат в логе review для отдельной пост-MVP уборки.

## Уровни остановки

1. **Stop&Ask** — критичное решение, плейбук блокируется до твоего ответа. Запись в `.claude/state/blockers.md`. Возобновление через `/continue-mvp`.
2. **Defer&Continue** — некритичное решение принимается агентом самостоятельно, фиксируется в `.claude/state/decisions.log` для аудита. Никакой остановки.
3. **Block&Park** — задача помечается `parked`, плейбук продолжает независимые ветки DAG. Запись в `blockers.md` с пометкой `parked`.

Полные критерии — в [плане плейбука](~/.claude/plans/mvp-playbook.md), раздел "Поведенческие правила".

---

## Компилированный контекст (Graphify)

Чтобы не передавать агентам сырые исходники файлов и не плодить расход токенов, плейбук строит граф знаний кодовой базы.

**Что в графе:** имена классов/функций/типов/интерфейсов, их сигнатуры (без тел), top-level docstrings, связи (imports/calls/extends/implements).

**Как используется:**
- `/plan-mvp` — planner получает сводку (список сервисов и кол-во экспортов) для оценки сложности
- `/execute-mvp` — для каждой молекулы извлекается subgraph (own + 1 уровень соседей) и инжектится в промпт агента вместо «прочитай файлы X, Y, Z»

**Инструмент:** предпочтительно [Graphify CLI](https://github.com/...) (`pip install graphify-ai` или `pnpm add -g graphify`). Если не установлен — `refresh-graph` использует tree-sitter fallback, в крайнем случае — grep по экспортам. В файле `graphify.json` всегда сохраняется поле `tool` чтобы было видно какой источник был использован.

**Стейл-логика:** после каждой завершённой молекулы граф помечается как stale (sentinel в `generated_at`). Полный rebuild делается лениво — когда следующая молекула впервые запросит subgraph.

**Экономия:** ожидаемая ~3-5× против передачи файлов целиком. Реальная цифра — в `telemetry/budget-usage.jsonl` после прогона.

## Telemetry и обратная связь

Каждый прогон плейбука пишет JSONL-логи в `.claude/state/telemetry/`:

| Файл | Что внутри |
|---|---|
| `sessions.jsonl` | `session_start` / `session_end` со стеком, halt reason, итоговой стоимостью |
| `decisions.jsonl` | Defer&Continue решения агентов (`task_id`, `choice`, `why`) |
| `agent-errors.jsonl` | Каждый fail (validator/review/implement) с `error_class` и первыми 200 символами details |
| `budget-usage.jsonl` | Per-task расход токенов, события `graph_refresh` |
| `retries.jsonl` | Каждая retry-попытка с `phase` и `reason` |

**Корреляция:** все события содержат `playbook_run_id` (UUID прогона) и `ts` — можно склеивать сессии без сторонних агрегаторов.

**Как извлекать выгоду:**

```
/analyze-telemetry
```

Этот скилл читает все JSONL, считает метрики per-role / per-stack, ищет паттерны (≥ 3 одинаковых fails — кандидат на правило, ≥ 5 одинаковых Defer&Continue — кандидат на default) и выдаёт markdown-отчёт с конкретными предложениями: какой шаблон агента обновить, какое правило добавить в `_common.md`, где плейбук теряет деньги.

**Цикл обратной связи:**
1. Прогон плейбука пишет telemetry
2. `/analyze-telemetry` после прогона выявляет систематические проблемы
3. Оператор обновляет шаблоны / правила в `~/.claude/agents/templates/` или `~/.claude/skills/`
4. Следующий прогон работает лучше

Без telemetry улучшения шаблонов — это догадки. С ней — численно обоснованные правки.

## Стоимость

Ориентир для одного полного прогона MVP (NestJS + Next.js + Docker/Dokploy, 10-12 сервисов):

| План подписки | Реалистичность | Комментарий |
|---|---|---|
| $20 | Не хватит | Хватит на bootstrap + plan, execute упирается в лимиты |
| $100 | 1 MVP в день | Рабочий вариант, hard cap на $40-50 в `plan.json` |
| $200 | Комфортно | Можно прогнать MVP + править и переделывать без оглядки |

Бюджет контролируется через `plan.json.budget.total_usd` и `budget.remaining()` внутри `execute-mvp` Workflow. При `hard_cap: true` исполнение останавливается на Stop&Ask при достижении лимита.

---

## Поддерживаемые стеки

- **Backend:** NestJS (TypeScript), FastAPI (Python)
- **Frontend:** Next.js 15+ (App Router), React + Vite
- **Deploy:** Docker + Dokploy (включая GitHub Actions CI)
- **БД:** PostgreSQL, Redis (TimescaleDB при необходимости)
- **Шина:** RabbitMQ (MVP), Kafka (масштаб)

Если в `technical_solutions.md` указан стек которого нет в этом списке — `/bootstrap-mvp` остановится Stop&Ask и предложит:
1. Добавить шаблон агента под этот стек (см. "Расширение плейбука")
2. Ослабить требования и использовать близкий поддержанный стек

---

## Файловая модель

### Глобальный уровень (`~/.claude/`)

```
playbooks/mvp.md                                  ← этот файл
agents/templates/
  _common.md                                      ← общая основа для всех
  backend-implementer.nestjs.template.md
  backend-implementer.fastapi.template.md
  frontend-implementer.nextjs.template.md
  frontend-implementer.react.template.md
  devops-engineer.docker-dokploy.template.md
  integration-specialist.template.md
  code-reviewer.template.md
  test-writer.nestjs.template.md
  test-writer.fastapi.template.md
skills/
  bootstrap-mvp/SKILL.md
  plan-mvp/SKILL.md
  execute-mvp/SKILL.md
  continue-mvp/SKILL.md
  refresh-graph/SKILL.md
```

`_common.md` склеивается с каждым специализированным шаблоном при копировании в `.claude/agents/<role>.md` — общие принципы не дублируются в файлах, а проектный агент получает полный набор.

### Проектный уровень (генерируется)

```
CLAUDE.md                            ← правила, <150 строк
ARCHITECTURE.md                      ← живой граф сервисов
PROJECT_PLAN.md                      ← view DAG (автогенерация из plan.json)
.claude/
  agents/                            ← сгенерированы из шаблонов под стек
  state/
    plan.json                        ← источник правды DAG
    current-task.json                ← где сейчас плейбук
    decisions.log                    ← аудит Defer&Continue решений
    blockers.md                      ← Stop&Ask список (для тебя)
    user-interrupt.md                ← создаёшь руками когда хочешь стоп
    graphify.json                    ← кеш графа кодбазы (с Блока 3)
    telemetry/                       ← JSONL логи (с Блока 5)
```

---

## Расширение плейбука

### Добавить новый шаблон агента под свой стек

1. Скопируй ближайший шаблон в `~/.claude/agents/templates/`:
   ```bash
   cp ~/.claude/agents/templates/backend-implementer.nestjs.template.md \
      ~/.claude/agents/templates/backend-implementer.django.template.md
   ```
2. Перепиши секции с правилами фреймворка под Django (структуру модулей, ORM, тесты)
3. Добавь стек в [таблицу выше](#поддерживаемые-стеки)
4. Зарегистрируй ключ стека в `bootstrap-mvp/SKILL.md` (раздел "Stack mapping")

### Поправить шаги плейбука

Скиллы (`bootstrap-mvp`, `plan-mvp`, `execute-mvp`, `continue-mvp`) — независимые файлы. Меняешь один — остальные не ломаются. Контракт между ними — через файлы в `.claude/state/`:

- `bootstrap-mvp` пишет: `CLAUDE.md`, `ARCHITECTURE.md`, `.claude/agents/*.md`, пустой `.claude/state/`
- `plan-mvp` читает: мета-файлы; пишет: `plan.json`, `PROJECT_PLAN.md`
- `execute-mvp` читает: `plan.json`, `current-task.json`; пишет: `current-task.json`, `decisions.log`, `blockers.md`, обновляет `plan.json`
- `continue-mvp` читает всё в `.claude/state/`, восстанавливает контекст, вызывает `execute-mvp`

---

## Источник правды

При сомнениях, потере контекста, расхождении между этим документом и реальностью — читай файл плана:

```
~/.claude/plans/mvp-playbook.md
```

Там зафиксированы:
- 10 ключевых решений дизайн-сессии
- Полная файловая модель
- Формат `plan.json` с JSON-схемой
- Anti-hallucination checklist
- Что сделано и что осталось из Блоков 1-5
